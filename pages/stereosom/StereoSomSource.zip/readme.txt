This is the StereoSOM readme file.

Index:
1. Copyright and license
2. Development Environments and Tools Used
3. StereoSOM under Linux
4. Using the StereoSOM tool
5. Understanding the source code

****

1. Copyright and license
	All the source code and binaries in this archive is (c) Marco Vanetti and
	under the Modified BSD License (see license.txt for details).
	StereoSOM was developed in collaboration with the CRAIIM research center 
	(http://win.dicom.uninsubria.it/craiim/), and the Department of Computer
	Science and Communications 
	(http://www.uninsubria.it/uninsubria/dipartimenti/dicom.html), University
	of Insubria, Italy.

2. Development Environments and Tools Used
	*	OS: 		Microsoft Windows Vista Business 32bit
	*	Compilers: 	Microsoft C# 4.0 Compiler
					GNU GCC for the C code
	*	VM:			Microsoft .NET Framework 4.0
	*	IDE: 		Visual Studio 2010 for the C# code
						Plugins: JetBrains' ReSharper 
						(http://www.jetbrains.com/resharper)
					DevCPP for the C code
	*	Testing:	NUnit Framework (http://www.nunit.org)
					Rhino Mocks Framework 
					(http://hibernatingrhinos.com/open-source/rhino-mocks)

3. StereoSOM under Linux
	*	StereoSOM was tested under the OS Ubuntu 10.04, with Mono 2.4.4 as
		VM for .NET binaries and Mono Develop 2.4 as IDE.
	*	You must use EmguCV managed DLLs for Linux (download from
		http://www.emgu.com).
	*	You must use EmguCV unmanaged binaries for Linux (download from
		http://www.emgu.com,
		include them into the "EmguLibraries" .NET project and, for each of
		them in the VS Solution, set the "Copy to output Directory" property
		to "Copy if newer").
	*	To run StereoSOM under Linux, Mono required packages: mono-winforms*
		(run "sudo apt-get install mono-winforms*" to install this package).

4. Using the StereoSOM tool
	*	StereoSOM tool (for Windows) is in the "bin" directory of the archive.
	*	To obtain a full help you can type 
			stereosom.exe --help 
		in the Windows Command Line, or
			mono stereosom.exe --help 
		in the Linux Terminal.
	*	Usage example: 
			stereosom.exe -maxd=15 -g tsukuba_l.png tsukuba_r.png
			Where
			- 	"maxd" is the max disparity value (in pixels)
			-	"g" shows a window where you can follow the process
			-	"tsukuba_l.png" and "tsukuba_r.png" are example stereo images
	*	You can find the StereoSOM tool's source code in the 
		"source\StereoSomTool" directory or opening the StereoSomTool's VS
		project within the StereoSomSharp solution (StereoSomSharp.sln).
	
5. Understanding the Source code
	* Project structure and testing method
	-	StereoSOM is composed by a core algorithm, written in C code for
		maximum performance, and a non-core part written in C#/.NET (called 
		StereoSomSharp). The core algorithm come from my Master Thesis, I 
		think it is well written but not unit-tested at all. However some 
		integration test in the StereoSomSharp fix the behavior of the core 
		algorithm.
	-	StereoSOM .NET part was my first full-project experiment done using 
		Test Driven / Test First Development: it is 61% test-covered (mainly 
		because it contains a lot of parameters configuration code and a 
		wrapper for the core algorithm that is intrinsically hard to test).
		
	* Start working with StereoSomSharp code
	-	As the first step you should execute all the 43 non-ignored NUnit 
		tests in the VS solution and they should pass taking few seconds.
		(Using the ReSharper plugin within VS, you can right-click on the 
		solution node in the Solution Explorer and click "Run Unit Tests").
	-	As the second step you should execute the ignored integration tests
		contained into the CorrectnessTest class (StereoSom.Tests.Integration),
		they should pass, fixing the behavior of the core algorithm.
	-	Now that all tests are green, you can start looking at the
		TwoFrameTest test class (ArteStereo.Tests.Integration), it 
		contains some ignored integration tests that show how to use the 
		"Arte Stereo" framework that includes:
		*	wrappers for stereo matching algorithms in OpenCV/EmguCV
		*	the StereoSOM algorithm classes
		*	the stereo matching evaluation classes, based on the evaluation
			framework described in http://vision.middlebury.edu/stereo
	- 	The core algorithm is under the "StereoSomEngine" directory.
		To compile it under Windows you may use GCC and DevCPP (DevCPP project:
		StereoSomEngine.dev).
		To compile it under Linux you may use the shell script "make.sh".


June 2011 - Marco Vanetti