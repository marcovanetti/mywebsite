/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */
 
#include <stdlib.h>

#include "ssom.h"
#include "ssom_utility.h"
#include "node_selection.h"
#include "matching.h"
#include "weights_update.h"

// Esegue l'aggiornamento dei pesi nella SOM
void update_weights(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res selected, matching_res match) {

	int r, c;									// Indici accesso matrici
	double deltaR, deltaG, deltaB, gk;	
	double hk;									// Variabili per il calcolo delle funzioni "gk" e "hk"
	double ogk = sess->ogk;
	
	// SOM "obbiettivo" in cui eseguire l'aggiornamento
	SSom* target = ((targetSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));
	
	/* Effettua il round dei valori del neurone vincente (sono valori positivi!) */
	int iwC = (int)(match.col + 0.5);
	int iwR = (int)(match.row + 0.5);
	
	// Coordinate del rettangolo che rachiude l'area di vicinato
	int neighLeft = int_trim(iwC - sess->neighSize, 0, sess->IColumns - 1);
	int neighRight = int_trim(iwC + sess->neighSize, 0, sess->IColumns - 1);
	int neighTop = int_trim(iwR - sess->neighSize, 0, sess->IRows - 1);
	int neighBottom = int_trim(iwR + sess->neighSize, 0, sess->IRows - 1);
	
	for (r = neighTop; r <= neighBottom; r++) {
		for (c = neighLeft; c <= neighRight; c++) {
			// Funzione di vicinato per la feature "intensità di colore"
			if (sess->enableGTerm) {
			/* Calcola le differenze tra l'"intensità di colore" del neurone vincente e la
			 * componente "intensità di colore" del vettore pesi dei neuroni nel vicinato
			 */
			 
				deltaR = (target->rW)[iwR][iwC] - (target->rW)[r][c];
				deltaG = (target->gW)[iwR][iwC] - (target->gW)[r][c];
				deltaB = (target->bW)[iwR][iwC] - (target->bW)[r][c];
																											 
				gk = EXP	(	-(	(	POW2(deltaR) +
										POW2(deltaG) + 
										POW2(deltaB)
							 		) / (2.0 * (ogk))
								)
							);

			} else {
				// Se richiesto, disabilita la funzione g...
				gk = 1.0;
			}
			
			// Calcola la funzione hk (Ottimizzato)
			hk = (opt_str->hkMat)[(r - iwR) + sess->neighSize][(c - iwC) + sess->neighSize];
			
			// Formula di aggiornamento dei pesi
			(target->vCorrW)[r][c] += 
						(hk * gk * ( ( (double)c - (match.col - selected.col) + 1.0) - (target->vCorrW)[r][c] ));
		}
	}
	
	//  Usando la disparita'� reale (data) compila la mappa degli errori di matching
		if ((sess->lSSom.expectedDisp)[iwR][iwC] != 0 && (targetSom == LEFT_SOM)) 
			if (abs((match.col - selected.col) - (sess->lSSom.expectedDisp)[iwR][iwC]) >= 1)
				(target->matchingErr)[(int)selected.row][(int)selected.col]++;
}

// Genera la matrice per l'ottimizzazione di hk (funzione a campana gaussiana)
void allocate_hk_matrix(stereo_session* sess, optimization* opt_str) {
	int extension = (2 * sess->neighSize + 1);
	double ohk = -(POW2((double)sess->neighSize))/(log(sess->gaussBorder/sess->alpha)*2.0);

	// Alloca l'aray bidimensionale
	opt_str->hkMat = (hk_matrix)malloc(extension * sizeof(double*));
	int m;
	for(m = 0; m < extension; m++)
		(opt_str->hkMat)[m] = (double*)malloc(extension * sizeof(double));

	int r,c;
	for(r = 0; r < extension; r++) {
		for(c = 0; c < extension; c++) {
			if (sess->gaussBorder != sess->alpha) { // Funzione gaussiana
				(opt_str->hkMat)[r][c] = double_trim(
												(sess->alpha) * 
												exp( -( 	(	POW2((r - sess->neighSize)) + 
																POW2((c - sess->neighSize))
															) / (2.0 * ohk)
									  					)
													)
												, 0, 1);
				if ((opt_str->hkMat)[r][c] < sess->gaussBorder) (opt_str->hkMat)[r][c] = 0;

			} else { // Funzione "a cerchio"
			
				(opt_str->hkMat)[r][c] = 
					double_trim(
						sess->alpha * 
						((sqrt(POW2(r - sess->neighSize) + POW2(c - sess->neighSize)) <= sess->neighSize) ? 1 : 0)
						, 0, 1
					);
			}
		}
	}
}

// Libera la memoria ocupata dalla matrice per l'ottimizzazione di hk
void deallocate_hk_matrix(stereo_session* sess, optimization* opt_str) {
	int extension = (2 * sess->neighSize + 1);
	
	int m;
	for(m = 0; m < extension; m++)
		free((void*)(opt_str->hkMat)[m]);
	free((void*)(opt_str->hkMat));
}

