/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */
 
#include "ssom.h"
#include "ssom_utility.h"

// Fa "ricadere" un intero x nell'intervallo [min,max]
int int_trim(int x, int min, int max) {
	if (x < min)
		return min;
	else if (x > max)
		return max;

	return x;
}

// Fa "ricadere" un double x nell'intervallo [min,max]
double double_trim(double x, double min, double max) {
	if (x < min)
		return min;
	else if (x > max)
		return max;

	return x;
}

// Inverte la SOM considerata (sinistra->destra / destra->sinistra)
som_dir reverse_som(som_dir sdir) {
	return (sdir == LEFT_SOM) ? RIGHT_SOM : LEFT_SOM;
}

