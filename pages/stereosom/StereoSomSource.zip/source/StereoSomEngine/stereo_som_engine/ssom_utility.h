/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#include <math.h>
#include <stdlib.h>
#include "exp_appr.h"

// MARCO  potenza di 2
#define POW2(x) pow(x,2)

// Fa "ricadere" un intero x nell'intervallo [min,max]
int int_trim(int x, int min, int max);

// Fa "ricadere" un double x nell'intervallo [min,max]
double double_trim(double x, double min, double max);

// Inverte la SOM considerata (sinistra->destra / destra->sinistra)
som_dir reverse_som(som_dir sdir);

