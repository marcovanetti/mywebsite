/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

// MACRO PER VALUTAZIONE SUBPIXEL
#define SPIX(pixelMap,r,c) ((double)(pixelMap)[(int)(r)][(int)(c)] * (((double)1)-((c)-((int)(c)))) + (double)(pixelMap)[(int)(r)][((int)(c))+1] * (((double)(c))-((int)(c))))

// Modalita'� di ricerca
typedef enum 	{	ONE_WAY, 
					BIDIRECTIONAL
				} search_modes;

// Funzioni di matching
typedef enum 	{	EUCLIDEAN_SPIX,
					ZEUCLIDEAN_SPIX,
					NCC_SPIX,
					MATCHING_FUNCTIONS
				} matching_functions;
 
// Risultato dell'operazione di matching
typedef struct {
	int valid;
	double row;
	double col;
} matching_res;

// Funzione di matching generale
typedef matching_res (*matching_function)(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread);

// Ricerca del matching tra due neuroni
matching_res find_match(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res selected, search_modes sMode, matching_functions mFunc, int thread);

// Gerenera il supporto variabile
void generate_support(stereo_session* sess, optimization* opt_str, som_dir sourceSom, select_res sel, int thread);
// Alloca la memoria per l'ottimizzazione del supporto variabile
void allocate_support(stereo_session* sess, optimization* opt_str);
// Dealloca la memoria occupata per l'ottimizzazione del supporto variabile
void deallocate_support(stereo_session* sess, optimization* opt_str);

