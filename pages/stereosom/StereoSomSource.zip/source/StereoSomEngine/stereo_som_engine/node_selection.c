/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */
 
#include <stdlib.h>

#include "ssom.h"
#include "ssom_utility.h"
#include "node_selection.h"

// Seleziona un neurone delle SOM seguendo le politiche nella sessione sess
select_res select_node(stereo_session* sess, som_dir sourceSom) 
{

	int int_row, int_col;
	select_res result;
	
	// Ricava le coordinate del pixel casuale
	if (sess->nodeSelStrategy == 0) 
    {
		// Pixel estratto casualmente
		result.row = (double)rnd_number(0, sess->IRows - 1);
		result.col = (double)rnd_number(0, sess->IColumns - 2); /* N.B. La valutazione subpixel 
																	utilizza un pixel e quello alla 
																	sua destra */
	}
    else 
    {
		do 
        {
			// Pixel estratto da un vettore casuale
			ind_to_sub(sess->IRows, 
                (sess->lSSom.randomPermutation)[sess->lSSom.randomPermutationProgression], &int_row, &int_col);
			result.row = int_row;
			result.col = int_col;

			// La dimensione del vettore casuale delle estrazioni e' IRows*IColumns
			(sess->lSSom.randomPermutationProgression)++;
			if ((sess->lSSom.randomPermutationProgression) >= (sess->IRows * sess->IColumns))
			{
				sess->lSSom.randomPermutationProgression = 0;
            }
		}
        while (result.col == (sess->IColumns - 1)); /* N.B. La valutazione subpixel 
																				utilizza un pixel e quello alla 
																				sua destra */
	}
	
	return result;
}

// Converte un indice lineare in una coppia di coordinate
// a = 1    2    3    4
//     5    6    7    8
//     9   10   11   12
// a(10) =  4
//
void ind_to_sub(int rows, int ind, int* r, int* c) 
{
	*r = ((ind - 1) % rows);
	*c = ceil((double)ind / rows) - 1;
}

// Genera un intero casuale nell'intervallo [min,max]
int rnd_number(int min, int max)
{
	int range = (max - min) + 1;
  //return min + (int)(double)range * rand() / (RAND_MAX + 1.0);
  return min + (rand() % range);
}

