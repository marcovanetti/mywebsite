/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#include <stdlib.h> 

#include "ssom.h"
#include "ssom_utility.h"
#include "node_selection.h"
#include "matching.h"
#include "matching_functions.h"

// Implementazioni delle funzioni di matching
matching_function matching[MATCHING_FUNCTIONS] = 
	{
		(void*)euclidean_spix_matching,
		(void*)z_euclidean_spix_matching,
		(void*)ncc_spix_matching
	};

// Ricerca del matching tra due neuroni
matching_res find_match(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res selected, search_modes sMode, matching_functions mFunc, int thread) {

	// SOM da cui e' stato estratto il neurone
	SSom* source = ((targetSom == LEFT_SOM) ? &(sess->rSSom) : &(sess->lSSom));
	
	matching_res one_way_res; 	// Risultato matching one way
	matching_res check_res;		// Risultato matching check
	select_res check_sel;		// Neurone di partenza per la fase di check
	
	// Genera il supporto variabile sulla SOM sorgente
	generate_support(sess, opt_str, reverse_som(targetSom), selected, thread);
	
	// Trova il match di andata
	one_way_res = matching[mFunc](sess, opt_str, targetSom, selected, thread);	
	
	if (sMode == BIDIRECTIONAL) {
		check_sel.row = one_way_res.row;
		check_sel.col = one_way_res.col;
		
		// Genera il supporto variabile sulla SOM destinazione
		//generate_support(sess, targetSom, check_sel, thread);

		// Trova il match di check (usando il supporto variabile calcolato in precedenza)
		check_res = matching[mFunc](sess, opt_str, reverse_som(targetSom), check_sel, thread);
		
		// Se il check da esito negativo, invalida il risultato
		if (abs(selected.col - check_res.col) > sess->qualityThreshold) {
			one_way_res.valid = 0;
			(source->consistenceErr)[(int)selected.row][(int)selected.col]++;
		}
	}
	
	return one_way_res;
}

// Gerenera il supporto variabile
void generate_support(stereo_session* sess, optimization* opt_str, som_dir sourceSom, select_res sel, int thread) {
	double rEye,cEye;									// Indici accesso matrici
	double deltaR, deltaG, deltaB, gk;			// Variabili per il calcolo della funzione "gk"
	double searchEye = sess->searchEye;			// Dimensioni SearchEye
	SSom* source;										// SOM da cui è stato estratto il neurone

	// Imposta la SOM sorgente e quella destinazione della ricerca
	source = ((sourceSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));

	for (rEye = (sel.row - searchEye); rEye <= (sel.row + searchEye); rEye += 1.0) {
		for (cEye = (sel.col - searchEye); cEye <= (sel.col + searchEye); cEye += 1.0) {
	
			/* Controlla che le coordinate usate per eseguire i confronti non escano dalle
				matrici in memoria */
			if (rEye >= 0 && ((int)(rEye))   < sess->IRows		&&
				 cEye >= 0 && ((int)(cEye)+1) < sess->IColumns		) {
				
				if (searchEye) {
						deltaR = SPIX(source->rW, rEye, cEye) - SPIX(source->rW, sel.row, sel.col); // !! Problema, sel.col può uscire dalla matrice !!
						deltaG = SPIX(source->gW, rEye, cEye) - SPIX(source->gW, sel.row, sel.col);
						deltaB = SPIX(source->bW, rEye, cEye) - SPIX(source->bW, sel.row, sel.col);
				
						gk =	EXP(	-(	(	POW2(deltaR) + 
									  			POW2(deltaG) + 
									  			POW2(deltaB)
									  			/*+ POW2(cEye-sel.col) + POW2(rEye-sel.row)*/
											) / (2 * sess->oSearch)
										)
								);

						opt_str->support[thread][(int)(rEye - sel.row + searchEye)]
													[(int)(cEye - sel.col + searchEye)] 
													=gk;
				}
			} else {
				opt_str->support[thread][(int)(rEye - sel.row + searchEye)]
											[(int)(cEye - sel.col + searchEye)] 
											= 0.0;
			}
		}
	}
}

// Alloca la memoria per l'ottimizzazione del supporto variabile
void allocate_support(stereo_session* sess, optimization* opt_str) {
	int extension = (2 * sess->neighSize + 1);
	int tid, m;
	
	// Alloca l'array bidimensionale
	for (tid = 0; tid < P_THREADS; tid++) {
		(opt_str->support[tid]) = (double**)malloc(extension * sizeof(double*));
		for(m = 0; m < extension; m++) {
			(opt_str->support[tid])[m] = (double*)malloc(extension * sizeof(double));
		}
	}
}

// Dealloca la memoria occupata per l'ottimizzazione del supporto variabile
void deallocate_support(stereo_session* sess, optimization* opt_str) {
	int extension = (2 * sess->neighSize + 1);
	int tid, m;

	for (tid = 0; tid < P_THREADS; tid++) {
		for(m = 0; m < extension; m++) {
			free((void*)(opt_str->support[tid])[m]);
		}
		free((void*)(opt_str->support[tid]));
	}
}


