/* Copyright (C) 1999 Nicol N. Schraudolph
 * Based on "A fast, compact approximation of the exponential function"
 *
 * Author: Nicol N. Schraudolph
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */
 
#include <math.h>

static union 
{ 
	double d;
	struct 
	{
// Macchine LITTLE_ENDIAN 
	   int j, i; 
// Macchine BIG_ENDIAN
//	int i, j; 

	} n; 
} _eco;

#define EXP_A (1048576/M_LN2) /* use 1512775 for integer version */ 
#define EXP_C 60801 					/* see text for choice of c values */ 

#define EXP_1(y) (_eco.n.i = EXP_A*(y) + (1072693248 - EXP_C), _eco.d)
#define EXP_2(y) ((y) > -700 ? EXP_1(y) : 0) /* Avoid errors for negative exponents with big absolute part */
#define EXP(y) ((y) < 700 ? EXP_2(y) : 1.014232055e+304) /* Avoid errors for exponents with big absolute part */
