/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#include <time.h>
#include "ssom.h"
#include "ssom_utility.h"
#include "node_selection.h"
#include "matching.h"
#include "weights_update.h"

// StereoSOM algorithm core
void stereo_som_engine(stereo_session* sess) {
	
	select_res selected;           // Coordinate del neurone estratto casualmente
	matching_res Lmatch, Rmatch;   // Coordinate dei pixel vincenti
	optimization opt_str;          // Optimization structure
	
	srand((unsigned)sess->lSSom.randomPermutationProgression);	// Random initialization seed
	
	// Genera la matrice per l'ottimizzazione della funzione hk (Programmazione dinamica)
	allocate_hk_matrix(sess, &opt_str);
	// Genera la matrice per l'ottimizzazione del supporto variabile
	allocate_support(sess, &opt_str);
		
	// Ciclo iterazioni
	int it;
	for (it = 0; it < sess->coreIterations; it++) {
        
		// Seleziona le coordinate di un neurone casuale
		selected = select_node(sess, RIGHT_SOM);
		
		// Ricerca il match nella SOM di sinistra
		Lmatch = find_match(sess, &opt_str, LEFT_SOM, selected, sess->searchMode, sess->matchingFunction, 0);

		// Ricerca il match nella SOM di destra
		Rmatch = find_match(sess, &opt_str, RIGHT_SOM, selected, sess->searchMode, sess->matchingFunction, 0);

		// Controlla la validita'  della corrispondenza di sinistra
		if(Lmatch.valid) {
			// Esegue aggiornamento dei pesi nella SOM di sinistra
			update_weights(sess, &opt_str, LEFT_SOM, selected, Lmatch);
		}
		
		// Controlla la validita'�della corrispondenza di destra
		if(Rmatch.valid) {
			// Esegue aggiornamento dei pesi nella SOM di destra
			update_weights(sess, &opt_str, RIGHT_SOM, selected, Rmatch);
		}	
	}

	// Libera la memoria occupata dalle matrice per l'ottimizzazione di hk
	deallocate_hk_matrix(sess, &opt_str);
	// Libera la memoria occupata dalla matrice per l'ottimizzazione del supporto variabile
	deallocate_support(sess, &opt_str);
}
