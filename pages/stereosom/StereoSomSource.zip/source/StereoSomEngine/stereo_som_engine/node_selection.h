/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

// Risultato dell'operazione di selezione
typedef struct {
    double row;
    double col;
} select_res;

// Seleziona un neurone delle SOM seguendo le politiche nella sessione sess
select_res select_node(stereo_session* sess, som_dir sourceSom);

// Converte un indice lineare in una coppia di coordinate
void ind_to_sub(int rows, int ind, int* r, int* c);

// Genera un intero casuale nell'intervallo [min,max]
int rnd_number(int min, int max);

