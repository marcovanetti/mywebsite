/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

// Numero di sessioni parallele (OpenMP)
#define P_THREADS 1

void get_simple_session(int*);

// Determina in quale SOM (destra/sinistra) si cerca il matching
typedef enum {LEFT_SOM = 1, RIGHT_SOM = 2} som_dir;

// Matrice aggiornamento neurale (ottimizzazione dynamic programming)
typedef double** hk_matrix;

// Matrice rilevanza (ottimizzazione dynamic programming)
typedef double** rk_matrix;

// Supporto variabile per le funzioni di matching (ottimizzazione allocazione)
typedef double** w_support; // Pesi del supporto variabile

// SOM image
typedef struct
{
    // Red channel weights
	double** rW;
    // Green channel weights
	double** gW;
    // Blue channel weights
	double** bW;
    // Vertical correspondence weights
	double** vCorrW;
	// Matching errors
	int** matchingErr;
	// Consistence errors
	int** consistenceErr;
	// Truth disparity data
	double** expectedDisp;
    // Random point permutation (used by node selection)
	int* randomPermutation;
    int randomPermutationProgression;
} SSom;

// Stereo session image
typedef struct
{
    // Image size
	int IRows;
	int IColumns;
	
	// Disparity constraint
	int minDisp;
	int minVDisp;
	int maxDisp;
	int maxVDisp;
	
	// Node selection strategy
    int nodeSelStrategy;
    
    // Iterations
    int coreIterations;
	
	// Matching strategy
    int matchingFunction;
	int searchEye;
	double oSearch;
	double subPixGran;
    double dispWeight;
	double colorWeight;
    
    // Consistence check strategy
	int searchMode;
	double qualityThreshold;
	
	// Weight updating strategy
	int enableGTerm;
	double ogk;	
	int neighSize;
	double alpha;
	double gaussBorder;
    
    // SOM data
	SSom lSSom;
	SSom rSSom;	
} stereo_session;

// Structure used for optimization purposes
typedef struct
{
	hk_matrix hkMat;               // pre-calculated hk function
	w_support support[P_THREADS];  // pre-calculated adaptive support
} optimization;

// Nucleo dell'algoritmo StereoSOM
void stereo_som_engine(stereo_session* sess);

