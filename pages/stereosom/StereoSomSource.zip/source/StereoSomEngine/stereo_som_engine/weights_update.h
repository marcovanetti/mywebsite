/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

// Esegue l'aggiornamento dei pesi nella SOM
void update_weights(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res selected, matching_res match);

// Genera la matrice per l'ottimizzazione di hk (funzione a campana gaussiana)
void allocate_hk_matrix(stereo_session* sess, optimization* opt_str);

// Libera la memoria occupata dalla matrice per l'ottimizzazione di hk
void deallocate_hk_matrix(stereo_session* sess, optimization* opt_str);

