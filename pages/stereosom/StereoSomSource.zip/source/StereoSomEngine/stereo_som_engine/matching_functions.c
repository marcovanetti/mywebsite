/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#include "ssom.h"
#include "ssom_utility.h"
#include "node_selection.h"
#include "matching.h"
#include "matching_functions.h"

// Implementa la funzione di matching subpixel basata su distanza euclidea
matching_res euclidean_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread) {

	matching_res winner = {0, 0.0,0.0};			// Risultato matching one way
	double subPixGran = 1.0;						// Granularità della ricerca subpixel
	int subPixSteps, subPixStep;					// Fasi della valutazione subpixel
	double 	searchWindowLeft = 0, spixSearchWindowLeft = 0,
				searchWindowRight = 0, spixSearchWindowRight = 0,
				searchWindowTop = 0, spixSearchWindowTop = 0,
				searchWindowBottom = 0, spixSearchWindowBottom = 0;
															// Coordinate della finestra di ricerca
	double r,c;
	double rEye,cEye;									// Indici accesso matrici
	double suppWeight;								// Peso locale del supporto variabile
	double dist = 0, minDist = -1;				// Calcolo della distanza euclidea nella ricerca del pixel vincente
	double dispWeight = sess->dispWeight;		// Peso feature "disparità calcolata in precedenza"
	double colorWeight = sess->colorWeight;	// Peso feature colore
	double searchEye = sess->searchEye;			// Dimensioni SearchEye
	SSom* source;										// SOM da cui è stato estratto il neurone
	SSom* target;										// SOM in cui ricercare il match
	
	winner.valid = 1;	// Risultato valido
		
	/* Nella ricerca del neurone vincente, la differenza tra due feature "disparità orizzontale" dovrà 
	 * essere resa comparabile con la differenza tra due feature colore, che ha un range di valori [0,255].
	 */
	double dispNormFactor = ((double)255/(double)(sess->maxDisp - sess->minDisp));
	
	// Imposta la SOM sorgente e quella destinazione della ricerca
	source = ((targetSom == LEFT_SOM) ? &(sess->rSSom) : &(sess->lSSom));
	target = ((targetSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));
	
	subPixSteps = ((sess->subPixGran) < 1.0 ? 2 : 1);
	/* Fasi di SubPixel estimation */
	for (subPixStep = 0; subPixStep < subPixSteps; subPixStep++) {

		if (subPixStep == 0) {	// Fase "intera"
		
			// Granularità iniziale
			subPixGran = 1.0;
		
			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			searchWindowLeft 		= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->minDisp) : (-sess->maxDisp)), 0, sess->IColumns - 2);
			searchWindowRight 	= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->maxDisp) : (-sess->minDisp)), 0, sess->IColumns - 2);
			searchWindowTop 		= double_trim(sel.row + sess->minVDisp, 0, sess->IRows - 1);
			searchWindowBottom 	= double_trim(sel.row + sess->maxVDisp, 0, sess->IRows - 1);

		} else {	// Fase "subpixel"

			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			spixSearchWindowLeft = double_trim(winner.col - subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowRight = double_trim(winner.col + subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowTop = double_trim(winner.row, 0, sess->IRows - 1);
			spixSearchWindowBottom = double_trim(winner.row, 0, sess->IRows - 1);
			searchWindowLeft 		= spixSearchWindowLeft;
			searchWindowRight 	= spixSearchWindowRight;
			searchWindowTop 		= spixSearchWindowTop;
			searchWindowBottom 	= spixSearchWindowBottom;
		
			// Imposta la granularità subpixel
			subPixGran = sess->subPixGran;
		}
		
		/* Confronta le feature del neurone vincente con quelle dei nodi nella finestra 
		 * di ricerca al fine di trovare il neurone vincente
		 */
		minDist = -1;
		for (r = searchWindowTop; r <= searchWindowBottom; r += 1.0) {
			for (c = searchWindowLeft; c <= searchWindowRight; c += subPixGran) {
				dist = 0.0;
			
				for (rEye = (sel.row - searchEye); rEye <= (sel.row + searchEye); rEye += 1.0) {
					for (cEye = (sel.col - searchEye); cEye <= (sel.col + searchEye); cEye += 1.0) {
				
						/* Controlla che le coordinate usate per eseguire i confronti non escano dalle
							matrici in memoria */
						if (rEye >= 0       			&& ((int)(rEye))   < sess->IRows          		&&
							 cEye >= 0       			&& ((int)(cEye)+1) < sess->IColumns       		&&
							 r+(rEye-sel.row) >= 0 	&& ((int)(r+(rEye-sel.row)))   < sess->IRows    &&
							 c+(cEye-sel.col) >= 0 	&& ((int)(c+(cEye-sel.col))+1) < sess->IColumns   ) {
							
							if (searchEye) {
								suppWeight = opt_str->support[thread]	[(int)(rEye - sel.row + searchEye)]
																				[(int)(cEye - sel.col + searchEye)];
							} else {
								suppWeight = 1.0;
							}
							
							dist += 	
								sqrt( ( POW2(	SPIX(target->rW, r+(rEye-sel.row), c+(cEye-sel.col)) - SPIX(source->rW, rEye, cEye)	) +
										  POW2(	SPIX(target->gW, r+(rEye-sel.row), c+(cEye-sel.col)) - SPIX(source->gW, rEye, cEye)	) +
										  POW2(	SPIX(target->bW, r+(rEye-sel.row), c+(cEye-sel.col)) - SPIX(source->bW, rEye, cEye)	)
										) * suppWeight * colorWeight
									   + POW2(	(	(sel.col + 1.0) - SPIX(target->vCorrW, r, c)
									   			) * dispNormFactor
									   ) * dispWeight
								);
						}
					}
				}
			
				if (dist < minDist || minDist == -1) {
					minDist = dist;
					winner.row = r;
					winner.col = c;
				}
			}
		}
	}
	
	return winner;
}

// Implementa la funzione di matching subpixel basata su distanza euclidea con compensazione di offset
matching_res z_euclidean_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread) {

	matching_res winner = {0, 0.0,0.0};			// Risultato matching one way
	double subPixGran = 1.0;						// Granularità della ricerca subpixel
	int subPixSteps, subPixStep;					// Fasi della valutazione subpixel
	double 	searchWindowLeft = 0, spixSearchWindowLeft = 0,
				searchWindowRight = 0, spixSearchWindowRight = 0,
				searchWindowTop = 0, spixSearchWindowTop = 0,
				searchWindowBottom = 0, spixSearchWindowBottom = 0;
															// Coordinate della finestra di ricerca
	double r,c;
	double rEye,cEye;									// Indici accesso matrici
	double suppWeight;								// Peso locale del supporto variabile
	rgb_mean srcMean, trgMean;						// Valori medi RGB
	double dist = 0, minDist = -1;				// Calcolo della distanza euclidea nella ricerca del pixel vincente
	double dispWeight = sess->dispWeight;		// Peso feature "disparità calcolata in precedenza"
	double colorWeight = sess->colorWeight;	// Peso feature colore
	double searchEye = sess->searchEye;			// Dimensioni SearchEye
	SSom* source;										// SOM da cui è stato estratto il neurone
	SSom* target;										// SOM in cui ricercare il match
	
	winner.valid = 1;	// Risultato valido
		
	/* Nella ricerca del neurone vincente, la differenza tra due feature "disparità orizzontale" dovrà 
	 * essere resa comparabile con la differenza tra due feature colore, che ha un range di valori [0,255].
	 */
	double dispNormFactor = ((double)255/(double)(sess->maxDisp - sess->minDisp));
	
	// Imposta la SOM sorgente e quella destinazione della ricerca
	source = ((targetSom == LEFT_SOM) ? &(sess->rSSom) : &(sess->lSSom));
	target = ((targetSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));
	
	subPixSteps = ((sess->subPixGran) < 1.0 ? 2 : 1);
	/* Fasi di SubPixel estimation */
	for (subPixStep = 0; subPixStep < subPixSteps; subPixStep++) {

		if (subPixStep == 0) {	// Fase "intera"
		
			// Granularità iniziale
			subPixGran = 1.0;
		
			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			searchWindowLeft 		= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->minDisp) : (-sess->maxDisp)), 0, sess->IColumns - 2);
			searchWindowRight 	= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->maxDisp) : (-sess->minDisp)), 0, sess->IColumns - 2);
			searchWindowTop 		= double_trim(sel.row + sess->minVDisp, 0, sess->IRows - 1);
			searchWindowBottom 	= double_trim(sel.row + sess->maxVDisp, 0, sess->IRows - 1);

		} else {	// Fase "subpixel"

			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			spixSearchWindowLeft = double_trim(winner.col - subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowRight = double_trim(winner.col + subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowTop = double_trim(winner.row, 0, sess->IRows - 1);
			spixSearchWindowBottom = double_trim(winner.row, 0, sess->IRows - 1);
			searchWindowLeft 		= spixSearchWindowLeft;
			searchWindowRight 	= spixSearchWindowRight;
			searchWindowTop 		= spixSearchWindowTop;
			searchWindowBottom 	= spixSearchWindowBottom;
		
			// Imposta la granularità subpixel
			subPixGran = sess->subPixGran;
		}

		// Media RGB del supporto sorgente
		srcMean = window_mean(sess, opt_str, reverse_som(targetSom), sel.row, sel.col, thread);
		
		/* Confronta le feature del neurone vincente con quelle dei nodi nella finestra 
		 * di ricerca al fine di trovare il neurone vincente
		 */
		minDist = -1;
		for (r = searchWindowTop; r <= searchWindowBottom; r += 1.0) {
			for (c = searchWindowLeft; c <= searchWindowRight; c += subPixGran) {
				dist = 0.0;
			
				// Media RGB del supporto destinazione
				trgMean = window_mean(sess, opt_str, targetSom, r, c, thread);

				for (rEye = (sel.row - searchEye); rEye <= (sel.row + searchEye); rEye += 1.0) {
					for (cEye = (sel.col - searchEye); cEye <= (sel.col + searchEye); cEye += 1.0) {
				
						/* Controlla che le coordinate usate per eseguire i confronti non escano dalle
							matrici in memoria */
						if (rEye >= 0       			&& ((int)(rEye))   < sess->IRows          		&&
							 cEye >= 0       			&& ((int)(cEye)+1) < sess->IColumns       		&&
							 r+(rEye-sel.row) >= 0 	&& ((int)(r+(rEye-sel.row)))   < sess->IRows    &&
							 c+(cEye-sel.col) >= 0 	&& ((int)(c+(cEye-sel.col))+1) < sess->IColumns   ) {
							
							if (searchEye) {
								suppWeight = opt_str->support[thread]	[(int)(rEye - sel.row + searchEye)]
																				[(int)(cEye - sel.col + searchEye)];
							} else {
								suppWeight = 1.0;
							}
							
							dist += 	
								sqrt( ( POW2(	(	SPIX(target->rW, r+(rEye-sel.row), c+(cEye-sel.col)) 	- trgMean.Rmv	)
													-( SPIX(source->rW, rEye, cEye) 									- srcMean.Rmv	) 
												) +
										  POW2(	(	SPIX(target->gW, r+(rEye-sel.row), c+(cEye-sel.col)) 	- trgMean.Gmv	)
													-( SPIX(source->gW, rEye, cEye)									- srcMean.Gmv	)
												) +
										  POW2(	(	SPIX(target->bW, r+(rEye-sel.row), c+(cEye-sel.col)) 	- trgMean.Bmv	)
										  			-( SPIX(source->bW, rEye, cEye)									- srcMean.Bmv	)
										  		)
										) * suppWeight * colorWeight
									   + POW2(	(	(sel.col + 1.0) - SPIX(target->vCorrW, r, c)
									   			) * dispNormFactor
									   ) * dispWeight
									 );
						}
					}
				}
			
				if (dist < minDist || minDist == -1) {
					minDist = dist;
					winner.row = r;
					winner.col = c;
				}
			}
		}
	}
	
	return winner;
}


// Implementa la funzione di matching subpixel basata su Normalized Cross-Correlation
matching_res ncc_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread) {

	matching_res winner = {0, 0.0,0.0};			// Risultato matching one way
	double subPixGran = 1.0;						// Granularità della ricerca subpixel
	int subPixSteps, subPixStep;					// Fasi della valutazione subpixel
	double 	searchWindowLeft = 0, spixSearchWindowLeft = 0,
				searchWindowRight = 0, spixSearchWindowRight = 0,
				searchWindowTop = 0, spixSearchWindowTop = 0,
				searchWindowBottom = 0, spixSearchWindowBottom = 0;
															// Coordinate della finestra di ricerca
	double r,c;
	double rEye,cEye;									// Indici accesso matrici
	double suppWeight;								// Peso locale del supporto variabile
	double corr_sum[4], sq_l_sum[4], sq_r_sum[4];
	double corr, maxCorr;							// Variabili per il calcolo della NCC nella ricerca del pixel vincente
	double dispWeight = sess->dispWeight;		// Peso feature "disparità calcolata in precedenza"
	double colorWeight = sess->colorWeight;	// Peso feature colore
	double searchEye = sess->searchEye;			// Dimensioni SearchEye
	SSom* source;										// SOM da cui è stato estratto il neurone
	SSom* target;										// SOM in cui ricercare il match

	
	winner.valid = 1;	// Risultato valido
		
	/* La differenza tra due feature "disparità orizzontale" dovrà essere resa comparabile con 
		il valore di correlazione */
	double dispNormFactor = ((double)1/(double)(sess->maxDisp - sess->minDisp));
	
	// Imposta la SOM sorgente e quella destinazione della ricerca
	source = ((targetSom == LEFT_SOM) ? &(sess->rSSom) : &(sess->lSSom));
	target = ((targetSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));

	subPixSteps = ((sess->subPixGran) < 1.0 ? 2 : 1);
	/* Fasi di SubPixel estimation */
	for (subPixStep = 0; subPixStep < subPixSteps; subPixStep++) {

		if (subPixStep == 0) {	// Fase "intera"
		
			// Granularità iniziale
			subPixGran = 1.0;
		
			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			searchWindowLeft 		= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->minDisp) : (-sess->maxDisp)), 0, sess->IColumns - 2);
			searchWindowRight 	= double_trim(sel.col + ((targetSom == LEFT_SOM) ? (sess->maxDisp) : (-sess->minDisp)), 0, sess->IColumns - 2);
			searchWindowTop 		= double_trim(sel.row + sess->minVDisp, 0, sess->IRows - 1);
			searchWindowBottom 	= double_trim(sel.row + sess->maxVDisp, 0, sess->IRows - 1);

		} else {	// Fase "subpixel"

			// Ricava le coordinate della finestra di ricerca (linea di pixel)
			spixSearchWindowLeft = double_trim(winner.col - subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowRight = double_trim(winner.col + subPixGran, searchWindowLeft, searchWindowRight);
			spixSearchWindowTop = double_trim(winner.row, 0, sess->IRows - 1);
			spixSearchWindowBottom = double_trim(winner.row, 0, sess->IRows - 1);
			searchWindowLeft 		= spixSearchWindowLeft;
			searchWindowRight 	= spixSearchWindowRight;
			searchWindowTop 		= spixSearchWindowTop;
			searchWindowBottom 	= spixSearchWindowBottom;
		
			// Imposta la granularità subpixel
			subPixGran = sess->subPixGran;
		}
		
		/* Confronta le feature del neurone vincente con quelle dei nodi nella finestra 
		 * di ricerca al fine di trovare il neurone vincente
		 */
		maxCorr = -1;
		for (r = searchWindowTop; r <= searchWindowBottom; r += 1.0) {
			for (c = searchWindowLeft; c <= searchWindowRight; c += subPixGran) {
				corr_sum[0] = 0.0; corr_sum[1] = 0.0; corr_sum[2] = 0.0; corr_sum[3] = 0.0;
				sq_l_sum[0] = 0.0; sq_l_sum[1] = 0.0; sq_l_sum[2] = 0.0; sq_l_sum[3] = 0.0;
				sq_r_sum[0] = 0.0; sq_r_sum[1] = 0.0; sq_r_sum[2] = 0.0; sq_r_sum[3] = 0.0;
				
				for (rEye = (sel.row - searchEye); rEye <= (sel.row + searchEye); rEye += 1.0) {
					for (cEye = (sel.col - searchEye); cEye <= (sel.col + searchEye); cEye += 1.0) {
				
						/* Controlla che le coordinate usate per eseguire i confronti non escano dalle
							matrici in memoria */
						if (rEye >= 0       			&& ((int)(rEye))   < sess->IRows          		&&
							 cEye >= 0       			&& ((int)(cEye)+1) < sess->IColumns       		&&
							 r+(rEye-sel.row) >= 0 	&& ((int)(r+(rEye-sel.row)))   < sess->IRows    &&
							 c+(cEye-sel.col) >= 0 	&& ((int)(c+(cEye-sel.col))+1) < sess->IColumns   ) {
							
							if (searchEye) {
								suppWeight = opt_str->support[thread]	[(int)(rEye - sel.row + searchEye)]
																				[(int)(cEye - sel.col + searchEye)];
							} else {
								suppWeight = 1.0;
							}
							
							suppWeight = 1.0;
							
							corr_sum[0] += (SPIX(target->rW, r+(rEye-sel.row), c+(cEye-sel.col)) * SPIX(source->rW, rEye, cEye)) * suppWeight;
							corr_sum[1] += (SPIX(target->gW, r+(rEye-sel.row), c+(cEye-sel.col)) * SPIX(source->gW, rEye, cEye)) * suppWeight;
							corr_sum[2] += (SPIX(target->bW, r+(rEye-sel.row), c+(cEye-sel.col)) * SPIX(source->bW, rEye, cEye)) * suppWeight;
							
							sq_l_sum[0] += POW2(SPIX(target->rW, r+(rEye-sel.row), c+(cEye-sel.col)) * suppWeight);
							sq_l_sum[1] += POW2(SPIX(target->gW, r+(rEye-sel.row), c+(cEye-sel.col)) * suppWeight);
							sq_l_sum[2] += POW2(SPIX(target->bW, r+(rEye-sel.row), c+(cEye-sel.col)) * suppWeight);
							
							sq_r_sum[0] += POW2(SPIX(source->rW, rEye, cEye) * suppWeight);
							sq_r_sum[1] += POW2(SPIX(source->gW, rEye, cEye) * suppWeight);
							sq_r_sum[2] += POW2(SPIX(source->bW, rEye, cEye) * suppWeight);

						}
					}
				}
				
				corr = 	(	corr_sum[0] / (sqrt(sq_l_sum[0]) * sqrt(sq_r_sum[0])) + 
								corr_sum[1] / (sqrt(sq_l_sum[1]) * sqrt(sq_r_sum[1])) + 
								corr_sum[2] / (sqrt(sq_l_sum[2]) * sqrt(sq_r_sum[2])) 
							) * colorWeight +
							(1.0	-	abs(	((sel.col + 1.0) - SPIX(target->vCorrW, r, c))
										) * dispNormFactor
							) * dispWeight;
			
				if (corr > maxCorr || maxCorr == -1) {
					maxCorr = corr;
					winner.row = r;
					winner.col = c;
				}
			}
		}
	}
	
	return winner;
}

// Calcola il valore medio (pesato) delle intensità RGB nel supporto Search Eye
rgb_mean window_mean(stereo_session* sess, optimization* opt_str, som_dir sourceSom, double row, double column, int thread) {
	double rEye,cEye;								// Indici accesso matrici
	double pCount, supp;
	rgb_mean mean;									// Variabili per il calcolo del valore medio
	double searchEye = sess->searchEye;		// Dimensioni SearchEye
	SSom* source;									// SOM su cui eseguire il calcolo

	// Imposta la SOM su cui eseguire il calcolo
	source = ((sourceSom == LEFT_SOM) ? &(sess->lSSom) : &(sess->rSSom));

	pCount = 0;
	mean.Rmv = 0; mean.Gmv = 0; mean.Bmv = 0;

	for (rEye = (row - searchEye); rEye <= (row + searchEye); rEye += 1.0) {
		for (cEye = (column - searchEye); cEye <= (column + searchEye); cEye += 1.0) {
	
			/* Controlla che le coordinate usate per eseguire i confronti non escano dalle
				matrici in memoria */
			if (rEye >= 0 && ((int)(rEye))   < sess->IRows		&&
				 cEye >= 0 && ((int)(cEye)+1) < sess->IColumns		) {
				 	
			 	// Calcolo numeratore del valore atteso
			 	supp = opt_str->support[thread]	[(int)(rEye - row + searchEye)]
														[(int)(cEye - column + searchEye)];
				mean.Rmv += SPIX(source->rW,(int)rEye,(int)cEye) * supp;
				mean.Gmv += SPIX(source->gW,(int)rEye,(int)cEye) * supp;
				mean.Bmv += SPIX(source->bW,(int)rEye,(int)cEye) * supp;
					
				pCount += supp;
			}
		}
	}
	mean.Rmv /= pCount;
	mean.Gmv /= pCount;
	mean.Bmv /= pCount;
	
	return mean;
}

