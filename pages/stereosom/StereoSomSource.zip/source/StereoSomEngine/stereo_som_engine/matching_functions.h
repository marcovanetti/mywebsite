/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

// Valori medi delle intensita'� RGB
typedef struct {
	double Rmv;
	double Gmv;
	double Bmv;
} rgb_mean;
 
 // Implementa la funzione di matching subpixel basata su distanza euclidea
matching_res euclidean_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread);

// Implementa la funzione di matching subpixel basata su distanza euclidea con compensazione di offset
matching_res z_euclidean_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread);

// Implementa la funzione di matching subpixel basata su Normalized Cross-Correlation
matching_res ncc_spix_matching(stereo_session* sess, optimization* opt_str, som_dir targetSom, select_res sel, int thread);

// Calcola il valore medio (pesato) delle intensità RGB nel supporto Search Eye
rgb_mean window_mean(stereo_session* sess, optimization* opt_str, som_dir sourceSom, double row, double column, int thread);

