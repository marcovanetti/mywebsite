/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#ifndef _DLL_H_
#define _DLL_H_

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */

DLLIMPORT void RunEngine(stereo_session* session);

DLLIMPORT long int ArrayTest1();
DLLIMPORT long int ArrayTest2(double* array);
DLLIMPORT long int ArrayTest2f(float* array);
DLLIMPORT long int ArrayTest3(double* array);

#endif /* _DLL_H_ */

// StereoSom session Marshalling
void MarshalSession(stereo_session* session);

// StereoSom session UnMarshalling
void UnmarshalSession(stereo_session* session);

// Wrap a monodimensional array into a bidimensional array
int** iMonodArr2BidArrWrap(int* monodArray, int rows, int columns);

// Unwrap a bidimensional array into a monodimensional array
int* iBidArr2MonodArrWrap(int** bidArray);

// Wrap a monodimensional array into a bidimensional array
double** dMonodArr2BidArrWrap(double* monodArray, int rows, int columns);

// Unwrap a bidimensional array into a monodimensional array
double* dBidArr2MonodArrWrap(double** bidArray);
