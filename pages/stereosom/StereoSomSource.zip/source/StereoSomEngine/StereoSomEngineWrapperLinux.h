/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

void RunEngine(stereo_session* session);

long int ArrayTest1();
long int ArrayTest2(double* array);
long int ArrayTest2f(float* array);
long int ArrayTest3(double* array);

// StereoSom session Marshalling
void MarshalSession(stereo_session* session);

// StereoSom session UnMarshalling
void UnmarshalSession(stereo_session* session);

// Wrap a monodimensional array into a bidimensional array
int** iMonodArr2BidArrWrap(int* monodArray, int rows, int columns);

// Unwrap a bidimensional array into a monodimensional array
int* iBidArr2MonodArrWrap(int** bidArray);

// Wrap a monodimensional array into a bidimensional array
double** dMonodArr2BidArrWrap(double* monodArray, int rows, int columns);

// Unwrap a bidimensional array into a monodimensional array
double* dBidArr2MonodArrWrap(double** bidArray);
