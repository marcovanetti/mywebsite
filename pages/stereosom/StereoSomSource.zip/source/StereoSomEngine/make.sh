#! /bin/bash
gcc -fPIC -mtune=i686 -msse3 -c stereo_som_engine/*.c StereoSomEngineWrapperLinux.c
gcc -shared -Wl -o libStereoSomEngine.so *.o
rm *.o
mv libStereoSomEngine.so ../Libraries/
