long int Timer();

long int array_test1();
long int array_test2(double* managedArray);
long int array_test2f(float* managedArray);
long int array_test3(double* managedArray);
int main();
