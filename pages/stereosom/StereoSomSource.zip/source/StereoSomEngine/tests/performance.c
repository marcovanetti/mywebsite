#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "performance.h"

long int Timer()
{
    double timer;
    timer = (double)clock() / CLOCKS_PER_SEC;
    return (long int)(timer * 1000);
}

#define ASIZE 10000000
#define FAKE_ITERATIONS 50

long int array_test1()
{
    long int begin = Timer();
    
    double* array;
    array = (double*)malloc(ASIZE * sizeof(double));
    
    int i, j;
    // Edit unmanaged memory
    for (j = 0; j < FAKE_ITERATIONS; j++)
        for (i = 0; i < ASIZE; i++)
            array[i] = ((double)j)/i;
    
    free((void*)array);
    
    long int end = Timer();
    return end-begin;
}

long int array_test2(double* managedArray)
{
    long int begin = Timer();

    int i, j;
    // Edit managed memory
    for (j = 0; j < FAKE_ITERATIONS; j++)
        for (i = 0; i < ASIZE; i++)
            managedArray[i] = ((double)j)/i;
    
    long int end = Timer();
    return end-begin;
}

long int array_test2f(float* managedArray)
{
    long int begin = Timer();

    int i, j;
    // Edit managed memory
    for (j = 0; j < FAKE_ITERATIONS; j++)
        for (i = 0; i < ASIZE; i++)
            managedArray[i] = ((float)j)/i;
    
    long int end = Timer();
    return end-begin;
}

long int array_test3(double* managedArray)
{
    long int begin = Timer();
    
    double* array;
    array = (double*)malloc(ASIZE * sizeof(double));
    
    // Copy from managed to unmanaged
    int i, j;
    for (i = 0; i < ASIZE; i++)
        array[i] = managedArray[i];
    
    // Edit unmanaged memory
    for (j = 0; j < FAKE_ITERATIONS; j++)
        for (i = 0; i < ASIZE; i++)
            array[i] = ((double)j)/i;

    // Copy from unmanaged to managed
    for (i = 0; i < ASIZE; i++)
        managedArray[i] = array[i];
    
    free((void*)array);
    
    long int end = Timer();
    return end-begin;
}

int main(void) {
    long int time1 = array_test1();
    
    printf("Test1 required %f seconds", (double)time1/1000);
}
