/* Copyright (C) 2008-2009 Marco Vanetti
 *
 * Author: Marco Vanetti    <marco.vanetti@gmail.com>
 * Last update: 28-03-2009
 */

#include <stdio.h>
#include <stdlib.h>
#include "stereo_som_engine/ssom.h"
#include "tests/performance.h"
#include "StereoSomEngineWrapperLinux.h"

void RunEngine(stereo_session* session)
{
    MarshalSession(session);
    stereo_som_engine(session);
    UnmarshalSession(session);
}

long int ArrayTest1()
{
    return array_test1();
}

long int ArrayTest2(double* array)
{
    return array_test2(array);
}

long int ArrayTest2f(float* array)
{
    return array_test2f(array);
}

long int ArrayTest3(double* array)
{
    return array_test3(array);
}

// StereoSom session Marshalling
void MarshalSession(stereo_session* session)
{  
    int columns = session->IColumns;
    int rows = session->IRows;
    
    // Left SOM
    session->lSSom.rW =                dMonodArr2BidArrWrap((double*)session->lSSom.rW, rows, columns);
	session->lSSom.gW =                dMonodArr2BidArrWrap((double*)session->lSSom.gW, rows, columns);
	session->lSSom.bW =                dMonodArr2BidArrWrap((double*)session->lSSom.bW, rows, columns);
	session->lSSom.vCorrW =            dMonodArr2BidArrWrap((double*)session->lSSom.vCorrW, rows, columns);
	session->lSSom.matchingErr =       iMonodArr2BidArrWrap((int*)session->lSSom.matchingErr, rows, columns); 
    session->lSSom.consistenceErr =    iMonodArr2BidArrWrap((int*)session->lSSom.consistenceErr, rows, columns);
    session->lSSom.expectedDisp =      dMonodArr2BidArrWrap((double*)session->lSSom.expectedDisp, rows, columns);
    // Right SOM
    session->rSSom.rW =                dMonodArr2BidArrWrap((double*)session->rSSom.rW, rows, columns);
	session->rSSom.gW =                dMonodArr2BidArrWrap((double*)session->rSSom.gW, rows, columns);
	session->rSSom.bW =                dMonodArr2BidArrWrap((double*)session->rSSom.bW, rows, columns);
	session->rSSom.vCorrW =            dMonodArr2BidArrWrap((double*)session->rSSom.vCorrW, rows, columns);
	session->rSSom.matchingErr =       iMonodArr2BidArrWrap((int*)session->rSSom.matchingErr, rows, columns); 
    session->rSSom.consistenceErr =    iMonodArr2BidArrWrap((int*)session->rSSom.consistenceErr, rows, columns);
    session->rSSom.expectedDisp =      dMonodArr2BidArrWrap((double*)session->rSSom.expectedDisp, rows, columns);
}

// StereoSom session UnMarshalling
void UnmarshalSession(stereo_session* session)
{
    // Left SOM
    session->lSSom.rW =               (double**)dBidArr2MonodArrWrap(session->lSSom.rW);
	session->lSSom.gW =               (double**)dBidArr2MonodArrWrap(session->lSSom.gW);
	session->lSSom.bW =               (double**)dBidArr2MonodArrWrap(session->lSSom.bW);
	session->lSSom.vCorrW =           (double**)dBidArr2MonodArrWrap(session->lSSom.vCorrW);
	session->lSSom.matchingErr =      (int**)iBidArr2MonodArrWrap(session->lSSom.matchingErr);
    session->lSSom.consistenceErr =   (int**)iBidArr2MonodArrWrap(session->lSSom.consistenceErr);
    session->lSSom.expectedDisp =     (double**)dBidArr2MonodArrWrap(session->lSSom.expectedDisp);
    // Right SOM
    session->rSSom.rW =               (double**)dBidArr2MonodArrWrap(session->rSSom.rW);
	session->rSSom.gW =               (double**)dBidArr2MonodArrWrap(session->rSSom.gW);
	session->rSSom.bW =               (double**)dBidArr2MonodArrWrap(session->rSSom.bW);
	session->rSSom.vCorrW =           (double**)dBidArr2MonodArrWrap(session->rSSom.vCorrW);
	session->rSSom.matchingErr =      (int**)iBidArr2MonodArrWrap(session->rSSom.matchingErr);
    session->rSSom.consistenceErr =   (int**)iBidArr2MonodArrWrap(session->rSSom.consistenceErr);
    session->rSSom.expectedDisp =     (double**)dBidArr2MonodArrWrap(session->rSSom.expectedDisp);
}

// Wrap a monodimensional array into a bidimensional array
int** iMonodArr2BidArrWrap(int* monodArray, int rows, int columns)
{
    int** bidArray;
    
    bidArray = (int**)malloc(rows * sizeof(int*));
    
    // Bidimensional array redirection
    int i;
    for (i = 0; i < rows; i++)
    {
        bidArray[i] = (monodArray + i*columns);
    }
    
    return bidArray;
}

// Unwrap a bidimensional array into a monodimensional array
int* iBidArr2MonodArrWrap(int** bidArray)
{
    int* monodArray = bidArray[0];
    
    // Free memory used for "bidimensional poiters"
    free ((void*)bidArray);
    
    return monodArray;
}

// Wrap a monodimensional array into a bidimensional array
double** dMonodArr2BidArrWrap(double* monodArray, int rows, int columns)
{
    double** bidArray;
    
    bidArray = (double**)malloc(rows * sizeof(double*));
    
    // Bidimensional array redirection
    int i;
    for (i = 0; i < rows; i++)
    {
        bidArray[i] = (monodArray + i*columns);
    }
    
    return bidArray;
}

// Unwrap a bidimensional array into a monodimensional array
double* dBidArr2MonodArrWrap(double** bidArray)
{
    double* monodArray = bidArray[0];
    
    // Free memory used for "bidimensional poiters"
    free ((void*)bidArray);
    
    return monodArray;
}
