#region .

// ReSharper disable InconsistentNaming

#endregion

using System;
using System.Runtime.InteropServices;
using NUnit.Framework;
using StereoSom.Utilities;

namespace StereoSom.Tests.Integration
{
    [TestFixture]
    [Ignore("Performance test...")]
    public class UnmanagedMemoryTest
    {
        #region DllImport
        [DllImport("StereoSomEngine")]
        [return: MarshalAs(UnmanagedType.I8)]
        public static extern long ArrayTest1();

        [DllImport("StereoSomEngine")]
        [return: MarshalAs(UnmanagedType.I8)]
        public static extern long ArrayTest2(IntPtr doubleP);

        [DllImport("StereoSomEngine")]
        [return: MarshalAs(UnmanagedType.I8)]
        public static extern long ArrayTest2f(IntPtr doubleP);

        [DllImport("StereoSomEngine")]
        [return: MarshalAs(UnmanagedType.I8)]
        public static extern long ArrayTest3(IntPtr doubleP);
        #endregion

        private int _tests;
        private int _arraySize;

        [SetUp]
        public void Setup()
        {
            _tests = 3;
            _arraySize = 10000000;
        }

        [Test]
        public void Performance_ArrayTest1()
        {
            // Dll read and modify internal allocated memory
            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest1(), timer);
                GC.Collect();
            }

            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

        [Test]
        public void Performance_ArrayTest2()
        {
            // Dll read and modify external allocated managed (pinned) memory
            var myArray = new double[_arraySize];
            
            var handle = GCHandle.Alloc(myArray, GCHandleType.Pinned);
            var myArrayPtr = handle.AddrOfPinnedObject();

            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest2(myArrayPtr), timer);
                GC.Collect();
            }

            handle.Free();
            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

        [Test]
        public void Performance_ArrayTest3()
        {
            // Dll read and modify external allocated managed (pinned) memory
            var myArray = new double[_arraySize];

            var handle = GCHandle.Alloc(myArray, GCHandleType.Pinned);
            var myArrayPtr = handle.AddrOfPinnedObject(); 
            
            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest3(myArrayPtr), timer);
                GC.Collect();
            }

            handle.Free();
            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

        [Test]
        public void Performance_PinnedArrayTest1()
        {
            // Dll read and modify external allocated managed (pinned) memory
            var myArray = new PinnedArray<double>(_arraySize);

            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest2(myArray.Address), timer);
                GC.Collect();
            }

            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

        [Test]
        public void Performance_PinnedArrayTest1Float()
        {
            // Dll read and modify external allocated managed (pinned) memory
            var myArray = new PinnedArray<float>(_arraySize);

            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest2f(myArray.Address), timer);
                GC.Collect();
            }

            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

        [Test]
        public void Performance_PinnedArrayTest2()
        {
            // Dll read and modify external allocated managed (pinned) memory
            var myArray = new PinnedArray<double>(_arraySize);

            var timer = 0L;
            for (var i = 0; i < _tests; i++)
            {
                timer = Math.Max(ArrayTest3(myArray.Address), timer);
                GC.Collect();
            }

            Console.WriteLine("Max required time: {0}", (double)timer / 1000);
        }

    }
}

#region .

// ReSharper restore InconsistentNaming

#endregion