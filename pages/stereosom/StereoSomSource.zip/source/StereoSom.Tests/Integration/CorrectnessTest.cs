#region .

// ReSharper disable InconsistentNaming

#endregion

using System;
using System.IO;
using ArteStereo.Images;
using NUnit.Framework;
using StereoSom.Engine;
using StereoSom.Utilities;

namespace StereoSom.Tests.Integration
{
    [TestFixture]
    [Ignore("Correctness/Performance test...")]
    public class CorrectnessTest
    {
        /// <summary>
        /// Number of test to do
        /// </summary>
        const int _testNumber = 3;

        private const string _imagesDirPath = "../../TestFiles/Images/";

        [Test]
        public void StereoSomEngine_CorrectnessDefaultParameters()
        {
            // Given
            var leftImagePath = Path.Combine(_imagesDirPath, "tsukuba_l.png");
            var rightImagePath = Path.Combine(_imagesDirPath, "tsukuba_r.png");
            var expectedLeftDispImagePath = Path.Combine(_imagesDirPath, "def_l_tsukuba_disp.png");
            var expectedRightDispImagePath = Path.Combine(_imagesDirPath, "def_r_tsukuba_disp.png");
            const int imageWidth = 384;
            const int imageHeight = 288;
            var parameters = new StereoSomParameters(imageWidth, imageHeight)
                                 {
                                     MaxDisp = 15,
                                     ConsistenceCheckStrategy = ConsistenceCheckStrategies.Nothing,
                                     RandomSeed = 84,
                                 };

            // Execute correctness/performance test
            StereoSomEngine_CorrectnessTest(leftImagePath, rightImagePath, parameters, expectedLeftDispImagePath, expectedRightDispImagePath);
        }

        [Test]
        public void StereoSomEngine_CorrectnessBidirectionalCheck()
        {
            // Given
            var leftImagePath = Path.Combine(_imagesDirPath, "tsukuba_l.png");
            var rightImagePath = Path.Combine(_imagesDirPath, "tsukuba_r.png");
            var expectedLeftDispImagePath = Path.Combine(_imagesDirPath, "def_bid_l_tsukuba_disp.png");
            var expectedRightDispImagePath = Path.Combine(_imagesDirPath, "def_bid_r_tsukuba_disp.png");
            const int imageWidth = 384;
            const int imageHeight = 288;
            var parameters = new StereoSomParameters(imageWidth, imageHeight)
                                 {
                                     MaxDisp = 15,
                                     ConsistenceCheckStrategy = ConsistenceCheckStrategies.BidirectionalCheck,
                                     RandomSeed = 84,
                                 };

            // Execute correctness/performance test
            StereoSomEngine_CorrectnessTest(leftImagePath, rightImagePath, parameters, expectedLeftDispImagePath, expectedRightDispImagePath);
        }

        [Test]
        public void StereoSomEngine_CorrectnessColorBasedLearningFunction()
        {
            // Given
            var leftImagePath = Path.Combine(_imagesDirPath, "tsukuba_l.png");
            var rightImagePath = Path.Combine(_imagesDirPath, "tsukuba_r.png");
            var expectedLeftDispImagePath = Path.Combine(_imagesDirPath, "def_gterm_bid_l_tsukuba_disp.png");
            var expectedRightDispImagePath = Path.Combine(_imagesDirPath, "def_gterm_bid_r_tsukuba_disp.png");
            const int imageWidth = 384;
            const int imageHeight = 288;
            var parameters = new StereoSomParameters(imageWidth, imageHeight)
                                 {
                                     MaxDisp = 15,
                                     ConsistenceCheckStrategy = ConsistenceCheckStrategies.BidirectionalCheck,
                                     RandomSeed = 84,
                                     LearningFunction = LearningFunctions.ColorDriven,
                                     ColorDrivenLearningFunctionVariance = 80,
                                     LearningFunctionSize = 10,
                                     LearningFunctionSpreadMax = 0.8,
                                     LearningFunctionSpreadMin = 0.1,
                                 };

            // Execute correctness/performance test
            StereoSomEngine_CorrectnessTest(leftImagePath, rightImagePath, parameters, expectedLeftDispImagePath, expectedRightDispImagePath);
        }

        private static void StereoSomEngine_CorrectnessTest(string leftImagePath, string rightImagePath, StereoSomParameters parameters, string expectedLeftDispImagePath, string expectedRightDispImagePath)
        {
            var initExecutionTime = 0d;
            var coreExecutionTime = 0d;
            var extractionExecutionTime = 0d;
            var somWeightUtils = new SomWeightsUtils();

            // When
            for (var testIt = 0; testIt < _testNumber; testIt++)
            {
                var initTic = DateTime.Now;
                using (var leftImage = new TruecolorImage(leftImagePath))
                using (var rightImage = new TruecolorImage(rightImagePath))
                {
                    var stereoSomEngine = new StereoSomEngine(leftImage, rightImage);

                    initExecutionTime += (DateTime.Now - initTic).TotalSeconds;

                    stereoSomEngine.Parameters = parameters;

                    var coreTic = DateTime.Now;
                    stereoSomEngine.Execute();
                    coreExecutionTime += (DateTime.Now - coreTic).TotalSeconds;


                    var extractionTic = DateTime.Now;

                    // Then
                    using (var expectedLeftDispImage = new TruecolorImage(expectedLeftDispImagePath))
                    using (var expectedRightDispImage = new TruecolorImage(expectedRightDispImagePath))
                    {
                        var leftDisparityMap = new TruecolorImage(leftImage.Width, leftImage.Height);
                        somWeightUtils.DeserializeImage(stereoSomEngine.LeftDisparityVector, 16, 0, leftDisparityMap);

                        var rightDisparityMap = new TruecolorImage(rightImage.Width, rightImage.Height);
                        somWeightUtils.DeserializeImage(stereoSomEngine.RightDisparityVector, 16, 0, rightDisparityMap);

                        extractionExecutionTime += (DateTime.Now - extractionTic).TotalSeconds;

                        Assert.That(expectedLeftDispImage.Equals(leftDisparityMap));
                        Assert.That(expectedRightDispImage.Equals(rightDisparityMap));
                    }
                }
            }

            Console.WriteLine("Initialization mean required time: {0}", initExecutionTime / _testNumber);
            Console.WriteLine("Core mean required time: {0}", coreExecutionTime / _testNumber);
            Console.WriteLine("Disparity extraction mean required time: {0}", extractionExecutionTime / _testNumber);
        }
    }
}

#region .

// ReSharper restore InconsistentNaming

#endregion