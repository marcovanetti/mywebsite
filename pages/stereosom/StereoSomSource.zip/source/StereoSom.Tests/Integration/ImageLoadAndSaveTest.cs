#region .

// ReSharper disable InconsistentNaming

#endregion

using System.IO;
using ArteStereo.Images;
using Emgu.CV.Structure;
using NUnit.Framework;

namespace StereoSom.Tests.Integration
{
    [TestFixture]
    public class ImageLoadAndSaveTest
    {
        private TruecolorImage _color24bppImage;
        private TruecolorImage _gray24bppImage;

        private const string s_imageDirPath = "../../TestFiles/Images/";
        private string _pngColor24bppImagePath;
        private string _pngGray24bppImagePath;
        private string _tiffRgb32bppImagePath;
        //private string _tiffFloat32bppImagePath;
        private string _tiffGray8bppImagePath;
        private string _pngGray32bppImagePath;
        private string _pngGray8bppImagePath;

        [SetUp]
        public void SetUp()
        {
            _pngColor24bppImagePath = Path.Combine(s_imageDirPath, "RGBImage1.png");
            _pngGray24bppImagePath = Path.Combine(s_imageDirPath, "GrayImage1.png");

            _tiffRgb32bppImagePath = Path.Combine(s_imageDirPath, "RGBImage1.tif");
            //_tiffFloat32bppImagePath = Path.Combine(s_imageDirPath, "FloatImage1.tif");
            _tiffGray8bppImagePath = Path.Combine(s_imageDirPath, "GrayImage1.tif");

            _pngGray32bppImagePath = Path.Combine(s_imageDirPath, "GrayImage2.png");
            _pngGray8bppImagePath = Path.Combine(s_imageDirPath, "GrayImage3.png");

            #region _color24bppImage initialization
            _color24bppImage = new TruecolorImage(4, 3);
            // Pixel row 1
            _color24bppImage[0, 0] = new Bgr(000, 000, 000);
            _color24bppImage[0, 1] = new Bgr(000, 000, 255);
            _color24bppImage[0, 2] = new Bgr(000, 255, 000);
            _color24bppImage[0, 3] = new Bgr(255, 000, 000);
            // Pixel row 2
            _color24bppImage[1, 0] = new Bgr(128, 128, 128);
            _color24bppImage[1, 1] = new Bgr(128, 128, 128);
            _color24bppImage[1, 2] = new Bgr(128, 128, 128);
            _color24bppImage[1, 3] = new Bgr(255, 255, 255);
            // Pixel row 3
            _color24bppImage[2, 0] = new Bgr(084, 012, 026);
            _color24bppImage[2, 1] = new Bgr(084, 012, 026);
            _color24bppImage[2, 2] = new Bgr(084, 012, 026);
            _color24bppImage[2, 3] = new Bgr(255, 255, 255);
            #endregion

            #region _gray24bppImage initialization
            _gray24bppImage = new TruecolorImage(4, 3);
            // Pixel row 1
            _gray24bppImage[0, 0] = new Bgr(000, 000, 000);
            _gray24bppImage[0, 1] = new Bgr(076, 076, 076);
            _gray24bppImage[0, 2] = new Bgr(149, 149, 149);
            _gray24bppImage[0, 3] = new Bgr(029, 029, 029);
            // Pixel row 2
            _gray24bppImage[1, 0] = new Bgr(128, 128, 128);
            _gray24bppImage[1, 1] = new Bgr(128, 128, 128);
            _gray24bppImage[1, 2] = new Bgr(128, 128, 128);
            _gray24bppImage[1, 3] = new Bgr(255, 255, 255);
            // Pixel row 3
            _gray24bppImage[2, 0] = new Bgr(024, 024, 024);
            _gray24bppImage[2, 1] = new Bgr(024, 024, 024);
            _gray24bppImage[2, 2] = new Bgr(024, 024, 024);
            _gray24bppImage[2, 3] = new Bgr(255, 255, 255);
            #endregion
        }

        [TearDown]
        public void TearDown()
        {
            _color24bppImage.Dispose();
            _gray24bppImage.Dispose();
        }

        [Test]
        public void Image24bppLoad_Test()
        {
            // When
            using (var loadedRgb24bppImage = new TruecolorImage(_pngColor24bppImagePath))
            using (var loadedGray24bppImage = new TruecolorImage(_pngGray24bppImagePath))
            {
                // Then
                Assert.That(loadedRgb24bppImage.NumberOfChannels, Is.EqualTo(3));
                Assert.That(loadedGray24bppImage.NumberOfChannels, Is.EqualTo(3));

                Assert.That(loadedRgb24bppImage.Equals(_color24bppImage), "Color rgb 24bpp image doesn't corrisponde after load");
                Assert.That(_color24bppImage.Equals(loadedRgb24bppImage), "Color rgb 24bpp image doesn't corrisponde after load");

                Assert.That(loadedGray24bppImage.Equals(_gray24bppImage), "Gray rgb 24bpp image doesn't corrisponde after load");
                Assert.That(_gray24bppImage.Equals(loadedGray24bppImage), "Gray rgb 24bpp image doesn't corrisponde after load");
            }
        }

        [Test]
        public void ImageNot24bppLoad_Test()
        {
            // When
            using (var loaded32bppImage = new TruecolorImage(_pngGray32bppImagePath))
            using (var loaded8bppImage = new TruecolorImage(_pngGray8bppImagePath))
            using (var loadedColorTiff32bppImage = new TruecolorImage(_tiffRgb32bppImagePath))
            //using (var loadedFloatTiff32bppImage = new TruecolorImage(_tiffFloat32bppImagePath))
            using (var loadedGrayTiff8bppImage = new TruecolorImage(_tiffGray8bppImagePath))
            {
                // Then
                Assert.That(loaded32bppImage.NumberOfChannels, Is.EqualTo(3));
                Assert.That(loaded8bppImage.NumberOfChannels, Is.EqualTo(3));
                Assert.That(loadedColorTiff32bppImage.NumberOfChannels, Is.EqualTo(3));
                //Assert.That(loadedFloatTiff32bppImage.NumberOfChannels, Is.EqualTo(3));
                Assert.That(loadedGrayTiff8bppImage.NumberOfChannels, Is.EqualTo(3));
            }
        }

        [Test]
        public void Image24bppSave_Test()
        {
            // Given
            const string pngColor24bppNewImagePath = "Color24bppNewImage.png";
            const string pngGray24bppNewImagePath = "Gray24bppNewImage.png";
            const string tiffRgb32bppNewImagePath = "Rgb32bppNewImage.tif";
            const string tiffGray8bppNewImagePath = "Gray8bppNewImage.tif";

            // When
            _color24bppImage.Save(pngColor24bppNewImagePath);
            _gray24bppImage.Save(pngGray24bppNewImagePath);
            _color24bppImage.Save(tiffRgb32bppNewImagePath);
            _gray24bppImage.Save(tiffGray8bppNewImagePath);

            // Then
            try
            {
                using (var reLoadedColor24bppImage = new TruecolorImage(pngColor24bppNewImagePath))
                using (var reLoadedGray24bppImage = new TruecolorImage(pngGray24bppNewImagePath))
                using (var reLoadedTiffRgb32bppImage = new TruecolorImage(tiffRgb32bppNewImagePath))
                using (var reLoadedTiffGray8bppImage = new TruecolorImage(tiffGray8bppNewImagePath))
                {
                    Assert.That(reLoadedColor24bppImage.Equals(_color24bppImage));
                    Assert.That(_color24bppImage.Equals(reLoadedColor24bppImage));

                    Assert.That(reLoadedGray24bppImage.Equals(_gray24bppImage));
                    Assert.That(_gray24bppImage.Equals(reLoadedGray24bppImage));

                    Assert.That(reLoadedTiffRgb32bppImage.Equals(_color24bppImage));
                    Assert.That(_color24bppImage.Equals(reLoadedTiffRgb32bppImage));

                    Assert.That(reLoadedTiffGray8bppImage.Equals(_gray24bppImage));
                    Assert.That(_gray24bppImage.Equals(reLoadedTiffGray8bppImage));
                }
            }
            finally
            {
                File.Delete(pngColor24bppNewImagePath);
                File.Delete(pngGray24bppNewImagePath);
                File.Delete(tiffRgb32bppNewImagePath);
                File.Delete(tiffGray8bppNewImagePath);
            }
        }
    }
}

#region .

// ReSharper restore InconsistentNaming

#endregion