using System;
using NUnit.Framework;
using Rhino.Mocks;
using StereoSom.Engine;
using StereoSom.Engine.Interfaces;
using System.Collections.Generic;
using StereoSom.Strategies;

namespace StereoSom.Tests.Strategies
{
    [TestFixture]
    public class StereoSomPhaseTest
    {
        private MockRepository _mockRepository;

        [SetUp]
        public void SetUp()
        {
            _mockRepository = new MockRepository();
        }

        [Test]
        public void Execute_TestEvenIterations()
        {
            // Given
            const int numOfCoreInternalIterations = 200;
            const int numOfTotalIterations = 1000;
            const int expectedNumOfRaises = 5;
            const int expectedCallbackCalls = expectedNumOfRaises;
            var expectedCoreIterations = new List<int> { 200, 200, 200, 200, 200 };
            var expectedProgressions = new [] {0, 0.25, 0.50, 0.75, 1};
            var parametersStub = new StereoSomParameters();

            // Given Mocks - When - Then
            Execute_Tester(expectedNumOfRaises, parametersStub, numOfTotalIterations, numOfCoreInternalIterations, expectedCallbackCalls, expectedCoreIterations, expectedProgressions);
        }

        [Test]
        public void Execute_TestOddIterations()
        {
            // Given
            const int numOfCoreInternalIterations = 300;
            const int numOfTotalIterations = 1000;
            const int expectedNumOfRaises = 4;
            const int expectedCallbackCalls = expectedNumOfRaises;
            var expectedCoreIterations = new List<int> { 300, 300, 300, 300 };
            var expectedProgressions = new[] {0, (1/3d)*1, (1/3d)*2, 1};
            var parametersStub = new StereoSomParameters();

            // Given Mocks - When - Then
            Execute_Tester(expectedNumOfRaises, parametersStub, numOfTotalIterations, numOfCoreInternalIterations, expectedCallbackCalls, expectedCoreIterations, expectedProgressions);
        }

        [Test]
        public void Execute_NoCatalyzer()
        {
            // Given
            const int numOfTotalIterations = 1000;

            // Given Mocks
            var parameterCatalyzer = new List<StereoSomPhase.ParameterCatalyzer>();

            // When / Then
            Assert.Throws(typeof (ArgumentException),
                          () => new StereoSomPhase("boh", numOfTotalIterations, parameterCatalyzer));
        }

        [Test]
        public void Execute_NoEvent()
        {
            // Given
            const int numOfCoreInternalIterations = 200;
            const int numOfTotalIterations = 1000;

            // Given Mocks
            var stereoSomEngineMock = _mockRepository.Stub<IStereoSomEngine>();
            var parameterCatalyzer = new[]{_mockRepository.Stub<StereoSomPhase.ParameterCatalyzer>(),
                                           _mockRepository.Stub<StereoSomPhase.ParameterCatalyzer>(),
                                           _mockRepository.Stub<StereoSomPhase.ParameterCatalyzer>()};

            // When
            var stereoSomPhase = new StereoSomPhase("boh", numOfTotalIterations, parameterCatalyzer);
            stereoSomPhase.Execute(stereoSomEngineMock, numOfCoreInternalIterations);

            // Then (no exceptions)
            Assert.True(true);
        }

        private void Execute_Tester(int expectedNumOfRaises, 
                                    IStereoSomParameters parametersStub, 
                                    int numOfTotalIterations, 
                                    int numOfCoreInternalIterations, 
                                    int expectedCallbackCalls, 
                                    IEnumerable<int> expectedCoreIterations,
                                    IEnumerable<double> expectedProgressions)
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();
            var parameterCatalyzer = new[]{_mockRepository.StrictMock<StereoSomPhase.ParameterCatalyzer>(),
                                           _mockRepository.StrictMock<StereoSomPhase.ParameterCatalyzer>(),
                                           _mockRepository.StrictMock<StereoSomPhase.ParameterCatalyzer>()};

            Expect.Call(stereoSomEngineMock.Parameters).Return(parametersStub)
                .Repeat.Times(expectedNumOfRaises * (parameterCatalyzer.Length + 1 + 1)); // 1 Call by the mocked Callback

            Expect.Call(stereoSomEngineMock.Parameters).SetPropertyWithArgument(parametersStub)
                .Repeat.Times(expectedNumOfRaises * parameterCatalyzer.Length);

            Expect.Call(stereoSomEngineMock.Execute).Repeat.Times(expectedNumOfRaises);

            // This test also Catalyzers calling order
            foreach (var catalyzer in parameterCatalyzer)
            {
                foreach (var expectedProgression in expectedProgressions)
                {
                    Expect.Call(catalyzer(expectedProgression, parametersStub)).Return(parametersStub);
                }
            }

            _mockRepository.ReplayAll();

            // When
            var stereoSomPhase = new StereoSomPhase("boh", numOfTotalIterations, parameterCatalyzer);
            var callbackCalls = 0;
            var coreIterations = new List<int>();

            stereoSomPhase.OnInternalIterationCycleDone +=
                (currentStereoSomEngine, currentStereoSomPhase, progression) =>
                    {
                        callbackCalls++;
                        coreIterations.Add(currentStereoSomEngine.Parameters.Iterations);
                    };
            stereoSomPhase.Execute(stereoSomEngineMock, numOfCoreInternalIterations);

            // Then
            _mockRepository.VerifyAll();
            Assert.That(callbackCalls, Is.EqualTo(expectedCallbackCalls), "Wrong number of event raises");
            Assert.That(coreIterations, Is.EquivalentTo(expectedCoreIterations), "Wrong core iterations");
        }
    }
}