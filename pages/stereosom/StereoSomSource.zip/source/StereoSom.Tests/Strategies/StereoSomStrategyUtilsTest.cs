using System;
using System.Collections.Generic;
using NUnit.Framework;
using Rhino.Mocks;
using StereoSom.Session.Interfaces;
using StereoSom.Strategies;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Tests.Strategies
{
    [TestFixture]
    public class StereoSomStrategyUtilsTest
    {
        private MockRepository _mockRepository;

        [SetUp]
        public void SetUp()
        {
            _mockRepository = new MockRepository();
        }

        [Test]
        public void LinearTrend_Test()
        {
            // Given
            var expectedValues = new []
                                     {
                                         new {start = 1, end = 10, progression = 0.5, expected = 5.5},
                                         new {start = 10, end = 1, progression = 0.5, expected = 5.5},
                                         new {start = -10, end = 10, progression = 0.5, expected = 0d},
                                         new {start = 10, end = -2, progression = 0.71, expected = 1.48},
                                         new {start = 10, end = 10, progression = 0.2, expected = 10d},
                                     };

            // When - Then
            foreach (var value in expectedValues)
            {
                Assert.That(StereoSomStrategyUtils.LinearTrend(value.start, value.end, value.progression), 
                    Is.InRange(value.expected - 0.00001, value.expected + 0.00001));
            }
            _mockRepository.VerifyAll();
        }

        [Test]
        public void AddStrategy_Test()
        {
            // Given (Mocks)
            var stereoSomMock = _mockRepository.DynamicMock<IStereoSomSession>();
            var stereoSomStrategyMock = _mockRepository.StrictMock<IStereoSomStrategy>();
            var phases = new[]
                             {
                                 _mockRepository.DynamicMock<IStereoSomPhase>(),
                                 _mockRepository.DynamicMock<IStereoSomPhase>(),
                                 _mockRepository.DynamicMock<IStereoSomPhase>(),
                                 _mockRepository.DynamicMock<IStereoSomPhase>(),
                                 _mockRepository.DynamicMock<IStereoSomPhase>(),
                             };
            
            var phasesToAdd = new List<IStereoSomPhase> { phases[0], phases[1] };
            var phasesAdded = new List<IStereoSomPhase> { phases[2], phases[3], phases[4] };
            var expectedPhases = new List<IStereoSomPhase> { phases[2], phases[3], phases[4], phases[0], phases[1] };

            Expect.Call(stereoSomStrategyMock.StrategyPhases).Return(phasesToAdd);
            Expect.Call(stereoSomMock.StereoSomPhases).Return(phasesAdded);

            var assertPhases = new Action<MethodInvocation>(
                ssp => Assert.That(ssp.Arguments[0], Is.EqualTo(expectedPhases)));
            Expect.Call(stereoSomMock.StereoSomPhases).SetPropertyAndIgnoreArgument().WhenCalled(assertPhases);          

            _mockRepository.ReplayAll();

            // When
            stereoSomMock.AddStrategy(stereoSomStrategyMock);

            // Then
            _mockRepository.VerifyAll();
        }
    }
}