using System;
using System.Collections.Generic;
using NUnit.Framework;
using Rhino.Mocks;
using StereoSom.Engine.Interfaces;
using StereoSom.Session;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Tests.Session
{
    [TestFixture]
    public class StereoSomSessionTest
    {
        private MockRepository _mockRepository;

        [SetUp]
        public void SetUp()
        {
            _mockRepository = new MockRepository();
        }

        [Test]
        public void Execute_TestOnePhase()
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();
            var stereoSomPhaseMocks = new List<IStereoSomPhase> { _mockRepository.StrictMock<IStereoSomPhase>() };

            Expect.Call(stereoSomEngineMock.ImageWidth).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.ImageHeight).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.SetDynamicDefaultParameters);
            Expect.Call(stereoSomPhaseMocks[0].Name).Return("test phase");
            Expect.Call(() => stereoSomPhaseMocks[0].Execute(stereoSomEngineMock));
            stereoSomPhaseMocks[0].OnInternalIterationCycleDone += null;
            LastCall.IgnoreArguments();
            
            _mockRepository.ReplayAll();

            // When
            var stereoSom = new StereoSomSession(stereoSomEngineMock, null) {StereoSomPhases = stereoSomPhaseMocks};
            stereoSom.OnInternalIterationCycleDone += (stereoSomEngine, stereoSomPhase, progression) => { };
            stereoSom.Execute();

            // Then        
            _mockRepository.VerifyAll();
        }

        [Test]
        public void Execute_TestMorePhases()
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();
            var stereoSomPhaseMocks = new List<IStereoSomPhase>
                                          {
                                              _mockRepository.StrictMock<IStereoSomPhase>(),
                                              _mockRepository.StrictMock<IStereoSomPhase>(),
                                              _mockRepository.StrictMock<IStereoSomPhase>()
                                          };

            Expect.Call(stereoSomEngineMock.ImageWidth).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.ImageHeight).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.SetDynamicDefaultParameters);
            for (var i = 0; i < stereoSomPhaseMocks.Count; i++)
            {
                Expect.Call(stereoSomPhaseMocks[i].Name).Return("test phase " + i);
                Expect.Call(() => stereoSomPhaseMocks[i].Execute(stereoSomEngineMock));
                stereoSomPhaseMocks[i].OnInternalIterationCycleDone += null;
                LastCall.IgnoreArguments();
            }

            _mockRepository.ReplayAll();

            // When
            var stereoSom = new StereoSomSession(stereoSomEngineMock, null);
            stereoSom.StereoSomPhases = stereoSomPhaseMocks;
            stereoSom.OnInternalIterationCycleDone += (stereoSomEngine, stereoSomPhase, progression) => { };
            stereoSom.Execute();

            // Then
            _mockRepository.VerifyAll();
        }

        [Test]
        public void Execute_TestNoEvent()
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();
            var stereoSomPhaseMocks = new List<IStereoSomPhase> { _mockRepository.StrictMock<IStereoSomPhase>() };

            Expect.Call(stereoSomEngineMock.ImageWidth).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.ImageHeight).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.SetDynamicDefaultParameters);
            Expect.Call(stereoSomPhaseMocks[0].Name).Return("test phase");
            Expect.Call(() => stereoSomPhaseMocks[0].Execute(stereoSomEngineMock));

            _mockRepository.ReplayAll();

            // When
            var stereoSom = new StereoSomSession(stereoSomEngineMock, null)
                                {
                                    StereoSomPhases = stereoSomPhaseMocks
                                };
            stereoSom.Execute();

            // Then
            _mockRepository.VerifyAll();
        }

        [Test]
        public void Execute_TestNoPhases()
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();
            var stereoSomEmptyPhases = new List<IStereoSomPhase>();

            Expect.Call(stereoSomEngineMock.ImageWidth).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.ImageHeight).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.SetDynamicDefaultParameters);

            _mockRepository.ReplayAll();

            // When
            var stereSom = new StereoSomSession(stereoSomEngineMock, null) { StereoSomPhases = stereoSomEmptyPhases };
            stereSom.Execute();

            // Then
            _mockRepository.VerifyAll();
        }

        [Test]
        public void Execute_TestNullPhases()
        {
            // Given Mocks
            var stereoSomEngineMock = _mockRepository.StrictMock<IStereoSomEngine>();

            Expect.Call(stereoSomEngineMock.ImageWidth).Repeat.Twice().Return(100);
            Expect.Call(stereoSomEngineMock.ImageHeight).Repeat.Twice().Return(100);

            _mockRepository.ReplayAll();

            // When - Then
            var stereSom = new StereoSomSession(stereoSomEngineMock, null) { StereoSomPhases = null };
            Assert.Throws(typeof(Exception), stereSom.Execute);
        }
    }
}