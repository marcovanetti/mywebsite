using System.Linq;
using NUnit.Framework;
using Rhino.Mocks;
using StereoSom.Utilities;

namespace StereoSom.Tests.Utilities
{
    [TestFixture]
    public class RandomUtilsTest
    {
        private MockRepository _mockRepository;

        [SetUp]
        public void SetUp()
        {
            _mockRepository = new MockRepository();
        }

        [Test]
        public void RandomPermutation_TestSum()
        {
            // Given
            const int arraySize = 50;
            var expectedSum = Enumerable.Range(1, arraySize).Sum();

            // When
            var randomUtils = new RandomUtils();
            var rndPerm = randomUtils.RandomPermutation(arraySize);

            // Then
            Assert.That(rndPerm.Sum(), Is.EqualTo(expectedSum));
        }

        [Test]
        public void RandomPermutation_TestAlgorithm()
        {
            // Given
            var expectedArray = new []{4, 2, 1, 3, 5};

            // Given Mocks
            var mockedRandomUtils = _mockRepository.PartialMock<RandomUtils>();
            // BallotBox [1,2,3,4,5]
            // Perm      []
            Expect.Call(mockedRandomUtils.RandomInt(0, 4)).Return(4);
            // BallotBox [1,2,3,4]
            // Perm      [5]
            Expect.Call(mockedRandomUtils.RandomInt(0, 3)).Return(2);
            // BallotBox [1,2,4]
            // Perm      [3,5]
            Expect.Call(mockedRandomUtils.RandomInt(0, 2)).Return(0);
            // BallotBox [2,4]
            // Perm      [1,3,5]
            Expect.Call(mockedRandomUtils.RandomInt(0, 1)).Return(0);
            // BallotBox [4]
            // Perm      [2,1,3,5]
            Expect.Call(mockedRandomUtils.RandomInt(0, 0)).Return(0);
            // BallotBox []
            // Perm      [4,2,1,3,5]
            _mockRepository.ReplayAll();

            // When
            var rndArray = mockedRandomUtils.RandomPermutation(5);

            // Then
            Assert.That(rndArray, Is.EquivalentTo(expectedArray));
            _mockRepository.VerifyAll();
        }
    }
}