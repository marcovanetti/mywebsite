using System;
using System.Linq;
using ArteStereo.Images;
using Emgu.CV.Structure;
using NUnit.Framework;
using StereoSom.Utilities;

namespace StereoSom.Tests.Utilities
{
    [TestFixture]
    public class SomWeightsUtilsTest
    {
        private SomWeightsUtils _weightSerializer;
        private TruecolorImage _rgb24BppImage;
        private TruecolorImage _gray24BppImage;
        private TruecolorImage _8BppImage;
        private TruecolorImage _32BppImage;

        [SetUp]
        public void SetUp()
        {
            _weightSerializer = new SomWeightsUtils();

            #region _rgb24bppImage initialization
            _rgb24BppImage = new TruecolorImage(4, 3);
            // Pixel row 1
            _rgb24BppImage[0, 0] = new Bgr(000, 000, 000);
            _rgb24BppImage[0, 1] = new Bgr(000, 000, 255);
            _rgb24BppImage[0, 2] = new Bgr(000, 255, 000);
            _rgb24BppImage[0, 3] = new Bgr(255, 000, 000);
            // Pixel row 2
            _rgb24BppImage[1, 0] = new Bgr(128, 128, 128);
            _rgb24BppImage[1, 1] = new Bgr(128, 128, 128);
            _rgb24BppImage[1, 2] = new Bgr(128, 128, 128);
            _rgb24BppImage[1, 3] = new Bgr(255, 255, 255);
            // Pixel row 3
            _rgb24BppImage[2, 0] = new Bgr(084, 012, 026);
            _rgb24BppImage[2, 1] = new Bgr(084, 012, 026);
            _rgb24BppImage[2, 2] = new Bgr(084, 012, 026);
            _rgb24BppImage[2, 3] = new Bgr(255, 255, 255);
            #endregion

            #region _gray24bppImage initialization
            _gray24BppImage = new TruecolorImage(4, 3);
            // Pixel row 1
            _gray24BppImage[0, 0] = new Bgr(000, 000, 000);
            _gray24BppImage[0, 1] = new Bgr(076, 076, 076);
            _gray24BppImage[0, 2] = new Bgr(149, 149, 149);
            _gray24BppImage[0, 3] = new Bgr(029, 029, 029);
            // Pixel row 2
            _gray24BppImage[1, 0] = new Bgr(128, 128, 128);
            _gray24BppImage[1, 1] = new Bgr(128, 128, 128);
            _gray24BppImage[1, 2] = new Bgr(128, 128, 128);
            _gray24BppImage[1, 3] = new Bgr(255, 255, 255);
            // Pixel row 3
            _gray24BppImage[2, 0] = new Bgr(024, 024, 024);
            _gray24BppImage[2, 1] = new Bgr(024, 024, 024);
            _gray24BppImage[2, 2] = new Bgr(024, 024, 024);
            _gray24BppImage[2, 3] = new Bgr(255, 255, 255);
            #endregion

            #region _8bppImage initialization
            _8BppImage = new TruecolorImage(4, 3);
            #endregion

            #region _32bppImage initialization
            _32BppImage = new TruecolorImage(4, 3);
            #endregion
        }

        [TearDown]
        public void TearDown()
        {
            _rgb24BppImage.Dispose();
            _gray24BppImage.Dispose();
            _8BppImage.Dispose();
            _32BppImage.Dispose();
        }

        // Serialization tests
        [Test]
        public void SerializeImage_TestCorrectRGB()
        {
            // Given
            var expectedRedChannel = new double[]
                                          {
                                              000, 255, 000, 000,
                                              128, 128, 128, 255,
                                              026, 026, 026, 255,
                                          };
            var expectedGreenChannel = new double[]
                                          {
                                              000, 000, 255, 000,
                                              128, 128, 128, 255,
                                              012, 012, 012, 255,
                                          };
            var expectedBlueChannel = new double[]
                                          {
                                              000, 000, 000, 255,
                                              128, 128, 128, 255,
                                              084, 084, 084, 255,
                                          };
            // When
            var actualRedChannel = new double[expectedRedChannel.Length];
            var actualGreenChannel = new double[expectedGreenChannel.Length];
            var actualBlueChannel = new double[expectedBlueChannel.Length];
            _weightSerializer.SerializeImage(_rgb24BppImage, actualRedChannel,
                                                          actualGreenChannel,
                                                          actualBlueChannel);

            // Then
            Assert.That(actualRedChannel, Is.EquivalentTo(expectedRedChannel));
            Assert.That(actualGreenChannel, Is.EquivalentTo(expectedGreenChannel));
            Assert.That(actualBlueChannel, Is.EquivalentTo(expectedBlueChannel));
        }

        [Test]
        public void SerializeImage_TestCorrectGrayscale()
        {
            // Given
            var expectedGrayChannel = new double[]
                                          {
                                              000, 076, 149, 029,
                                              128, 128, 128, 255,
                                              024, 024, 024, 255,
                                          };
            const double normalizationFactor = 3d;
            var expectedNormGrayChannel = (from channel in expectedGrayChannel
                                           select channel / normalizationFactor).ToArray();

            // When
            var actualGrayChannel = new double[expectedGrayChannel.Length];
            _weightSerializer.SerializeImage(_gray24BppImage, actualGrayChannel);

            var actualNormGrayChannel = new double[expectedNormGrayChannel.Length];
            _weightSerializer.SerializeImage(_gray24BppImage, actualNormGrayChannel, normalizationFactor, 0);

            // Then
            Assert.That(actualGrayChannel, Is.EquivalentTo(expectedGrayChannel));
            Assert.That(actualNormGrayChannel, Is.EquivalentTo(expectedNormGrayChannel));
        }

        [Test]
        public void SerializeImage_TestCorrectGrayscaleOffset()
        {
            // Given
            var expectedGrayChannel = new double[]
                                          {
                                              000, 076, 149, 029,
                                              128, 128, 128, 255,
                                              024, 024, 024, 255,
                                          };
            const double normalizationFactor = 3d;
            const double normalizationOffset = -10.5d;
            var expectedNormGrayChannel = (from channel in expectedGrayChannel
                                           select (channel / normalizationFactor) + normalizationOffset).ToArray();

            // When
            var actualGrayChannel = new double[expectedGrayChannel.Length];
            _weightSerializer.SerializeImage(_gray24BppImage, actualGrayChannel);

            var actualNormGrayChannel = new double[expectedNormGrayChannel.Length];
            _weightSerializer.SerializeImage(_gray24BppImage, actualNormGrayChannel, normalizationFactor, normalizationOffset);

            // Then
            Assert.That(actualGrayChannel, Is.EquivalentTo(expectedGrayChannel));
            Assert.That(actualNormGrayChannel, Is.EquivalentTo(expectedNormGrayChannel));
        }

        [Test]
        public void SerializeImage_TestGrayscaleCompatibleException()
        {
            // When / Then
            var actualGrayChannel = new double[_rgb24BppImage.Width * _rgb24BppImage.Height];
            Assert.Throws(typeof(GrayscaleCompatibleException),
                () => _weightSerializer.SerializeImage(_rgb24BppImage, actualGrayChannel));

            // Assert.NotThrows
            _weightSerializer.SerializeImage(_rgb24BppImage,
                actualGrayChannel, actualGrayChannel, actualGrayChannel);
        }

        [Test]
        public void SerializeImage_TestWrongSizeException()
        {
            // When / Then
            var actualChannel = new double[_rgb24BppImage.Width * _rgb24BppImage.Height - 1];
            Assert.Throws(typeof(WrongSizeException),
                () => _weightSerializer.SerializeImage(_rgb24BppImage, actualChannel));

            Assert.Throws(typeof(WrongSizeException),
               () => _weightSerializer.SerializeImage(_rgb24BppImage,
                   actualChannel, actualChannel, actualChannel));
        }

        // Deserialization tests
        [Test]
        public void DeserializeImage_TestCorrectRGB()
        {
            // Given
            var redChannel = new double[]
                                          {
                                              000, 255, 000, 000,
                                              128, 128, 128, 255,
                                              026, 026, 026, 255,
                                          };
            var greenChannel = new double[]
                                          {
                                              000, 000, 255, 000,
                                              128, 128, 128, 255,
                                              012, 012, 012, 255,
                                          };
            var blueChannel = new double[]
                                          {
                                              000, 000, 000, 255,
                                              128, 128, 128, 255,
                                              084, 084, 084, 255,
                                          };
            // When
            using (var actualRgbImage = new TruecolorImage(4, 3))
            {
                _weightSerializer.DeserializeImage(redChannel,
                                                    greenChannel,
                                                    blueChannel,
                                                    actualRgbImage);

                // Then
                Assert.That(_rgb24BppImage.Equals(actualRgbImage));
            }
        }

        [Test]
        public void DeserializeImage_TestCorrectGrayscale()
        {
            // Given
            var grayChannel = new double[]
                                          {
                                              000, 076, 149, 029,
                                              128, 128, 128, 255,
                                              024, 024, 024, 255,
                                          };
            const double normalizationFactor = 3d;
            var normGrayChannel = (from channel in grayChannel
                                   select channel / normalizationFactor).ToArray();

            // When
            var actualGrayImage = new TruecolorImage(4, 3);
            _weightSerializer.DeserializeImage(grayChannel, actualGrayImage);

            var actualNormGrayImage = new TruecolorImage(4, 3);
            _weightSerializer.DeserializeImage(normGrayChannel, normalizationFactor, 0, actualNormGrayImage);

            // Then
            Assert.That(_gray24BppImage.Equals(actualGrayImage));
            Assert.That(_gray24BppImage.Equals(actualNormGrayImage));
        }

        [Test]
        public void DeserializeImage_TestCorrectGrayscaleOffset()
        {
            // Given
            var grayChannel = new double[]
                                          {
                                              000, 076, 149, 029,
                                              128, 128, 128, 255,
                                              024, 024, 024, 255,
                                          };
            const double normalizationFactor = 3d;
            const double normalizationOffset = -10.5d;
            var normGrayChannel = (from channel in grayChannel
                                   select (channel / normalizationFactor) + normalizationOffset).ToArray();

            // When
            var actualGrayImage = new TruecolorImage(4, 3);
            _weightSerializer.DeserializeImage(grayChannel, actualGrayImage);

            var actualNormGrayImage = new TruecolorImage(4, 3);
            _weightSerializer.DeserializeImage(normGrayChannel, normalizationFactor, normalizationOffset, actualNormGrayImage);

            // Then
            Assert.That(_gray24BppImage.Equals(actualGrayImage));
            Assert.That(_gray24BppImage.Equals(actualNormGrayImage));
        }

        [Test]
        public void DeserializeImage_TestWrongSizeException()
        {
            // When / Then
            var channel = new double[_rgb24BppImage.Width * _rgb24BppImage.Height - 1];
            Assert.Throws(typeof(WrongSizeException),
                () => _weightSerializer.DeserializeImage(channel, _rgb24BppImage));

            Assert.Throws(typeof(WrongSizeException),
               () => _weightSerializer.DeserializeImage(channel, channel, channel, _rgb24BppImage));
        }

        [Test]
        public void DeserializeText_TestCorrect()
        {
            // Given
            var givenWeight = new[]
                                 {
                                     000.00,   076.00,         149.00,     029.23,
                                     128.128,  128.129,        128.1279,   255.12719,
                                     024,      024.49954543,   024,        255.0,
                                 };

            const string expectedText = "3 4\n"+
                                        "0.000 76.000 149.000 29.230\n"+
                                        "128.128 128.129 128.128 255.127\n"+
                                        "24.000 24.500 24.000 255.000\n";
            const int imageHeight = 3;
            const int imageWidth = 4;

            // When
            var actualText = _weightSerializer.DeserializeText(givenWeight, imageHeight, imageWidth);

            // Then
            Assert.That(actualText, Is.EqualTo(expectedText));
        }

        // Weight creation tests
        [Test]
        public void InitializeSomCorrespondenceWeights_Correct()
        {
            // Given
            var expectedWeights = new double[]{1, 2, 3, 4,
                                               1, 2, 3, 4,
                                               1, 2, 3, 4,};
            const int columns = 4;
            const int rows = 3;

            // When
            var actualWeights = new double[expectedWeights.Length];
            SomWeightsUtils.InitializeSomCorrespondenceWeights(actualWeights, rows, columns);

            // Then
            Assert.That(actualWeights, Is.EquivalentTo(expectedWeights));
        }

        [Test]
        public void InitializeSomCorrespondenceWeights_WrongSizeException()
        {
            // Given
            const int columns = 4;
            const int rows = 3;

            // When / Then
            var actualWeights = new double[rows * columns + 1];
            Assert.Throws(typeof(ArgumentException),
                () => SomWeightsUtils.InitializeSomCorrespondenceWeights(actualWeights, rows, columns));
        }

        // Weight conversions
        [Test]
        public void CorrespondenceWeights2Disparity_Correct()
        {
            // Given
            var leftCorrWeights = new double[]{-2, 2, 3, 2,
                                                1, 1, 2, 4,
                                                1, 1, 2, 1,};

            var expectedLeftDisp = new double[]{3, 0, 0, 2,
                                                0, 1, 1, 0,
                                                0, 1, 1, 3,};

            var rightCorrWeights = new double[]{3, 2, 3, 4,
                                                1, 3, 3, 4,
                                                1, 2, 3, 7,};

            var expectedRightDisp = new double[]{2, 0, 0, 0,
                                                 0, 1, 0, 0,
                                                 0, 0, 0, 3,};

            const int columns = 4;
            const int rows = 3;

            // When
            var actualLeftDisp = SomWeightsUtils.CorrespondenceWeights2Disparity(leftCorrWeights, rows, columns, SomLocator.LeftSom);
            var actualRightDisp = SomWeightsUtils.CorrespondenceWeights2Disparity(rightCorrWeights, rows, columns, SomLocator.RightSom);

            // Then
            Assert.That(actualLeftDisp, Is.EquivalentTo(expectedLeftDisp));
            Assert.That(actualRightDisp, Is.EquivalentTo(expectedRightDisp));
        }

        [Test]
        public void CorrespondenceWeights2Disparity_WrongSizeException()
        {
            // Given
            const int columns = 4;
            const int rows = 3;

            // When / Then
            var actualWeights = new double[rows * columns + 1];
            Assert.Throws(typeof(ArgumentException),
                () => SomWeightsUtils.CorrespondenceWeights2Disparity(actualWeights, rows, columns, SomLocator.LeftSom));
            Assert.Throws(typeof(ArgumentException),
                () => SomWeightsUtils.CorrespondenceWeights2Disparity(actualWeights, rows, columns, SomLocator.RightSom));

        }
    }
}