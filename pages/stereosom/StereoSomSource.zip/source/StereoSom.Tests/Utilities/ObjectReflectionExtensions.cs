﻿//using System;
//using System.Reflection;

//namespace StereoSom.Tests.Utilities
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    /// <creator>Alessandro Cavallaro, Roberto Zanon</creator>
//    public static class ObjectReflectionExtensions
//    {
//        /// <summary>
//        /// Set an instance non public field using reflection.
//        /// </summary>
//        /// <param name="obj"></param>
//        /// <param name="fieldName"></param>
//        /// <param name="value"></param>
//        public static void SetField(this object obj, string fieldName, object value)
//        {
//            var field = obj.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
//            field.SetValue(obj, value);
//        }

//        public static void SetProperty(this object obj, string propertyName, object value)
//        {
//            var prop = obj.GetType().GetProperty(propertyName);
//            if (prop != null)
//            {
//                prop.SetValue(obj, value, new object[0]);
//            }
//            else
//            {
//                obj.GetType().InvokeMember(propertyName,
//                                           BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
//                                           null, obj, new[] { value });
//            }
//        }

//        /// <summary>
//        /// Get an instance non public field using reflection.
//        /// </summary>
//        /// <typeparam name="E"></typeparam>
//        /// <param name="obj"></param>
//        /// <param name="fieldName"></param>
//        /// <returns></returns>
//        public static E GetField<E>(this object obj, string fieldName)
//        {
//            return (E)obj.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(obj);
//        }

//        /// <summary>
//        /// Set a static non public field using reflection.
//        /// </summary>
//        /// <param name="obj"></param>
//        /// <param name="fieldName"></param>
//        /// <param name="value"></param>
//        public static void SetStaticField(this object obj, string fieldName, object value)
//        {
//            var agentAdapterField = obj.GetType().GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Static);
//            agentAdapterField.SetValue(obj, value);
//        }

//        /// <summary>
//        /// Get a static non public field using reflection.
//        /// </summary>
//        /// <typeparam name="E"></typeparam>
//        /// <param name="obj"></param>
//        /// <param name="fieldName"></param>
//        /// <returns></returns>
//        public static E GetStaticField<E>(this object obj, string fieldName)
//        {
//            return (E)obj.GetType().GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Static).GetValue(obj);
//        }

//        public static E InvokeStaticMethod<E>(this Type obj, string methodName, params object[] args)
//        {
//            if (args == null)
//            {
//                throw new ArgumentNullException("args");
//            }
//            return (E)obj.GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, args);
//        }

//        public static E InvokeMethod<E>(this object obj, string methodName, params object[] args)
//        {
//            if (args == null)
//            {
//                throw new ArgumentNullException("args");
//            }
//            return (E)obj.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(obj, args);
//        }
//    }
//}