﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using Emgu.CV.CvEnum;
using NUnit.Framework;
using Emgu.CV.Structure;
using Emgu.CV;

namespace EmguLibraries.Test
{
    [TestFixture]
    public class ValidationDllTest
    {
        DirectoryInfo _tempDir;

        [TestFixtureSetUp]
        public void TestFixtureSetUp()
        {
            _tempDir = new DirectoryInfo(Path.Combine(Path.GetTempPath(), "EmguDllTests"));

            if (Directory.Exists(_tempDir.FullName))
            {
                _tempDir.Delete(true);
            }
            _tempDir.Create();
        }

        [TestFixtureTearDown]
        public void TestFixtureTearDown()
        {
            _tempDir.Delete(true);
        }

        [Test]
        public void ImagingSaveAndLoad()
        {
            var image = new Image<Bgra, byte>(5, 5);
            var grayImage = new Image<Gray, byte>(5, 5);

            var rand = new Random();

            image.ROI = new Rectangle(1, 1, 1, 1);

            foreach (var point in image.GetAllPoints())
            {
                image[point.Y, point.X] = new Bgra(rand.Next(255), rand.Next(255), rand.Next(255), rand.Next(255));
            }

            var tempFileName = Path.Combine(_tempDir.FullName, Guid.NewGuid().ToString());
            image.Save(tempFileName + ".jpg");
            image.Save(tempFileName + ".png");
            grayImage.Save(tempFileName + "_gray" + ".png");

            var imageJpg = new Image<Bgra, byte>(tempFileName + ".jpg");
            var imagePng = new Image<Bgra, byte>(tempFileName + ".png");

            //Assert.That(image.EqualsToImage(imageJpg)); //<- save a jpeg is lossy
            Assert.That(image.EqualsToImage(imagePng));
        }

        [Test]
        public void Imaging()
        {
            //test constructors
            var image = new Image<Bgra, byte>(10, 10);

            //test smoot filters calls
            image.SmoothGaussian(3);
            image.SmoothBlur(1, 1);
            image.SmoothMedian(3);
            image.SmoothBlur(1, 1);

            //test resize
            var imageResized = image.Resize(5, 3, INTER.CV_INTER_NN);
            Assert.That(imageResized.Height, Is.EqualTo(3));
            Assert.That(imageResized.Width, Is.EqualTo(5));
        }

        [Test]
        public void DenseHistogram()
        {
            var w = 10;
            var h = 10;
            var gray = new Image<Gray, byte>(w, h, new Gray(0));
            gray.Data[1, 1, 0] = 255;
            gray.Data[2, 2, 0] = 255;
            var hist = new DenseHistogram(2, new RangeF(0, 256));
            CvInvoke.cvCalcHist(new[] { gray.Ptr }, hist, false, IntPtr.Zero);
            Assert.That((int)hist[0], Is.EqualTo(98));
            Assert.That((int)hist[1], Is.EqualTo(2));
        }

        [Test]
        public void MatrixGetRowTest()
        {
            var matrix = new Matrix<float>(2, 2);
            matrix.SetZero();

            var row = matrix.GetRow(1);
            row[0, 0] = 1F;

            Assert.That(matrix.Rows, Is.EqualTo(2));
            Assert.That(matrix.Cols, Is.EqualTo(2));
            Assert.That(row.Rows, Is.EqualTo(1));
            Assert.That(row.Cols, Is.EqualTo(2));

            Assert.That(matrix[0, 0], Is.EqualTo(0));
            Assert.That(matrix[0, 1], Is.EqualTo(0));
            Assert.That(matrix[1, 0], Is.EqualTo(1));
            Assert.That(matrix[1, 1], Is.EqualTo(0));
        }

        [Test]
        public void ImageDivision()
        {
            // Given
            var tolerance = Math.Pow(10, -4);
            var size = new Size(2, 2);
            var img1 = new Image<Gray, float>(size);
            img1.SetValue(10);
            var img2 = new Image<Gray, float>(size);
            img2.SetValue(2);
            var zeroImg = new Image<Gray, float>(size);
            zeroImg.SetValue(0);

            // When
            var result = img1.Mul(1 / img2);
            var byZero = img1.Mul(1 / zeroImg);

            // Then
            for (int row = 0; row < size.Height; row++)
            {
                for (int col = 0; col < size.Width; col++)
                {
                    Assert.That(result.Data[row, col, 0], Is.EqualTo(5).Within(tolerance));
                    Assert.That(byZero.Data[row, col, 0], Is.EqualTo(0).Within(tolerance));
                }
            }

        }

        [Test]
        public void ConvertImage_BGR_Single_to_Gray_byte()
        {
            // Given
            var size = new Size(10, 10);
            var bgr = new Image<Bgr, Single>(size);
            bgr.SetValue(new Bgr(10, 10, 10));

            // When
            var gray = bgr.Convert<Gray, byte>();

            // Then
            Assert.That(gray.Size, Is.EqualTo(size));
            Assert.That(gray.Data[0, 0, 0], Is.EqualTo(10));

        }
        
        [Test]
        public void HardImageNot()
        {
            var originalImage = new Image<Gray, byte>(10, 10, new Gray(1));
            originalImage[0, 0] = new Gray(0);
            originalImage[1, 1] = new Gray(255);
            originalImage[2, 2] = new Gray(2);

            var complementImage = (originalImage * 255).Not();

            Assert.That(complementImage.GetSum().Intensity, Is.EqualTo(255));
        }

        [Test]
        public void CopyOnlyInMask()
        {
            var mask = new Image<Gray, byte>(10, 10, new Gray(0));
            mask[1, 1] = new Gray(255);
            mask[2, 2] = new Gray(1);

            var image = new Image<Gray, byte>(10, 10, new Gray(84));

            var maskedCopy = image.Copy(mask);

            Assert.That(maskedCopy[1, 1].Intensity, Is.EqualTo(84));
            Assert.That(maskedCopy[2, 2].Intensity, Is.EqualTo(84));
            Assert.That(maskedCopy[3, 3].Intensity, Is.EqualTo(0));
        }
    }

    public static class ImageExtension
    {
        public static IEnumerable<Point> GetAllPoints(this Image<Bgra, byte> image)
        {
            for (var x = 0; x < image.Width; x++)
            {
                for (var y = 0; y < image.Height; y++)
                {
                    yield return new Point(x, y);
                }
            }
            yield break;
        }

        public static bool EqualsToImage(this Image<Bgra, byte> image, Image<Bgra, byte> other)
        {
            if (image.Size != other.Size)
                return false;

            foreach (var point in image.GetAllPoints())
            {
                if (!image[point.Y, point.X].Equals(other[point.Y, point.X]))
                    return false;
            }
            return true;
        }
    }
}