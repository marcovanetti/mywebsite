﻿using System.IO;
using ArteStereo.Evaluation;
using ArteStereo.Images;
using NUnit.Framework;

namespace ArteStereo.Tests.Evaluation
{
    [TestFixture]
    public class StereoEvaluationTest
    {
        [Test]
        public void GetPBDErrors_Test()
        {
            // Given
            const string imageDir = "../../TestFiles/Images";
            var expectedPbd = new[] { new { All = 17.5, NonOcc = 16.7, Disc = 32.5, Threshold = 0.5, NormFactor = 16 },
                                      new { All = 3.10, NonOcc = 2.78, Disc = 12.9, Threshold = 0.5, NormFactor = 8 },
                                      new { All = 19.9, NonOcc = 13.6, Disc = 30.0, Threshold = 0.5, NormFactor = 4 },
                                      new { All = 14.7, NonOcc = 8.28, Disc = 20.3, Threshold = 0.5, NormFactor = 4 }};

            var onlineDataset = new []
                                    {   
                                        new StereoDataset(null, null, 
                                            new GrayscaleImage(Path.Combine(imageDir, "all_tsukuba_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "disc_tsukuba_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "nonocc_tsukuba_left.png")), 16, 0, 15),

                                        new StereoDataset(null, null, 
                                            new GrayscaleImage(Path.Combine(imageDir, "all_venus_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "disc_venus_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "nonocc_venus_left.png")), 8, 0, 19),

                                        new StereoDataset(null, null, 
                                            new GrayscaleImage(Path.Combine(imageDir, "all_teddy_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "disc_teddy_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "nonocc_teddy_left.png")), 4, 0, 59),

                                        new StereoDataset(null, null, 
                                            new GrayscaleImage(Path.Combine(imageDir, "all_cones_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "disc_cones_left.png")),
                                            new GrayscaleImage(Path.Combine(imageDir, "nonocc_cones_left.png")), 4, 0, 59)
                                        };

            var ssomDispMaps = new[]
                          {
                            new DisparityResult(new GrayscaleImage(Path.Combine(imageDir, "stereosom_tsukuba_left.png"))),
                            new DisparityResult(new GrayscaleImage(Path.Combine(imageDir, "stereosom_venus_left.png"))),
                            new DisparityResult(new GrayscaleImage(Path.Combine(imageDir, "stereosom_teddy_left.png"))),
                            new DisparityResult(new GrayscaleImage(Path.Combine(imageDir, "stereosom_cones_left.png"))),
                          };
            // When-Then
            for (int i = 0; i < onlineDataset.Length; i++)
            {
                var stereoEvaluator = new StereoEvaluator(onlineDataset[i], ssomDispMaps[i],
                                                           expectedPbd[i].Threshold, expectedPbd[i].NormFactor);

                Assert.That(stereoEvaluator.PbdAll, Is.EqualTo(expectedPbd[i].All).Within(0.05));
                Assert.That(stereoEvaluator.PbdNonOcc, Is.EqualTo(expectedPbd[i].NonOcc).Within(0.05));
                Assert.That(stereoEvaluator.PbdDisc, Is.EqualTo(expectedPbd[i].Disc).Within(0.05));
            }
        }

    }


}
