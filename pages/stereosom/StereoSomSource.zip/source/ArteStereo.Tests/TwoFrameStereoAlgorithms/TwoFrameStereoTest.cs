﻿using System;
using ArteStereo.TwoFrameStereoAlgorithms;
using NUnit.Framework;

namespace ArteStereo.Tests.TwoFrameStereoAlgorithms
{
    [TestFixture]
    public class TwoFrameStereoTest
    {
        [Test]
        public void ForceToModule_Test()
        {
            Assert.That(TwoFrameStereo.ForceToModule(1, 16), Is.EqualTo(16));
            Assert.That(TwoFrameStereo.ForceToModule(1, 2), Is.EqualTo(2));
            Assert.That(TwoFrameStereo.ForceToModule(20, 16), Is.EqualTo(32));
            Assert.That(TwoFrameStereo.ForceToModule(100, 8), Is.EqualTo(104));
            Assert.That(TwoFrameStereo.ForceToModule(0, 16), Is.EqualTo(0));
            Assert.Throws<ArgumentException>(() => TwoFrameStereo.ForceToModule(0, 0));
            Assert.Throws<ArgumentException>(() => TwoFrameStereo.ForceToModule(1, 0));
            Assert.Throws<ArgumentException>(() => TwoFrameStereo.ForceToModule(1, -1));
            Assert.Throws<ArgumentException>(() => TwoFrameStereo.ForceToModule(-1, 2));
        }
    }
}
