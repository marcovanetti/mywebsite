using System;
using System.Collections.Generic;
using System.IO;
using ArteStereo.Evaluation;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;
using ArteStereo.TwoFrameStereoAlgorithms;
using ArteStereo.TwoFrameStereoAlgorithms.Interfaces;
using NUnit.Framework;
using StereoSom;

namespace ArteStereo.Tests.Integration
{
    [TestFixture, Ignore("Integration tests")]
    public class TwoFrameTest
    {
        private const string EvaluationDir = "../../TestFiles/Images";
        private Dictionary<string, IStereoDataset> _onlineDatasets;
        private Dictionary<string, IStereoEvaluator> _evaluators;
        private string _algorithmName;

        public delegate ITwoFrameStereoAlgorithm StereoMatchingProcess(IStereoDataset stereoDataset);

        [SetUp]
        public void SetUp()
        {
            _onlineDatasets = new Dictionary<string, IStereoDataset>
                                 { {"Tsukuba",
                                    new StereoDataset(new TruecolorImage(Path.Combine(EvaluationDir, "tsukuba_l.png")), 
                                                      new TruecolorImage(Path.Combine(EvaluationDir, "tsukuba_r.png")), 
                                                      new GrayscaleImage(Path.Combine(EvaluationDir, "all_tsukuba_left.png")),
                                                      new GrayscaleImage(Path.Combine(EvaluationDir, "disc_tsukuba_left.png")),
                                                      new GrayscaleImage(Path.Combine(EvaluationDir, "nonocc_tsukuba_left.png")), 16, 0, 15)
                                    },
                                    {"Venus",
                                     new StereoDataset(new TruecolorImage(Path.Combine(EvaluationDir, "venus_l.png")), 
                                                       new TruecolorImage(Path.Combine(EvaluationDir, "venus_r.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "all_venus_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "disc_venus_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "nonocc_venus_left.png")), 8, 0, 19)
                                    },
                                    {"Teddy",
                                     new StereoDataset(new TruecolorImage(Path.Combine(EvaluationDir, "teddy_l.png")), 
                                                       new TruecolorImage(Path.Combine(EvaluationDir, "teddy_r.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "all_teddy_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "disc_teddy_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "nonocc_teddy_left.png")), 4, 0, 59)
                                    },
                                    {"Cones",
                                     new StereoDataset(new TruecolorImage(Path.Combine(EvaluationDir, "cones_l.png")), 
                                                       new TruecolorImage(Path.Combine(EvaluationDir, "cones_r.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "all_cones_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "disc_cones_left.png")),
                                                       new GrayscaleImage(Path.Combine(EvaluationDir, "nonocc_cones_left.png")), 4, 0, 59)
                                    },
                                 };

            _evaluators = new Dictionary<string, IStereoEvaluator>();
        }

        [TearDown]
        public void TearDown()
        {
            Console.WriteLine("{0} algorithm", _algorithmName);
            foreach (var evaluatorKey in _evaluators.Keys)
            {
                var evaluator = _evaluators[evaluatorKey];
                Console.WriteLine("\tDataset: {0}", evaluatorKey);
                Console.WriteLine("\t\tAll: {0}", evaluator.PbdAll);
                Console.WriteLine("\t\tNon-Occ: {0}", evaluator.PbdNonOcc);
                Console.WriteLine("\t\tDisc: {0}", evaluator.PbdDisc);
            }
        }

        [Test]
        public void BlockMatchingStereoMatching()
        {
            _algorithmName = "OpenCV Block Matching";
            StereoMatchingTest(stereoDataset => new BlockMatchingStereo(stereoDataset));
        }

        [Test]
        public void GraphCutsStereoMatching()
        {
            _algorithmName = "OpenCV Graph Cuts";
            StereoMatchingTest(stereoDataset => new GraphCutsStereo(stereoDataset)) ;
        }

        [Test]
        public void SgbmStereoMatching()
        {
            _algorithmName = "OpenCV Semi-Global Block Matching";
            StereoMatchingTest(stereoDataset => new SGBlockMatchingStereo(stereoDataset));
        }

        [Test]
        public void StereoSomMatching()
        {
            _algorithmName = "Dicom's StereoSom";
            StereoMatchingTest(stereoDataset => new StereoSomStereo(stereoDataset));
        }

        void StereoMatchingTest(StereoMatchingProcess stereoMatchingProcess)
        {
            foreach (var datasetKey in _onlineDatasets.Keys)
            {
                var dataset = _onlineDatasets[datasetKey];

                IDisparityResult disparityResult;
                using (var stereoMatcher = stereoMatchingProcess(dataset))
                {
                    disparityResult = stereoMatcher.CalculateLeftDisparityMap();
                }

                _evaluators.Add(datasetKey, new StereoEvaluator(dataset, disparityResult, 0.5, dataset.NormalizationFactor));
            }
        }

    }
}