﻿using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;

namespace ArteStereo.Evaluation
{
    public class StereoDataset : IStereoDataset
    {
        public TruecolorImage LeftImage { get; private set; }
        public TruecolorImage RightImage { get; private set; }

        public GrayscaleImage DisparityMap { get; private set; }
        public GrayscaleImage DiscontinuityMap { get; private set; }
        public GrayscaleImage NonOcclusionMap { get; private set; }

        public double NormalizationFactor { get; private set; }
        public double MinimumDisparity { get; private set; }
        public double MaximumDisparity { get; private set; }

        public StereoDataset(TruecolorImage leftImage, TruecolorImage rightImage, GrayscaleImage disparityMap,
            GrayscaleImage discontinuityMap, GrayscaleImage nonOcclusionMap,
            double normalizationFactor, double minimumDisparity, double maximumDisparity)
        {
            LeftImage = leftImage;
            RightImage = rightImage;
            DisparityMap = disparityMap;
            DiscontinuityMap = discontinuityMap;
            NonOcclusionMap = nonOcclusionMap;
            NormalizationFactor = normalizationFactor;
            MinimumDisparity = minimumDisparity;
            MaximumDisparity = maximumDisparity;
        }

        public StereoDataset(TruecolorImage leftImage, TruecolorImage rightImage, GrayscaleImage disparityMap,
            double normalizationFactor, double minimumDisparity, double maximumDisparity) :
            this(leftImage, rightImage, disparityMap, null, null, normalizationFactor, minimumDisparity, maximumDisparity)
        { }

        public StereoDataset(TruecolorImage leftImage, TruecolorImage rightImage,
                             double normalizationFactor, double minimumDisparity, double maximumDisparity) :
            this(leftImage, rightImage, null, null, null, normalizationFactor, minimumDisparity, maximumDisparity)
        { }

    }
}
