﻿using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;

namespace ArteStereo.Evaluation
{
    public class DisparityResult : IDisparityResult
    {
        public GrayscaleImage LeftDisparityMap { get; private set; }
        
        public DisparityResult(GrayscaleImage leftDisparityMap)
        {
            LeftDisparityMap = leftDisparityMap;
        }
    }
}
