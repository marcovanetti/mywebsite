﻿using System;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;

namespace ArteStereo.Evaluation
{
    public class StereoEvaluator : IStereoEvaluator
    {
        private readonly GrayscaleImage _truthAllDisparityMap;
        private readonly GrayscaleImage _truthNonOccDisparityMap;
        private readonly GrayscaleImage _truthDiscDisparityMap;
        private readonly GrayscaleImage _disparityMap;
        private readonly double _threshold;
        private readonly double _normalizationFactor;

        public double PbdAll { get; private set; }
        public double PbdNonOcc { get; private set; }
        public double PbdDisc { get; private set; }

        public StereoEvaluator(IStereoDataset dataset,
                               IDisparityResult disparityResult,
                               double threshold, 
                               double normalizationFactor)
        {
            _truthAllDisparityMap = dataset.DisparityMap;
            _truthNonOccDisparityMap = dataset.NonOcclusionMap;
            _truthDiscDisparityMap = dataset.DiscontinuityMap;
            _disparityMap = disparityResult.LeftDisparityMap;
            _threshold = threshold;
            _normalizationFactor = normalizationFactor;

            ComputePbdErrors();
        }

        private void ComputePbdErrors()
        {
            var pbdAllErrors = 0.0d;
            var pbdNonOccErrors = 0.0d;
            var pbdDiscErrors = 0.0d;
            var allEvaluablePixels = 0.0d;
            var nonOccEvaluablePixels = 0.0d;
            var discEvaluablePixels = 0.0d;

            for (var row = 0; row < _disparityMap.Height; row++)
            {
                for (var col = 0; col < _disparityMap.Width; col++)
                {
                    var pixelIntensity = _truthAllDisparityMap[row, col].Intensity;

                    var nonOccValidity = (_truthNonOccDisparityMap != null) ? _truthNonOccDisparityMap[row, col].Intensity : 0;

                    var discValidity = _truthDiscDisparityMap[row, col].Intensity;
                    if (pixelIntensity != 0)
                    {
                        allEvaluablePixels++;

                        if (nonOccValidity != 0)
                        {
                            nonOccEvaluablePixels++;
                        }

                        if (discValidity == 255)
                        {
                            discEvaluablePixels++;
                        }

                        var actualPixelIntensity = _disparityMap[row, col].Intensity;
                        if (Math.Abs(pixelIntensity - actualPixelIntensity) > _threshold * _normalizationFactor)
                        {
                            pbdAllErrors++;

                            if (nonOccValidity != 0)
                            {
                                pbdNonOccErrors++;
                            }

                            if (discValidity == 255)
                            {
                                pbdDiscErrors++;
                            }
                        }
                    }
                }
            }

            PbdAll = (pbdAllErrors / allEvaluablePixels) * 100;
            if (nonOccEvaluablePixels > 0) 
                PbdNonOcc = (pbdNonOccErrors / nonOccEvaluablePixels) * 100;
            if (discEvaluablePixels > 0)
                PbdDisc = (pbdDiscErrors / discEvaluablePixels) * 100;
        }
    }
}
