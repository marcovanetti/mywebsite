﻿using ArteStereo.Images;

namespace ArteStereo.Evaluation.Interfaces
{
    public interface IStereoDataset
    {
        TruecolorImage LeftImage { get; }
        TruecolorImage RightImage { get; }
        GrayscaleImage DisparityMap { get; }
        GrayscaleImage DiscontinuityMap { get; }
        GrayscaleImage NonOcclusionMap { get; }
        double NormalizationFactor { get; }
        double MinimumDisparity { get; }
        double MaximumDisparity { get; }
    }
}