﻿using ArteStereo.Images;

namespace ArteStereo.Evaluation.Interfaces
{
    public interface IDisparityResult
    {
        GrayscaleImage LeftDisparityMap { get; }
    }
}