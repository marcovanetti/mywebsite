﻿namespace ArteStereo.Evaluation.Interfaces
{
    public interface IStereoEvaluator
    {
        double PbdAll { get; }
        double PbdNonOcc { get; }
        double PbdDisc { get; }
    }
}