﻿using System.Linq;
using ArteStereo.Evaluation;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;
using Emgu.CV;
using Emgu.CV.Structure;

namespace ArteStereo.TwoFrameStereoAlgorithms
{
    public class SGBlockMatchingStereo : TwoFrameStereo
    {
        private readonly StereoSGBM _stereoMatcher;

        public SGBlockMatchingStereo(IStereoDataset stereoDataset)
            : base(stereoDataset)
        {
            _stereoMatcher = new StereoSGBM(
            ForceToModule((int) stereoDataset.MinimumDisparity, 16),
            ForceToModule((int) stereoDataset.MaximumDisparity, 16),
            3,
            128,
            256,
            ForceToModule((int)stereoDataset.MaximumDisparity, 16),
            16,
            1,
            100,
            20,
            true);
        }

        public override void Dispose()
        {
            _stereoMatcher.Dispose();
        }

        public override IDisparityResult CalculateLeftDisparityMap()
        {
            var shortDisparityMap = new Image<Gray, short>(StereoDataset.LeftImage.Size);
            _stereoMatcher.FindStereoCorrespondence(StereoDataset.LeftImage.ToGrayscale(), StereoDataset.RightImage.ToGrayscale(), shortDisparityMap);


            var disparityMap = shortDisparityMap.Convert(value =>
                                                             {
                                                                 if (value < 0)
                                                                 {
                                                                     return (byte)0;
                                                                 }
                                                                 return
                                                                     (byte)
                                                                     ((value / 16f) * StereoDataset.NormalizationFactor);
                                                             }).ToGrayscaleImage();

            return new DisparityResult(disparityMap);
        }
    }
}