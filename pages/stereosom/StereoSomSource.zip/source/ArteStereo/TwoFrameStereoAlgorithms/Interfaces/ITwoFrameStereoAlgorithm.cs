﻿using System;
using ArteStereo.Evaluation.Interfaces;

namespace ArteStereo.TwoFrameStereoAlgorithms.Interfaces
{
    public interface ITwoFrameStereoAlgorithm : IDisposable
    {
        IDisparityResult CalculateLeftDisparityMap();
    }
}
