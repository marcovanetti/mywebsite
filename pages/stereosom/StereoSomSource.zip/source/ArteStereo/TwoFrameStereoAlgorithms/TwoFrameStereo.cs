﻿using System;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.TwoFrameStereoAlgorithms.Interfaces;

namespace ArteStereo.TwoFrameStereoAlgorithms
{
    public abstract class TwoFrameStereo : ITwoFrameStereoAlgorithm
    {
        protected readonly IStereoDataset StereoDataset;

        protected TwoFrameStereo(IStereoDataset stereoDataset)
        {
            StereoDataset = stereoDataset;
        }

        public abstract void Dispose();
        public abstract IDisparityResult CalculateLeftDisparityMap();

        public static int ForceToModule(int value, int module)
        {
            if (module <= 0 || value < 0)
            {
                throw new ArgumentException();
            }

            return (value / module) * module + (((double)value % module != 0) ? module : 0);
        }
    }
}
