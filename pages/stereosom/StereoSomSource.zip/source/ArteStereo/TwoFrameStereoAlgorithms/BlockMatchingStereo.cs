﻿using ArteStereo.Evaluation;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;

namespace ArteStereo.TwoFrameStereoAlgorithms
{
    public class BlockMatchingStereo : TwoFrameStereo
    {
        private readonly StereoBM _stereoMatcher;

        public BlockMatchingStereo(IStereoDataset stereoDataset) : base(stereoDataset)
        {
            _stereoMatcher = new StereoBM(STEREO_BM_TYPE.NARROW, ForceToModule((int)stereoDataset.MaximumDisparity, 16));
        }

        public override void Dispose()
        {
            _stereoMatcher.Dispose();
        }

        public override IDisparityResult CalculateLeftDisparityMap()
        {
            var floatDisparityMap = new Image<Gray, float>(StereoDataset.LeftImage.Size);
            _stereoMatcher.FindStereoCorrespondence(StereoDataset.LeftImage.ToGrayscale(), StereoDataset.RightImage.ToGrayscale(), floatDisparityMap);
            var disparityMap = floatDisparityMap.Convert((value, row, col) =>
                                                             {
                                                                 if (value < 0)
                                                                 {
                                                                     return (byte)0;
                                                                 }
                                                                 return
                                                                     (byte)
                                                                     (value * StereoDataset.NormalizationFactor);
                                                             }).ToGrayscaleImage();

            return new DisparityResult(disparityMap);
        }
    }
}