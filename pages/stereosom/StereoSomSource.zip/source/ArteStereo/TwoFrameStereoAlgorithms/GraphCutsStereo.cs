﻿using ArteStereo.Evaluation;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.Images;
using Emgu.CV;
using Emgu.CV.Structure;

namespace ArteStereo.TwoFrameStereoAlgorithms
{
    public class GraphCutsStereo : TwoFrameStereo
    {
        private readonly StereoGC _stereoMatcher;

        public GraphCutsStereo(IStereoDataset stereoDataset) : base(stereoDataset)
        {
            _stereoMatcher = new StereoGC((int)StereoDataset.MaximumDisparity, 3);
        }

        public override void Dispose()
        {
            _stereoMatcher.Dispose();
        }

        public override IDisparityResult CalculateLeftDisparityMap()
        {
            var shortDisparityMap = new Image<Gray, short>(StereoDataset.LeftImage.Size);
            var rightShortDisparity = new Image<Gray, short>(shortDisparityMap.Size);
            _stereoMatcher.FindStereoCorrespondence(StereoDataset.LeftImage.ToGrayscale(), StereoDataset.RightImage.ToGrayscale(), shortDisparityMap, rightShortDisparity);

            var disparityMap = shortDisparityMap.Convert((value, row, col) =>
                                                         (byte)(-value * StereoDataset.NormalizationFactor)).ToGrayscaleImage();

            return new DisparityResult(disparityMap);
        }
    }
}