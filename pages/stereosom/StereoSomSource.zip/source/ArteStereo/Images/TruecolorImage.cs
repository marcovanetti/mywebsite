﻿using System;
using System.Drawing;
using System.Runtime.Serialization;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;

namespace ArteStereo.Images
{
    public class TruecolorImage : Image<Bgr, byte>
    {
        public TruecolorImage(Bitmap bmp) : base(bmp) { }
        public TruecolorImage(GrayscaleImage[] channels) : base(channels) { }
        public TruecolorImage(int width, int height) : base(width, height) { }
        public TruecolorImage(int width, int height, Bgr value) : base(width, height, value) { }
        public TruecolorImage(int width, int height, int stride, IntPtr scan0) : base(width, height, stride, scan0) { }
        public TruecolorImage(SerializationInfo info, StreamingContext context) : base(info, context) { }
        public TruecolorImage(Size size) : base(size) { }
        public TruecolorImage(String fileName) : base(fileName) { }

        public new TruecolorImage Resize (double scale, INTER interpolationType)
        {
            return (TruecolorImage)base.Resize(scale, interpolationType);
        }

        public new TruecolorImage Resize(int width, int height, INTER interpolationType)
        {
            return (TruecolorImage)base.Resize(width, height, interpolationType);
        }

        public new TruecolorImage Resize(int width, int height, INTER interpolationType, bool preserveScale)
        {
            return (TruecolorImage)base.Resize(width, height, interpolationType, preserveScale);
        }

        public GrayscaleImage ToGrayscale()
        {
            var grayscaleImage = new Image<Gray, byte>(Size);
            grayscaleImage.ConvertFrom(this);
            return grayscaleImage.ToGrayscaleImage();
        }
    }
}
