﻿using System;
using System.Drawing;
using System.Runtime.Serialization;
using Emgu.CV;
using Emgu.CV.Structure;

namespace ArteStereo.Images
{
    public class GrayscaleImage : Image<Gray, byte>
    {
        public GrayscaleImage(Bitmap bmp) : base(bmp) { }
        public GrayscaleImage(Image<Gray, byte>[] channels) : base(channels) { }
        public GrayscaleImage(int width, int height) : base(width, height) { }
        public GrayscaleImage(int width, int height, Gray value) : base(width, height, value) { }
        public GrayscaleImage(int width, int height, int stride, IntPtr scan0) : base(width, height, stride, scan0) { }
        public GrayscaleImage(SerializationInfo info, StreamingContext context) : base(info, context) { }
        public GrayscaleImage(Size size) : base(size) { }
        public GrayscaleImage(String fileName) : base(fileName) { }
    }

    public static class GrayscaleExtension
    {
        public static GrayscaleImage ToGrayscaleImage(this Image<Gray, byte> openCvImage)
        {
            return new GrayscaleImage(openCvImage.Split());
        }
    }
}