﻿using System;
using ArteStereo.Evaluation;
using ArteStereo.Evaluation.Interfaces;
using ArteStereo.TwoFrameStereoAlgorithms;
using StereoSom.Engine;
using StereoSom.Session;
using StereoSom.Session.Interfaces;
using StereoSom.Strategies;

namespace StereoSom
{
    public class StereoSomStereo : TwoFrameStereo
    {
        private readonly IStereoSomSession _stereoSomSession;

        public StereoSomStereo(IStereoDataset stereoDataset)
            : base(stereoDataset)
        {
            var width = stereoDataset.LeftImage.Width;
            var height = stereoDataset.LeftImage.Height;

            var defaultParameters = new StereoSomParameters(width, height)
            {
                MaxDisp = (int)stereoDataset.MaximumDisparity,
                MinDisp = (int)stereoDataset.MinimumDisparity,
                NormalizationFactor = stereoDataset.NormalizationFactor,
                ConsistenceCheckStrategy = ConsistenceCheckStrategies.BidirectionalCheck,
                RandomSeed = 84,
                LearningFunction = LearningFunctions.ColorDriven,
                ColorDrivenLearningFunctionVariance = 80,
                LearningFunctionSize = 10,
                LearningFunctionSpreadMax = 0.8,
                LearningFunctionSpreadMin = 0.1,
            };

            _stereoSomSession = new StereoSomSession(stereoDataset.LeftImage, stereoDataset.RightImage, defaultParameters,
                (a, b, c) => Console.Write("{0}% ", (int)(c * 100)));
            _stereoSomSession.AddStrategy(new Ordering(height, width));
            _stereoSomSession.AddStrategy(new Tuning(height, width));
        }

        public override void Dispose()
        {
            _stereoSomSession.Dispose();
        }

        public override IDisparityResult CalculateLeftDisparityMap()
        {
            _stereoSomSession.Execute();
            return new DisparityResult(_stereoSomSession.LeftDisparityMap.ToGrayscale());
        }
    }
}
