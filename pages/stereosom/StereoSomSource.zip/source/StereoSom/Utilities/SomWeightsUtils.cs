﻿using System;
using System.Globalization;
using System.Text;
using ArteStereo.Images;
using Emgu.CV.Structure;
using StereoSom.Utilities.Interfaces;

namespace StereoSom.Utilities
{
    public class SomWeightsUtils : ISomWeightsUtils
    {
        /// <summary>
        /// Serialize an image in a floating point weights array
        /// </summary>
        /// <param name="unserializedImage">3 color channels image</param>
        /// <param name="redWeights">Floating point weights vector for the red RGB channel</param>
        /// <param name="greenWeights">Floating point weights vector for the green RGB channel</param>
        ///  <param name="blueWeights">Floating point weights vector for the blue RGB channel</param>
        public void SerializeImage(TruecolorImage unserializedImage, double[] redWeights, double[] greenWeights, double[] blueWeights)
        {
            var expectedLength = unserializedImage.Width * unserializedImage.Height;
            if (redWeights.Length != expectedLength ||
                greenWeights.Length != expectedLength ||
                blueWeights.Length != expectedLength)
            {
                throw new WrongSizeException("Weight vectors have invalid size and can't contain the serialized image.");
            }

            var unserializedImageData = (byte[, ,])unserializedImage.Data.Clone();

            var i = 0;
            for (var row = 0; row < unserializedImage.Height; row++)
            {
                for (var col = 0; col < unserializedImage.Width; col++, i++)
                {
                    redWeights[i] = unserializedImageData[row, col, 2];
                    greenWeights[i] = unserializedImageData[row, col, 1];
                    blueWeights[i] = unserializedImageData[row, col, 0];
                }
            }
        }

        /// <summary>
        /// Serialize an image in a floating point weights array using the provided normalizationFactor
        /// </summary>
        /// <param name="unserializedGrayImage">"Grayscale compatible" 3 color channels image</param>
        /// <param name="grayWeights">Floating point weights vector</param>
        /// <param name="normalizationFactor">Used to normalize weights during the conversion</param>
        /// <param name="offsetFactor">Weights offset</param>
        public void SerializeImage(TruecolorImage unserializedGrayImage, double[] grayWeights, double normalizationFactor, double offsetFactor)
        {
            var expectedLength = unserializedGrayImage.Width * unserializedGrayImage.Height;
            if (grayWeights.Length != expectedLength)
            {
                throw new WrongSizeException("Weight vectors have invalid size and can't contain the serialized image.");
            }

            var unserializedGrayImageData = (byte[, ,])unserializedGrayImage.Data.Clone();

            var i = 0;
            for (var row = 0; row < unserializedGrayImage.Height; row++)
            {
                for (var col = 0; col < unserializedGrayImage.Width; col++, i++)
                {
                    grayWeights[i] = (unserializedGrayImageData[row, col, 0] / normalizationFactor) + offsetFactor;

                    if (unserializedGrayImageData[row, col, 0] != unserializedGrayImageData[row, col, 1] ||
                        unserializedGrayImageData[row, col, 0] != unserializedGrayImageData[row, col, 2])
                    {
                        throw new GrayscaleCompatibleException("3 color channels unserialized image should be grayscale compatible (for each pixel, R=G=B).");
                    }
                }
            }
        }

        public void SerializeImage(TruecolorImage unserializedGrayImage, double[] grayWeights)
        {
            SerializeImage(unserializedGrayImage, grayWeights, 1.0d, 0d);
        }

        /// <summary>
        /// Deserialize a floating point weights array into an image
        /// </summary>
        /// <param name="serializedRedWeights">Floating point weights vector for the red RGB channel</param>
        /// <param name="serializedGreenWeights">Floating point weights vector for the green RGB channel</param>
        /// <param name="serializedBlueWeights">Floating point weights vector for the blue RGB channel</param>
        /// <param name="outImage">Output 3 color channels image</param>
        public void DeserializeImage(double[] serializedRedWeights, double[] serializedGreenWeights, double[] serializedBlueWeights, TruecolorImage outImage)
        {
            var imageLength = outImage.Width * outImage.Height;
            if (imageLength != serializedRedWeights.Length ||
                imageLength != serializedGreenWeights.Length ||
                imageLength != serializedBlueWeights.Length)
            {
                throw new WrongSizeException("Output image have invalid size and can't contain the unserialized image.");
            }

            var i = 0;
            for (var row = 0; row < outImage.Height; row++)
            {
                for (var col = 0; col < outImage.Width; col++, i++)
                {
                    outImage[row, col] = new Bgr((byte)serializedBlueWeights[i], (byte)serializedGreenWeights[i], (byte)serializedRedWeights[i]);
                }
            }
        }

        /// <summary>
        /// Deserialize a floating point weights array into a textual disparity map representation
        /// </summary>
        /// <param name="serializedGrayWeights">Floating point weights vector</param>
        /// <param name="imageHeight">Stereo image height</param>
        /// <param name="imageWidth">Stereo image width</param>
        /// <returns>Disparity values in textual format</returns>
        public string DeserializeText(double[] serializedGrayWeights, int imageHeight, int imageWidth)
        {
            var deserializedWeights = new StringBuilder();

            deserializedWeights.Append(String.Format("{0} {1}\n", imageHeight, imageWidth));
            var n = 0;
            for (var row = 0; row < imageHeight; row++)
            {
                for (var col = 0; col < imageWidth; col++)
                {
                    deserializedWeights.Append(String.Format(CultureInfo.InvariantCulture, "{0:0.000}", serializedGrayWeights[n]));
                    n++;
                    deserializedWeights.Append((col == imageWidth - 1) ? "\n" : " ");
                }
            }
            return deserializedWeights.ToString();
        }

        /// <summary>
        /// Deserialize a floating point weights array into an image
        /// </summary>
        /// <param name="serializedGrayWeights">Floating point weights vector</param>
        /// <param name="normalizationFactor">The normalization factor used during the serialization</param>
        /// <param name="offsetFactor">Weights offset</param>
        /// <param name="outGrayImage">"Grayscale compatible" 3 color channels image</param>
        public void DeserializeImage(double[] serializedGrayWeights, double normalizationFactor, double offsetFactor, TruecolorImage outGrayImage)
        {
            var imageLength = outGrayImage.Width * outGrayImage.Height;
            if (imageLength != serializedGrayWeights.Length)
            {
                throw new WrongSizeException("Output image have invalid size and can't contain the unserialized image.");
            }

            var i = 0;
            for (var row = 0; row < outGrayImage.Height; row++)
            {
                for (var col = 0; col < outGrayImage.Width; col++, i++)
                {
                    var intensity = (byte)((serializedGrayWeights[i] - offsetFactor) * normalizationFactor);
                    outGrayImage[row, col] = new Bgr(intensity, intensity, intensity);
                }
            }
        }

        public void DeserializeImage(double[] serializedGrayWeights, TruecolorImage outGrayImage)
        {
            DeserializeImage(serializedGrayWeights, 1.0d, 0d, outGrayImage);
        }

        /// <summary>
        /// Initialize SOM "correspondence weights" according with the StereoSOM algorithms
        /// </summary>
        /// <param name="weights">Weight vector</param>
        /// <param name="rows">Weight matrix rows</param>
        /// <param name="columns">Weight matrix columns</param>
        public static void InitializeSomCorrespondenceWeights(double[] weights, int rows, int columns)
        {
            if (weights.Length != (rows * columns))
            {
                throw new ArgumentException("Weight vector size mismatch (must have rows*columns elements).");
            }

            var i = 0;
            for (var r = 1; r <= rows; r++)
            {
                for (var c = 1; c <= columns; c++)
                {
                    weights[i++] = c;
                }
            }
        }

        /// <summary>
        /// Initialize SOM "correspondence weights" according with the StereoSOM algorithms
        /// </summary>
        /// <param name="weights">Weight vector</param>
        /// <param name="rows">Weight matrix rows</param>
        /// <param name="columns">Weight matrix columns</param>
        /// <param name="referenceSom">Determines which Som has to be considered</param>
        /// <returns>Disparity values vector</returns>
        public static double[] CorrespondenceWeights2Disparity(double[] weights, int rows, int columns, SomLocator referenceSom)
        {
            var disparityVector = new double[weights.Length];

            if (weights.Length != (rows * columns))
            {
                throw new ArgumentException("Wrong weight vector size (must have rows*columns elements).");
            }

            var i = 0;
            switch (referenceSom)
            {
                case SomLocator.LeftSom:
                    for (var r = 1; r <= rows; r++)
                    {
                        for (var c = 1; c <= columns; c++)
                        {
                            disparityVector[i] = c - weights[i];
                            i++;
                        }
                    }
                    break;
                case SomLocator.RightSom:
                    for (var r = 1; r <= rows; r++)
                    {
                        for (var c = 1; c <= columns; c++)
                        {
                            disparityVector[i] = weights[i] - c;
                            i++;
                        }
                    }
                    break;
            }

            return disparityVector;
        }
    }

    /// <summary>
    /// Represent the left Som or the Right som
    /// </summary>
    public enum SomLocator
    {
        LeftSom,
        RightSom
    }

    public class WrongSizeException : Exception
    {
        public WrongSizeException(string message) : base(message) { }
    }

    public class GrayscaleCompatibleException : Exception
    {
        public GrayscaleCompatibleException(string message) : base(message) { }
    }
}
