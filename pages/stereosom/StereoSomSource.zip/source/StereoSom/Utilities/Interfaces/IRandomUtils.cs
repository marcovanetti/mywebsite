namespace StereoSom.Utilities.Interfaces
{
    public interface IRandomUtils
    {
        /// <summary>
        /// Set the given integer array to a random permutation of range numbers
        /// </summary>
        /// <param name="permutationLength">Lenght of the permutation vector</param>
        /// <returns>Random permutated vector</returns>
        int[] RandomPermutation(int permutationLength);

        /// <summary>
        /// Extract a random number
        /// </summary>
        /// <param name="minValue">Minimum value</param>
        /// <param name="maxValue">Maximum value</param>
        /// <returns></returns>
        int RandomInt(int minValue, int maxValue);
    }
}