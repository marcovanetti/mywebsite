using ArteStereo.Images;

namespace StereoSom.Utilities.Interfaces
{
    public interface ISomWeightsUtils
    {
        /// <summary>
        /// Serialize an image in a floating point weights array
        /// </summary>
        /// <param name="unserializedImage">3 color channels image</param>
        /// <param name="redWeights">Floating point weights vector for the red RGB channel</param>
        /// <param name="greenWeights">Floating point weights vector for the green RGB channel</param>
        ///  <param name="blueWeights">Floating point weights vector for the blue RGB channel</param>
        void SerializeImage(TruecolorImage unserializedImage, double[] redWeights, double[] greenWeights, double[] blueWeights);

        /// <summary>
        /// Serialize an image in a floating point weights array using the provided normalizationFactor
        /// </summary>
        /// <param name="unserializedGrayImage">"Grayscale compatible" 3 color channels image</param>
        /// <param name="grayWeights">Floating point weights vector</param>
        /// <param name="normalizationFactor">Used to normalize weights during the conversion</param>
        /// <param name="offsetFactor">Weights offset</param>
        void SerializeImage(TruecolorImage unserializedGrayImage, double[] grayWeights, double normalizationFactor, double offsetFactor);

        void SerializeImage(TruecolorImage unserializedGrayImage, double[] grayWeights);

        /// <summary>
        /// Deserialize a floating point weights array into an image
        /// </summary>
        /// <param name="serializedRedWeights">Floating point weights vector for the red RGB channel</param>
        /// <param name="serializedGreenWeights">Floating point weights vector for the green RGB channel</param>
        /// <param name="serializedBlueWeights">Floating point weights vector for the blue RGB channel</param>
        /// <param name="outImage">Output 3 color channels image</param>
        void DeserializeImage(double[] serializedRedWeights,
                              double[] serializedGreenWeights,
                              double[] serializedBlueWeights,
                              TruecolorImage outImage);

        /// <summary>
        /// Deserialize a floating point weights array into a textual disparity map representation
        /// </summary>
        /// <param name="serializedGrayWeights">Floating point weights vector</param>
        /// <param name="imageHeight">Stereo image height</param>
        /// <param name="imageWidth">Stereo image width</param>
        /// <returns>Disparity values in textual format</returns>
        string DeserializeText(double[] serializedGrayWeights, int imageHeight, int imageWidth);

        /// <summary>
        /// Deserialize a floating point weights array into an image
        /// </summary>
        /// <param name="serializedGrayWeights">Floating point weights vector</param>
        /// <param name="normalizationFactor">The normalization factor used during the serialization</param>
        /// <param name="offsetFactor">Weights offset</param>
        /// <param name="outGrayImage">"Grayscale compatible" 3 color channels image</param>
        void DeserializeImage(double[] serializedGrayWeights, double normalizationFactor,
                                             double offsetFactor, TruecolorImage outGrayImage);

        void DeserializeImage(double[] serializedGrayWeights, TruecolorImage outGrayImage);
    }
}