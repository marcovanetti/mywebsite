﻿using System;
using System.Runtime.InteropServices;

namespace StereoSom.Utilities
{
    /// <summary>
    /// Allocate and mantain an array in memory for unmanaged code needs
    /// </summary>
    /// <typeparam name="TArrayType">Array elements type</typeparam>
    /// <creator>Marco Vanetti</creator>
    public class PinnedArray<TArrayType>
    {
        public IntPtr Address { get; private set; }
        public TArrayType[] Array { get; private set; }

        private GCHandle _garbageCollectorHandle;

        /// <summary>
        /// Allocate and pin a new array with given length
        /// </summary>
        /// <param name="arrayLength">PinnedArray length</param>
        public PinnedArray(int arrayLength)
        {
            Array = new TArrayType[arrayLength];
            _garbageCollectorHandle = GCHandle.Alloc(Array, GCHandleType.Pinned);
            Address = _garbageCollectorHandle.AddrOfPinnedObject();
        }

        /// <summary>
        /// Pin an already existent array
        /// </summary>
        /// <param name="existentArray">Existent array</param>
        public PinnedArray(TArrayType[] existentArray)
        {
            Array = existentArray;
            _garbageCollectorHandle = GCHandle.Alloc(Array, GCHandleType.Pinned);
            Address = _garbageCollectorHandle.AddrOfPinnedObject();
        }

        ~PinnedArray()
        {
            _garbageCollectorHandle.Free();
        }
    }   
}
