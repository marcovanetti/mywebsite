using System;
using System.Collections.Generic;
using System.Linq;
using StereoSom.Utilities.Interfaces;

namespace StereoSom.Utilities
{
    public class RandomUtils : IRandomUtils
    {
        private readonly Random _random;

        public RandomUtils()
        {
            _random = new Random();
        }

        /// <summary>
        /// Return a random permutation of integer numbers
        /// </summary>
        /// <param name="permutationLength">Lenght of the permutation vector</param>
        /// <returns>Random permutated vector</returns>
        public int[] RandomPermutation(int permutationLength)
        {
            var ballotBox = Enumerable.Range(1, permutationLength).ToList();
            var rndPermutation = new LinkedList<int>();

            for (var i = 0; i < permutationLength; i++)
            {
                // Extract an element (position based extraction) in the ballot box
                var extractedPosition = RandomInt(0, ballotBox.Count - 1);

                // Add the element extracted to the final permutation
                rndPermutation.AddFirst(ballotBox[extractedPosition]);

                // Remove the element at position fromthe ballot box
                ballotBox.RemoveAt(extractedPosition);
            }

            return rndPermutation.ToArray();
        }

        /// <summary>
        /// Extract a random number
        /// </summary>
        /// <param name="minValue">Minimum value</param>
        /// <param name="maxValue">Maximum value</param>
        /// <returns></returns>
        public virtual int RandomInt(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }
    }
}