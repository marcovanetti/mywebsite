using StereoSom.Engine.Interfaces;

namespace StereoSom.Engine
{   
    public class StereoSomParameters : IStereoSomParameters
    {
        /// <summary>
        /// Minimum disparity
        /// </summary>
        public int MinDisp { get; set; }

        /// <summary>
        /// Minimum vertical disparity (set different from 0 only for non-epipolar images)
        /// </summary>
        public int MinVerticalDisp { get; set; }

        /// <summary>
        /// Maximum disparity
        /// </summary>
        public int? MaxDisp { get; set; }

        /// <summary>
        /// Maximum vertical disparity (set different from 0 only for non-epipolar images)
        /// </summary>
        public int MaxVerticalDisp { get; set; }

        /// <summary>
        /// Normalization Factor
        /// </summary>
        public double? NormalizationFactor { get; set; }

        /// <summary>
        /// Random strategy
        /// </summary>
        public NodeSelectionStrategies NodeSelectionStrategy { get; set; }

        /// <summary>
        /// Random seed
        /// </summary>
        /// <remarks>This property is useful only when <code>NodeSelectionStrategy</code> 
        /// is setted to <code>NodeSelectionStrategies.Random</code></remarks>
        public int RandomSeed { get; set; }

        /// <summary>
        /// Number of iteration the core must execute
        /// </summary>
        public int Iterations { get; set; }

        /// <summary>
        /// Matching function
        /// </summary>
        public MatchingFunctions MatchingFunction { get; set; }

        /// <summary>
        /// Adaptive support size (in points)
        /// </summary>
        public int SupportSize { get; set; }

        /// <summary>
        /// Adaptive support function variance
        /// </summary>
        public double SupportVariance { get; set; }

        /// <summary>
        /// Pixel fraction in the sub-pixel estimation
        /// </summary>
        public double SubPixelSize { get; set; }

        /// <summary>
        /// Importance of the continuity factor for disparity in the 
        /// matching process
        /// </summary>
        public double ContinuityMagnitude { get; set; }

        /// <summary>
        /// Importance of the color factor in the  matching process
        /// </summary>
        public double ColorMagnitude { get; set; }

        /// <summary>
        /// Strategy used in order to manage occlusions
        /// </summary>
        public ConsistenceCheckStrategies ConsistenceCheckStrategy { get; set; }

        /// <summary>
        /// Consistence strategy disparity threshold
        /// </summary>
        public double ConsistenceCheckThreshold { get; set; }

        /// <summary>
        /// Strategy used in order to manage occlusions
        /// </summary>
        public LearningFunctions LearningFunction { get; set; }

        /// <summary>
        /// Color-based learning function variance
        /// </summary>
        public double ColorDrivenLearningFunctionVariance { get; set; }

        /// <summary>
        /// Color-based learning function variance
        /// </summary>
        public int LearningFunctionSize { get; set; }

        /// <summary>
        /// Color-based learning function maximum spread
        /// </summary>
        public double LearningFunctionSpreadMax { get; set; }

        /// <summary>
        /// Color-based learning function minimum spread
        /// </summary>
        public double LearningFunctionSpreadMin { get; set; }

        /// <summary>
        /// _stereoSomEngine default parameters
        /// </summary>
        /// <param name="imageWidth">Image width</param>
        /// <param name="imageHeight">Image height</param>
        public StereoSomParameters(int imageWidth, int imageHeight)
        {
            MaxDisp = imageWidth / 10;
            Iterations = (imageWidth*imageHeight) / 15;
            MinDisp = 0;
            MinVerticalDisp = 0;
            MaxVerticalDisp = 0;
            NodeSelectionStrategy = NodeSelectionStrategies.Random;
            //RandomSeed = DateTime.Now.Millisecond + DateTime.Now.Second;
            RandomSeed = 84;
            MatchingFunction = MatchingFunctions.ZeroMeanEuclidean;
            SupportSize = 3;
            SupportVariance = 300;
            SubPixelSize = 1d/4;
            ContinuityMagnitude = 1;
            ColorMagnitude = 1000;
            ConsistenceCheckStrategy = ConsistenceCheckStrategies.Nothing;
            ConsistenceCheckThreshold = 0;
            LearningFunction = LearningFunctions.Flat;
            ColorDrivenLearningFunctionVariance = 0;
            LearningFunctionSize = 10;
            LearningFunctionSpreadMax = 1;
            LearningFunctionSpreadMin = 1;
        }

        /// <summary>
        /// _stereoSomEngine default parameters based on image size
        /// </summary>
        public StereoSomParameters() : this(200, 200) {}

        /// <summary>
        /// Creates a new StereoSomParameters that is a copy of the current StereoSomParameters instance.
        /// </summary>
        /// <returns>
        /// A new StereoSomParameters that is a copy of this StereoSomParameters instance.
        /// </returns>
        public IStereoSomParameters Clone()
        {
            return (IStereoSomParameters)MemberwiseClone();
        }
    }
}