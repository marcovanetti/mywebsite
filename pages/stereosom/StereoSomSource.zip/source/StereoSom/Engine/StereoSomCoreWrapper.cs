﻿using System;
using System.Runtime.InteropServices;

namespace StereoSom.Engine
{
    public static class StereoSomCoreWrapper
    {
        [DllImport("StereoSomEngine")]
        public static extern void RunEngine(IntPtr session);

        // SOM image
        public struct SSom
        {
            // Red channel weights
            public IntPtr rW;                   // double[]
            // Green channel weights
            public IntPtr gW;                   // double[]
            // Blue channel weights
            public IntPtr bW; // double[]
            // Vertical correspondence weights
            public IntPtr vCorrW;               // double[]

            // Matching errors
            public IntPtr matchingErr;          // int[]
            // Consistence errors
            public IntPtr consistenceErr;       // int[]

            // Truth disparity data
            public IntPtr expectedDisp;         // double[]

            // Random point permutation (used by node selection)
            public IntPtr randomPermutation;    // int[]
            // Progressive index used to access random poit permutation
            public int randomPermutationProgression;
        };

        /// <summary>
        /// Stereo session image
        /// </summary>
        public struct StereoSomCoreSession
        {
            // Image size
            public int IRows;
            public int IColumns;
        	
            // Disparity constraint
            public int minDisp;
            public int minVDisp;
            public int maxDisp;
            public int maxVDisp;
        	
            // Node selection strategy
            public int nodeSelStrategy;
            
            // Iterations
            public int coreIterations;
        	
            // Matching strategy
            public int matchingFunction;
            public int searchEye;
            public double oSearch;
            public double subPixGran;
            public double dispWeight;
            public double colorWeight;
            
            // Consistence check strategy
            public int searchMode;
            public double qualityThreshold;
        	
            // Weight updating strategy
            public int enableGTerm;
            public double ogk;	
            public int neighSize;
            public double alpha;
            public double gaussBorder;
            
            // SOM data
            public SSom lSSom;
            public SSom rSSom;
        }
    }
}