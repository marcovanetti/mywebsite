namespace StereoSom.Engine.Interfaces
{
    public interface IStereoSomParameters
    {
        /// <summary>
        /// Minimum disparity
        /// </summary>
        int MinDisp { get; set; }

        /// <summary>
        /// Minimum vertical disparity (set different from 0 only for non-epipolar images)
        /// </summary>
        int MinVerticalDisp { get; set; }

        /// <summary>
        /// Maximum disparity
        /// </summary>
        int? MaxDisp { get; set; }

        /// <summary>
        /// Maximum vertical disparity (set different from 0 only for non-epipolar images)
        /// </summary>
        int MaxVerticalDisp { get; set; }

        /// <summary>
        /// Normalization Factor
        /// </summary>
        double? NormalizationFactor { get; set; }

        /// <summary>
        /// Random strategy
        /// </summary>
        NodeSelectionStrategies NodeSelectionStrategy { get; set; }

        /// <summary>
        /// Random seed
        /// </summary>
        /// <remarks>This property is useful only when <code>NodeSelectionStrategy</code> 
        /// is setted to <code>NodeSelectionStrategies.Random</code></remarks>
        int RandomSeed { get; set; }

        /// <summary>
        /// Number of iteration the core must execute
        /// </summary>
        int Iterations { get; set; }

        /// <summary>
        /// Matching function
        /// </summary>
        MatchingFunctions MatchingFunction { get; set; }

        /// <summary>
        /// Adaptive support size (in points)
        /// </summary>
        int SupportSize { get; set; }

        /// <summary>
        /// Adaptive support function variance
        /// </summary>
        double SupportVariance { get; set; }

        /// <summary>
        /// Pixel fraction in the sub-pixel estimation
        /// </summary>
        double SubPixelSize { get; set; }

        /// <summary>
        /// Importance of the continuity factor for disparity in the 
        /// matching process
        /// </summary>
        double ContinuityMagnitude { get; set; }

        /// <summary>
        /// Importance of the color factor in the  matching process
        /// </summary>
        double ColorMagnitude { get; set; }

        /// <summary>
        /// Strategy used in order to manage occlusions
        /// </summary>
        ConsistenceCheckStrategies ConsistenceCheckStrategy { get; set; }

        /// <summary>
        /// Consistence strategy disparity threshold
        /// </summary>
        double ConsistenceCheckThreshold { get; set; }

        /// <summary>
        /// Strategy used in order to manage occlusions
        /// </summary>
        LearningFunctions LearningFunction { get; set; }

        /// <summary>
        /// Color-based learning function variance
        /// </summary>
        double ColorDrivenLearningFunctionVariance { get; set; }

        /// <summary>
        /// Color-based learning function variance
        /// </summary>
        int LearningFunctionSize { get; set; }

        /// <summary>
        /// Color-based learning function maximum spread
        /// </summary>
        double LearningFunctionSpreadMax { get; set; }

        /// <summary>
        /// Color-based learning function minimum spread
        /// </summary>
        double LearningFunctionSpreadMin { get; set; }

        /// <summary>
        /// Creates a new StereoSomParameters that is a copy of the current StereoSomParameters instance.
        /// </summary>
        /// <returns>
        /// A new StereoSomParameters that is a copy of this StereoSomParameters instance.
        /// </returns>
        IStereoSomParameters Clone();
    }
}