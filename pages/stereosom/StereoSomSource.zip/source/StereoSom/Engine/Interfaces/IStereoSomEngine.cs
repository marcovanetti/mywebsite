namespace StereoSom.Engine.Interfaces
{
    public interface IStereoSomEngine
    {
        /// <summary>
        /// StereoSomSession parameters
        /// </summary>
        IStereoSomParameters Parameters { get; set; }

        /// <summary>
        /// Image height for current session
        /// </summary>
        int ImageHeight { get; }

        /// <summary>
        /// Image width for current session
        /// </summary>
        int ImageWidth { get; }

        /// <summary>
        /// Give the disparity vector for the left SOM
        /// </summary>
        double[] LeftDisparityVector { get; }

        /// <summary>
        /// Give the disparity vector for the right SOM
        /// </summary>
        double[] RightDisparityVector { get; }

        /// <summary>
        /// Run the Stereo SOM engine
        /// </summary>
        void Execute();

        /// <summary>
        /// Set "dynamic" (e.g. images size dependent) default values for parameters
        /// </summary>
        void SetDynamicDefaultParameters();
    }
}