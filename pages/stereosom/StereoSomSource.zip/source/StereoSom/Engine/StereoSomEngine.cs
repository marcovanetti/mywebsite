using System;
using System.Runtime.InteropServices;
using ArteStereo.Images;
using StereoSom.Engine.Interfaces;
using StereoSom.Utilities;

namespace StereoSom.Engine
{
    public class StereoSomEngine : IStereoSomEngine
    {
        #region Properties

        /// <summary>
        /// StereoSomSession parameters
        /// </summary>
        public IStereoSomParameters Parameters
        {
            get
            {
                return _stereoSomParameters;
            }

            set
            {
                _stereoSomParameters.NormalizationFactor 
                                                = value.NormalizationFactor;
                _coreSession.minDisp           = (_stereoSomParameters.MinDisp = value.MinDisp);
                _coreSession.minVDisp          = (_stereoSomParameters.MinVerticalDisp = value.MinVerticalDisp);
                _coreSession.maxDisp           = ((_stereoSomParameters.MaxDisp = value.MaxDisp) ?? 0);
                _coreSession.maxVDisp          = (_stereoSomParameters.MaxVerticalDisp = value.MaxVerticalDisp);
                _coreSession.nodeSelStrategy   = (int)(_stereoSomParameters.NodeSelectionStrategy = value.NodeSelectionStrategy);
                _coreSession.lSSom.randomPermutationProgression 
                                            = (_stereoSomParameters.RandomSeed = value.RandomSeed);
                _coreSession.coreIterations    = (_stereoSomParameters.Iterations = value.Iterations);
                _coreSession.matchingFunction  = (int)(_stereoSomParameters.MatchingFunction = value.MatchingFunction);
                _coreSession.searchEye         = (_stereoSomParameters.SupportSize = value.SupportSize);
                _coreSession.oSearch           = (_stereoSomParameters.SupportVariance = value.SupportVariance);
                _coreSession.subPixGran        = (_stereoSomParameters.SubPixelSize = value.SubPixelSize);
                _coreSession.dispWeight        = (_stereoSomParameters.ContinuityMagnitude = value.ContinuityMagnitude);
                _coreSession.colorWeight       = (_stereoSomParameters.ColorMagnitude = value.ColorMagnitude);
                _coreSession.searchMode        = (int)(_stereoSomParameters.ConsistenceCheckStrategy = value.ConsistenceCheckStrategy);
                _coreSession.qualityThreshold  = (_stereoSomParameters.ConsistenceCheckThreshold = value.ConsistenceCheckThreshold);
                _coreSession.enableGTerm       = (int)(_stereoSomParameters.LearningFunction = value.LearningFunction);
                _coreSession.ogk               = (_stereoSomParameters.ColorDrivenLearningFunctionVariance = value.ColorDrivenLearningFunctionVariance);
                _coreSession.neighSize         = (_stereoSomParameters.LearningFunctionSize = value.LearningFunctionSize);
                _coreSession.alpha             = (_stereoSomParameters.LearningFunctionSpreadMax = value.LearningFunctionSpreadMax);
                _coreSession.gaussBorder       = (_stereoSomParameters.LearningFunctionSpreadMin = value.LearningFunctionSpreadMin);
            }
        }

        /// <summary>
        /// Image height for current session
        /// </summary>
        public int ImageHeight { get { return _coreSession.IRows; } }

        /// <summary>
        /// Image width for current session
        /// </summary>
        public int ImageWidth { get { return _coreSession.IColumns; } }

        /// <summary>
        /// Give the disparity vector for the left SOM
        /// </summary>
        public double[] LeftDisparityVector
        {
            get
            {
                return SomWeightsUtils.CorrespondenceWeights2Disparity(_lVCorrW.Array, _coreSession.IRows,
                                                                                          _coreSession.IColumns,
                                                                                          SomLocator.LeftSom);
            }
        }

        /// <summary>
        /// Give the disparity vector for the right SOM
        /// </summary>
        public double[] RightDisparityVector
        {
            get
            {
                return SomWeightsUtils.CorrespondenceWeights2Disparity(_rVCorrW.Array, _coreSession.IRows,
                                                                                          _coreSession.IColumns,
                                                                                          SomLocator.RightSom);
            }
        }

        #endregion Properties

        #region SOM Data

        private readonly PinnedArray<double> _lRw;
        private readonly PinnedArray<double> _lGw;
        private readonly PinnedArray<double> _lBw;
        private readonly PinnedArray<double> _lVCorrW;
        private readonly PinnedArray<int> _lMatchingErr;
        private readonly PinnedArray<int> _lConsistenceErr;
        private readonly PinnedArray<double> _lExpectedDisp;
        private readonly PinnedArray<int> _lRndPermutation;

        private readonly PinnedArray<double> _rRw;
        private readonly PinnedArray<double> _rGw;
        private readonly PinnedArray<double> _rBw;
        private readonly PinnedArray<double> _rVCorrW;
        private readonly PinnedArray<int> _rMatchingErr;
        private readonly PinnedArray<int> _rConsistenceErr;
        private readonly PinnedArray<double> _rExpectedDisp;
        private readonly PinnedArray<int> _rRndPermutation;

        #endregion

        private readonly IStereoSomParameters _stereoSomParameters = new StereoSomParameters();
        private readonly SomWeightsUtils _somWeightsUtils;
        //private readonly RandomUtils _randomUtils;
        private StereoSomCoreWrapper.StereoSomCoreSession _coreSession;

        /// <summary>
        /// Run StereoSOM engine on given parameters
        /// </summary>
        /// <param name="leftImage">Left stereo image</param>
        /// <param name="rightImage">Right stereo image</param>
        public StereoSomEngine(TruecolorImage leftImage, TruecolorImage rightImage)
            : this(leftImage, rightImage, new SomWeightsUtils(), new RandomUtils()) { }

        /// <summary>
        /// Only for testing purposes
        /// </summary>
        public StereoSomEngine(TruecolorImage leftImage, TruecolorImage rightImage, SomWeightsUtils weightsSerializer, RandomUtils randomUtils)
        {
            //_randomUtils = randomUtils;
            _somWeightsUtils = weightsSerializer;

            // Stereo SOM session, contains all data exchanged between the StereoSomSession engine and this application
            _coreSession = new StereoSomCoreWrapper.StereoSomCoreSession();

            // Pixel format check
            if (leftImage.NumberOfChannels != 3 || rightImage.NumberOfChannels != 3)
            {
                Console.WriteLine("Wrong number of channels: l:{0} r:{1}", leftImage.NumberOfChannels, rightImage.NumberOfChannels);
                throw new ArgumentException("Only 3 color channels stereo images are supported.");
            }

            // Dimension check
            if (leftImage.Width != rightImage.Width || leftImage.Height != rightImage.Height)
            {
                throw new ArgumentException("Stereo images must have the same size.");
            }

            _coreSession.IRows = leftImage.Height;
            _coreSession.IColumns = leftImage.Width;
            var dataLength = _coreSession.IRows * _coreSession.IColumns;

            // Allocate Left SOM Data
                _lRw = new PinnedArray<double>(dataLength);
                _lGw = new PinnedArray<double>(dataLength);
                _lBw = new PinnedArray<double>(dataLength);
                _lVCorrW = new PinnedArray<double>(dataLength);
                _lMatchingErr = new PinnedArray<int>(dataLength);
                _lConsistenceErr = new PinnedArray<int>(dataLength);
                _lExpectedDisp = new PinnedArray<double>(dataLength);

            // Initialize Left SOM Data
                _somWeightsUtils.SerializeImage(leftImage, _lRw.Array, _lGw.Array, _lBw.Array);
                SomWeightsUtils.InitializeSomCorrespondenceWeights(_lVCorrW.Array, _coreSession.IRows, _coreSession.IColumns);
                // TODO: truth disparity map (_lExpectedDisp)
                //_lRndPermutation = new PinnedArray<int>(_randomUtils.RandomPermutation(dataLength));
                _lRndPermutation = new PinnedArray<int>(dataLength);

            // Allocate Right SOM Data
                _rRw = new PinnedArray<double>(dataLength);
                _rGw = new PinnedArray<double>(dataLength);
                _rBw = new PinnedArray<double>(dataLength);
                _rVCorrW = new PinnedArray<double>(dataLength);
                _rMatchingErr = new PinnedArray<int>(dataLength);
                _rConsistenceErr = new PinnedArray<int>(dataLength);
                _rExpectedDisp = new PinnedArray<double>(dataLength);

            // Initialize Right SOM Data
                _somWeightsUtils.SerializeImage(rightImage, _rRw.Array, _rGw.Array, _rBw.Array);
                SomWeightsUtils.InitializeSomCorrespondenceWeights(_rVCorrW.Array, _coreSession.IRows, _coreSession.IColumns);
                // TODO: truth disparity map (_rExpectedDisp)
                _rRndPermutation = _lRndPermutation;

            _coreSession.lSSom = new StereoSomCoreWrapper.SSom
                                {
                                      rW = _lRw.Address,
                                      gW = _lGw.Address,
                                      bW = _lBw.Address,
                                      vCorrW = _lVCorrW.Address,
                                      matchingErr = _lMatchingErr.Address,
                                      consistenceErr = _lConsistenceErr.Address,
                                      expectedDisp = _lExpectedDisp.Address,
                                      randomPermutation = _lRndPermutation.Address,
                                      randomPermutationProgression = 0,
                                };

            _coreSession.rSSom = new StereoSomCoreWrapper.SSom
                                {
                                    rW = _rRw.Address,
                                    gW = _rGw.Address,
                                    bW = _rBw.Address,
                                    vCorrW = _rVCorrW.Address,
                                    matchingErr = _rMatchingErr.Address,
                                    consistenceErr = _rConsistenceErr.Address,
                                    expectedDisp = _rExpectedDisp.Address,
                                    randomPermutation = _rRndPermutation.Address,
                                    randomPermutationProgression = 0,
                                };
            
            // Default values for private session fields
            Parameters = new StereoSomParameters(_coreSession.IColumns, _coreSession.IRows);
        }

        /// <summary>
        /// Run the Stereo SOM engine
        /// </summary>
        public void Execute()
        {
            // Invoke Parameters' setter
            Parameters = _stereoSomParameters;

            // Marshal session structure
            var callSession = Marshal.AllocHGlobal(Marshal.SizeOf(_coreSession));
            Marshal.StructureToPtr(_coreSession, callSession, false);
            
            // Run engine
            StereoSomCoreWrapper.RunEngine(callSession);

            // Unmarshal session structure
            _coreSession = (StereoSomCoreWrapper.StereoSomCoreSession)Marshal.PtrToStructure(
                callSession, typeof(StereoSomCoreWrapper.StereoSomCoreSession));
            Marshal.FreeHGlobal(callSession);
        }

        /// <summary>
        /// Set "dynamic" (e.g. images size dependent) default values for parameters
        /// </summary>
        public void SetDynamicDefaultParameters()
        {
            var defaultMaxDisp = ImageWidth;
            if (Parameters.MaxDisp == null)
            {
                Parameters.MaxDisp = defaultMaxDisp;
            }
            if (Parameters.MinDisp >= Parameters.MaxDisp)
            {
                Parameters.MinDisp = 0;
                Parameters.MaxDisp = defaultMaxDisp;
            }
            
            var defaultNormFactor = Math.Floor((255d / ((int)Parameters.MaxDisp - Parameters.MinDisp)));
            if (Parameters.NormalizationFactor == null || Parameters.NormalizationFactor > defaultNormFactor)
            {
                Parameters.NormalizationFactor = defaultNormFactor;
            }
        }
    }

    /// <summary>
    /// Supported node selection strategies
    /// </summary>
    public enum NodeSelectionStrategies
    {
        Random = 0,
        RandomPermutation = 1
    }

    /// <summary>
    /// Supported matching functions
    /// </summary>
    public enum MatchingFunctions
    {
        Euclidean = 0,
        ZeroMeanEuclidean = 1,
        //NormalizedCrossCorrelation = 2
    }

    /// <summary>
    /// Strategies used in order to manage occlusions
    /// </summary>
    public enum ConsistenceCheckStrategies
    {
        Nothing = 0,
        BidirectionalCheck = 1
    }

    /// <summary>
    /// Supported learning functions
    /// </summary>
    public enum LearningFunctions
    {
        Flat = 0,
        ColorDriven = 1
    }
}