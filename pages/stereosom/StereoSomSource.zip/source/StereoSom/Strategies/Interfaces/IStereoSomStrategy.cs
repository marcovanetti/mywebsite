using System.Collections.Generic;

namespace StereoSom.Strategies.Interfaces
{
    public interface IStereoSomStrategy
    {
        /// <summary>
        /// Phases for this strategy
        /// </summary>
        IEnumerable<IStereoSomPhase> StrategyPhases { get; }
    }
}