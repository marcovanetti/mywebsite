using StereoSom.Engine.Interfaces;

namespace StereoSom.Strategies.Interfaces
{
    public interface IStereoSomPhase
    {
        /// <summary>
        /// Phase name
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Event called on each iteration completed
        /// </summary>
        event StereoSomPhase.StereoSomPhaseCallback OnInternalIterationCycleDone;

        /// <summary>
        /// Execute the phase
        /// </summary>
        /// <param name="stereoSomEngine">StereoSomSession engine instance to use</param>
        /// <param name="coreInternalIterations">Core's internal iterations (with constant parameters)</param>
        void Execute(IStereoSomEngine stereoSomEngine, int coreInternalIterations);

        void Execute(IStereoSomEngine stereoSomEngine);
    }
}