using System.Collections.Generic;
using StereoSom.Engine;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Strategies
{
    /// <summary>
    /// Contains a StereoSomSession strategy (collection of StereoSomPhase)
    /// </summary>
    public class DiscoverDisparityRange : IStereoSomStrategy
    {
        public const int ScaledImageHeight = 100;
        public const int ScaledImageWidth = 200;

        /// <summary>
        /// Phases for this strategy
        /// </summary>
        public IEnumerable<IStereoSomPhase> StrategyPhases
        {
            get
            {
                // Phase catalyzers
                var parameterCatalyzers =
                    new List<StereoSomPhase.ParameterCatalyzer>
                        {
                            // Parameters initialization
                            (progression, currentParameters) =>
                                {
                                    if (progression == 0)
                                    {
                                        currentParameters.Iterations = (ScaledImageHeight * ScaledImageWidth)/4;
                                        currentParameters.ContinuityMagnitude = 1;
                                        currentParameters.ColorMagnitude = 1000;
                                        currentParameters.LearningFunction = LearningFunctions.Flat;
                                        currentParameters.LearningFunctionSpreadMax = 1;
                                        currentParameters.LearningFunctionSpreadMin = 0.01;
                                        currentParameters.ConsistenceCheckStrategy =
                                            ConsistenceCheckStrategies.BidirectionalCheck;
                                        currentParameters.SupportSize = 3;
                                        currentParameters.SupportVariance = 300;
                                        currentParameters.SubPixelSize = 1d/4;
                                    }
                                    return currentParameters;
                                },
                            // Gradually reduce learning function size
                            (progression, currentParameters) =>
                                {
                                    currentParameters.LearningFunctionSize = (int)    
                                        StereoSomStrategyUtils.LinearTrend(50, 5,
                                                                           progression);
                                    return currentParameters;
                                }
                        };

                return new List<IStereoSomPhase>
                           {
                               new StereoSomPhase("disparity range discover", ScaledImageHeight * ScaledImageWidth, parameterCatalyzers)
                           };
            }
        }
    }
}