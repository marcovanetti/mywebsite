﻿using System.Linq;
using StereoSom.Session.Interfaces;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Strategies
{
    public static class StereoSomStrategyUtils
    {
        /// <summary>
        /// Simulate a linear function between start and end values
        /// </summary>
        /// <param name="start">Linear function start value</param>
        /// <param name="end">Linear function end value</param>
        /// <param name="progression">State of the progression</param>
        /// <returns>Linear function current value</returns>
        public static double LinearTrend(double start, double end, double progression)
        {
            return start + (end - start)*progression;
        }

        /// <summary>
        /// Add a strategy to the StereoSomSession session
        /// </summary>
        /// <param name="stereoSomSession">StereoSomSession session</param>
        /// <param name="stereoSomStrategy">Strategy to add</param>
        public static void AddStrategy(this IStereoSomSession stereoSomSession, IStereoSomStrategy stereoSomStrategy)
        {
            stereoSomSession.StereoSomPhases = stereoSomSession.StereoSomPhases.Union(stereoSomStrategy.StrategyPhases);
        }
    }
}
