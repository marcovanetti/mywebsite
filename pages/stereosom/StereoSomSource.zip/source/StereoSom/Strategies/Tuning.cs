﻿using System.Collections.Generic;
using StereoSom.Engine;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Strategies
{
    /// <summary>
    /// Contains a StereoSomSession strategy (collection of StereoSomPhase)
    /// </summary>
    public class Tuning : IStereoSomStrategy
    {
        private readonly TuningParameters _tuningParams;

        /// <summary>
        /// Phases for this strategy
        /// </summary>
        public IEnumerable<IStereoSomPhase> StrategyPhases
        {
            get
            {
                // Phase catalyzers
                var parameterCatalyzers =
                    new List<StereoSomPhase.ParameterCatalyzer>
                        {
                            // Parameters initialization
                            (progression, currentParameters) =>
                                {
                                    if (progression == 0)
                                    {
                                        currentParameters.Iterations = (int)_tuningParams.Iterations;
                                        currentParameters.ColorMagnitude = _tuningParams.ColorMagnitude;
                                        currentParameters.ContinuityMagnitude = _tuningParams.ContinuityMagnitude;
                                        currentParameters.LearningFunctionSize = _tuningParams.LearningSize;
                                        currentParameters.LearningFunction = LearningFunctions.ColorDriven;
                                        currentParameters.ColorDrivenLearningFunctionVariance =
                                            _tuningParams.ColorDrivenlearningFunctionVariance;
                                    }
                                    return currentParameters;
                                },
                            // Gradually reduce LearningFunctionSpreadMax
                            (progression, currentParameters) =>
                                {
                                    currentParameters.LearningFunctionSpreadMax =
                                                StereoSomStrategyUtils.LinearTrend(_tuningParams.StartLearningFunctionSpreadMax,
                                                                        _tuningParams.EndLearningFunctionSpreadMax, progression);
                                    return currentParameters;
                                },
                            // Gradually reduce LearningFunctionSpreadMin
                            (progression, currentParameters) =>
                                {
                                    currentParameters.LearningFunctionSpreadMin =
                                                StereoSomStrategyUtils.LinearTrend(_tuningParams.StartLearningFunctionSpreadMin,
                                                                        _tuningParams.EndLearningFunctionSpreadMin, progression);
                                    return currentParameters;
                                }
                        };

                return new List<IStereoSomPhase>
                           {
                               new StereoSomPhase("tuning", (int)_tuningParams.Iterations, parameterCatalyzers)
                           };
            }
        }

        /// <summary>
        /// Create a Tuning StereoSomSession strategy
        /// </summary>
        public Tuning(int imageHeight, int imageWidth, TuningParameters tuningParams)
        {
            if (tuningParams.Iterations == null)
            {
                switch (tuningParams.Accuracy)
                {
                    case 0:
                        tuningParams.Iterations = (imageWidth * imageHeight) / 4;
                        break;
                    case 1:
                        tuningParams.Iterations = (imageWidth * imageHeight) / 2;
                        break;
                    case 2:
                        tuningParams.Iterations = (imageWidth * imageHeight);
                        break;
                    case 3:
                        tuningParams.Iterations = (imageWidth * imageHeight) * 2;
                        break;
                    case 4:
                        tuningParams.Iterations = (imageWidth * imageHeight) * 4;
                        break;
                }
            }
            _tuningParams = tuningParams;
        }

        /// <summary>
        /// Create a Tuning StereoSomSession strategy
        /// </summary>
        public Tuning(int imageHeight, int imageWidth)
            : this(imageHeight, imageWidth, new TuningParameters
                                                {
                                                    Iterations = null,
                                                    ColorMagnitude = 20,
                                                    ContinuityMagnitude = 1,
                                                    LearningSize = 20,
                                                    StartLearningFunctionSpreadMax = 6,
                                                    EndLearningFunctionSpreadMax = 1,
                                                    StartLearningFunctionSpreadMin = 6f/10,
                                                    EndLearningFunctionSpreadMin = 1f/10,
                                                    ColorDrivenlearningFunctionVariance = 80,
                                                    Accuracy = 0,
                                                }

                ) {}
    }

    /// <summary>
    /// Parameters for the tuning phase
    /// </summary>
    public class TuningParameters
    {
        public int? Iterations { get; set; }
        public double ColorMagnitude { get; set; }
        public double ContinuityMagnitude { get; set; }
        public int LearningSize { get; set; }
        public double StartLearningFunctionSpreadMax { get; set; }
        public double EndLearningFunctionSpreadMax { get; set; }
        public double StartLearningFunctionSpreadMin { get; set; }
        public double EndLearningFunctionSpreadMin { get; set; }
        public double ColorDrivenlearningFunctionVariance { get; set; }
        public int Accuracy { get; set; }
    }
}
