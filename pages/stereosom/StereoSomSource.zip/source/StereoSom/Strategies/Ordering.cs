﻿using System.Collections.Generic;
using StereoSom.Engine;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Strategies
{
    /// <summary>
    /// Contains a StereoSomSession strategy (collection of StereoSomPhase)
    /// </summary>
    public class Ordering : IStereoSomStrategy
    {
        private readonly OrderingParameters _orderingParams;

        /// <summary>
        /// Phases for this strategy
        /// </summary>
        public IEnumerable<IStereoSomPhase> StrategyPhases
        {
            get
            {
                // Phase catalyzers
                var parameterCatalyzers =
                    new List<StereoSomPhase.ParameterCatalyzer>
                        {
                            // Parameters initialization
                            (progression, currentParameters) =>
                                {
                                    if (progression == 0)
                                    {
                                        currentParameters.Iterations = (int)_orderingParams.Iterations;
                                        currentParameters.ContinuityMagnitude = _orderingParams.ContinuityMagnitude;
                                        currentParameters.ColorMagnitude = _orderingParams.ColorMagnitude;
                                        currentParameters.LearningFunction = LearningFunctions.Flat;
                                        currentParameters.LearningFunctionSpreadMax = 1;
                                        currentParameters.LearningFunctionSpreadMin = (bool)_orderingParams.Smoothed ? 0.01 : 1;
                                    }
                                    return currentParameters;
                                },
                            // Gradually reduce learning function size
                            (progression, currentParameters) =>
                                {
                                    currentParameters.LearningFunctionSize = (int)    
                                        StereoSomStrategyUtils.LinearTrend(_orderingParams.StartLearningSize, _orderingParams.EndLearningSize,
                                                                           progression);
                                    return currentParameters;
                                }
                        };

                return new List<IStereoSomPhase>
                           {
                               new StereoSomPhase("ordering", (int)_orderingParams.Iterations, parameterCatalyzers)
                           };
            }
        }

        /// <summary>
        /// Create a Flat Ordering StereoSomSession strategy
        /// </summary>
        public Ordering(int imageHeight, int imageWidth, OrderingParameters orderingParams)
        {
            if (orderingParams.Iterations == null)
            {
                orderingParams.Iterations = (imageWidth * imageHeight) / 15;
            }
            _orderingParams = orderingParams;
        }

        /// <summary>
        /// Create a Flat Ordering StereoSomSession strategy
        /// </summary>
        public Ordering(int imageHeight, int imageWidth)
            : this(imageHeight, imageWidth, new OrderingParameters
                                                {
                                                    Iterations = null,
                                                    ColorMagnitude = 1000,
                                                    ContinuityMagnitude = 1,
                                                    StartLearningSize = 80,
                                                    EndLearningSize = 10,
                                                    Smoothed = false
                                                }) {}
    }

    /// <summary>
    /// Parameters for the ordering phase
    /// </summary>
    public class OrderingParameters
    {
        public int? Iterations { get; set; }
        public double ColorMagnitude { get; set; }
        public double ContinuityMagnitude { get; set; }
        public int StartLearningSize { get; set; }
        public int EndLearningSize { get; set; }
        public bool? Smoothed { get; set; }
    }
}
