using System;
using System.Collections.Generic;
using StereoSom.Engine.Interfaces;
using System.Linq;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Strategies
{
    /// <summary>
    /// Represent a StereoSomSession phase (eg. Ordering and Tuning)
    /// </summary>
    public class StereoSomPhase : IStereoSomPhase
    {
        /// <summary>
        /// Phase name
        /// </summary>
        public string Name { get; private set; }
        
        /// <summary>
        /// Event called ever compled core iteration cycle
        /// </summary>
        public event StereoSomPhaseCallback OnInternalIterationCycleDone;

        /// <summary>
        /// Delegate a function that should define a parameters evolution
        /// </summary>
        /// <param name="progression">Algorithm progression (0.0 - 1.0)</param>
        /// <param name="currentParameters">Current parameters</param>
        /// <returns>Evolved parameters</returns>
        public delegate IStereoSomParameters ParameterCatalyzer(double progression, IStereoSomParameters currentParameters);

        /// <summary>
        /// Function called ever compled core iteration cycle
        /// </summary>
        /// <param name="stereoSomEngine">instance of the StereoSom engine</param>
        /// <param name="stereoSomPhase">instance of the current StereoSom phase</param>
        /// <param name="progression">Current phase progression (from 0 to 1)</param>
        public delegate void StereoSomPhaseCallback(IStereoSomEngine stereoSomEngine, IStereoSomPhase stereoSomPhase, double progression);

        private readonly int _phaseIterations;
        private readonly IEnumerable<ParameterCatalyzer> _parameterCatalyzers = new List<ParameterCatalyzer>();      

        /// <summary>
        /// Create a StereoSomPhase
        /// </summary>
        /// <param name="phaseName">Phase name</param>
        /// <param name="phaseIterations">Number of iterations for this phase</param>
        /// <param name="parameterCatalyzers">List of parameters catalyzers for this phase</param>
        public StereoSomPhase(string phaseName, int phaseIterations, IEnumerable<ParameterCatalyzer> parameterCatalyzers)
        {
            if (phaseName == null) throw new ArgumentNullException("phaseName");
            if (phaseIterations < 0) throw new ArgumentNullException("phaseIterations", "must be >= 0");
            if (parameterCatalyzers == null) throw new ArgumentNullException("parameterCatalyzers");
            if (!parameterCatalyzers.Any()) throw new ArgumentException("parameterCatalyzers can't be empty");

            Name = phaseName;
            _phaseIterations = phaseIterations;
            _parameterCatalyzers = parameterCatalyzers.ToList();
        }

        /// <summary>
        /// Execute the phase
        /// </summary>
        /// <param name="stereoSomEngine">StereoSomSession engine instance to use</param>
        /// <param name="coreInternalIterations">Core's internal iterations (with constant parameters)</param>
        public void Execute(IStereoSomEngine stereoSomEngine, int coreInternalIterations)
        {
            if (_phaseIterations == 0)
            {
                return;
            }

            var totalCoreIt = Math.Ceiling((double)_phaseIterations / coreInternalIterations);

            for (int coreIt = 0; coreIt < totalCoreIt; coreIt++)
            {
                // Algorithm progression
                var progression = coreIt/(totalCoreIt - 1d);

                // Apply catalyzers to the parameters
                foreach (var catalyzer in _parameterCatalyzers)
                {
                    stereoSomEngine.Parameters = catalyzer(progression, stereoSomEngine.Parameters);
                }

                // Run the engine
                stereoSomEngine.Parameters.Iterations = coreInternalIterations;
                stereoSomEngine.Execute();

                // Raise OnInternalIterationCycleDone event
                if (OnInternalIterationCycleDone != null)
                {
                    OnInternalIterationCycleDone(stereoSomEngine, this, progression);
                }
            }
        }

        public void Execute(IStereoSomEngine stereoSomEngine)
        {
            Execute(stereoSomEngine, _phaseIterations / 10);
        }
    }
}