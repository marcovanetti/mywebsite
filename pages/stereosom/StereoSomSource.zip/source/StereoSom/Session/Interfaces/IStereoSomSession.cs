using System;
using System.Collections.Generic;
using ArteStereo.Images;
using StereoSom.Engine.Interfaces;
using StereoSom.Strategies;
using StereoSom.Strategies.Interfaces;

namespace StereoSom.Session.Interfaces
{
    public interface IStereoSomSession : IDisposable
    {
        /// <summary>
        /// Image width
        /// </summary>
        int ImageWidth { get; }

        /// <summary>
        /// Image height
        /// </summary>
        int ImageHeight { get; }

        /// <summary>
        /// Give the disparity map for the left SOM
        /// </summary>
        TruecolorImage LeftDisparityMap { get; }

        /// <summary>
        /// Give the disparity map for the right SOM
        /// </summary>
        TruecolorImage RightDisparityMap { get; }

        /// <summary>
        /// Give the textual disparity map for the left SOM
        /// </summary>
        string LeftTextualDisparityMap { get; }

        /// <summary>
        /// Give the textual disparity map for the right SOM
        /// </summary>
        string RightTextualDisparityMap { get; }

        /// <summary>
        /// Parameters
        /// </summary>
        IStereoSomParameters Parameters { get; set; }

        /// <summary>
        /// StereoSomSession phases
        /// </summary>
        IEnumerable<IStereoSomPhase> StereoSomPhases { get; set; }

        /// <summary>
        /// Event called ever compled core iteration cycle
        /// </summary>
        event StereoSomPhase.StereoSomPhaseCallback OnInternalIterationCycleDone;

        /// <summary>
        /// Execute this StereoSomSession session
        /// </summary>
        void Execute();
    }
}