﻿using System;
using System.Collections.Generic;
using ArteStereo.Images;
using StereoSom.Engine;
using StereoSom.Engine.Interfaces;
using StereoSom.Session.Interfaces;
using StereoSom.Strategies;
using StereoSom.Strategies.Interfaces;
using StereoSom.Utilities;

namespace StereoSom.Session
{
    /// <summary>
    /// StereoSomSession algorithm
    /// </summary>
    public class StereoSomSession : IStereoSomSession
    {
        /// <summary>
        /// Image width
        /// </summary>
        public int ImageWidth { get { return _stereoSomEngine.ImageWidth; } }

        /// <summary>
        /// Image height
        /// </summary>
        public int ImageHeight { get { return _stereoSomEngine.ImageHeight; } }

        /// <summary>
        /// Give the disparity map for the left SOM
        /// </summary>
        public TruecolorImage LeftDisparityMap
        {
            get
            {
                _somWeightsUtils.DeserializeImage(_stereoSomEngine.LeftDisparityVector, Parameters.NormalizationFactor ?? 1, Parameters.MinDisp, _leftDisparityMap);
                return _leftDisparityMap;
            }

        }

        /// <summary>
        /// Give the disparity map for the right SOM
        /// </summary>
        public TruecolorImage RightDisparityMap
        {
            get
            {
                _somWeightsUtils.DeserializeImage(_stereoSomEngine.RightDisparityVector, Parameters.NormalizationFactor ?? 1, Parameters.MinDisp, _rightDisparityMap);
                return _rightDisparityMap;
            }
        }

        /// <summary>
        /// Give the textual disparity map for the left SOM
        /// </summary>
        public string LeftTextualDisparityMap
        {
            get { return _somWeightsUtils.DeserializeText(_stereoSomEngine.RightDisparityVector, ImageHeight, ImageWidth); }
        }

        /// <summary>
        /// Give the textual disparity map for the right SOM
        /// </summary>
        public string RightTextualDisparityMap
        {
            get { return _somWeightsUtils.DeserializeText(_stereoSomEngine.LeftDisparityVector, ImageHeight, ImageWidth); }
        }

        /// <summary>
        /// Parameters
        /// </summary>
        public IStereoSomParameters Parameters
        {
            get { return _stereoSomEngine.Parameters; } 
            set { _stereoSomEngine.Parameters = value; }
        }

        /// <summary>
        /// StereoSomSession phases
        /// </summary>
        public IEnumerable<IStereoSomPhase> StereoSomPhases { get; set; }

        /// <summary>
        /// Event called ever compled core iteration cycle
        /// </summary>
        public event StereoSomPhase.StereoSomPhaseCallback OnInternalIterationCycleDone;

        private readonly IStereoSomEngine _stereoSomEngine;
        private readonly SomWeightsUtils _somWeightsUtils;
        private readonly TruecolorImage _leftDisparityMap;
        private readonly TruecolorImage _rightDisparityMap;

        /// <summary>
        /// Create a new StereoSomSession session
        /// </summary>
        /// <param name="stereoSomEngine">StereoSomEngine instance</param>
        /// <param name="internalIterationCycleDoneCallback">Callback function raised by the core</param>
        public StereoSomSession(IStereoSomEngine stereoSomEngine,
                         StereoSomPhase.StereoSomPhaseCallback internalIterationCycleDoneCallback)
        {
            if (stereoSomEngine == null) throw new ArgumentNullException("stereoSomEngine");
            
            _stereoSomEngine = stereoSomEngine;
            _somWeightsUtils = new SomWeightsUtils();
            OnInternalIterationCycleDone = internalIterationCycleDoneCallback;
            StereoSomPhases = new List<IStereoSomPhase>();

            // Pre-allcoate images for Left and Right disparity maps
            _leftDisparityMap = new TruecolorImage(ImageWidth, ImageHeight);
            _rightDisparityMap = new TruecolorImage(ImageWidth, ImageHeight);
        }

        /// <summary>
        /// Create a new StereoSomSession session
        /// </summary>
        /// <param name="leftImage">Left stereo image</param>
        /// <param name="rightImage">Left stereo image</param>
        /// <param name="stereoSomParameters">Initial algorithm parameters</param>
        /// <param name="internalIterationCycleDoneCallback">Callback function raised by the core</param>
        public StereoSomSession(TruecolorImage leftImage, TruecolorImage rightImage, IStereoSomParameters stereoSomParameters, 
                         StereoSomPhase.StereoSomPhaseCallback internalIterationCycleDoneCallback)
            : this(new StereoSomEngine(leftImage, rightImage), internalIterationCycleDoneCallback)
        {
            Parameters = stereoSomParameters;
        }

        /// <summary>
        /// Create a new StereoSomSession session
        /// </summary>
        /// <param name="leftImage">Left stereo image</param>
        /// <param name="rightImage">Left stereo image</param>
        /// <param name="stereoSomParameters">Initial algorithm parameters</param>
        public StereoSomSession(TruecolorImage leftImage, TruecolorImage rightImage, IStereoSomParameters stereoSomParameters)
            : this(leftImage, rightImage, stereoSomParameters, null) { }


        /// <summary>
        /// Execute this StereoSomSession session
        /// </summary>
        public void Execute()
        {
            if (StereoSomPhases == null) throw new Exception("StereoSomPhases property can't be setted to null");

            _stereoSomEngine.SetDynamicDefaultParameters();
            
            foreach (var phase in StereoSomPhases)
            {
                if (OnInternalIterationCycleDone != null)
                {
                    phase.OnInternalIterationCycleDone += OnInternalIterationCycleDone;
                }
                Console.WriteLine("Executing {0} phase...", phase.Name);
                phase.Execute(_stereoSomEngine);
                Console.WriteLine();
            }
        }

        public void Dispose()
        {
            _leftDisparityMap.Dispose();
            _rightDisparityMap.Dispose();
        }
    }
}
