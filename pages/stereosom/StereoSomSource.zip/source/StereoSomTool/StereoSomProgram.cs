﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using StereoSom.Engine;
using StereoSom.Strategies;
using StereoSomTool.Libraries;

namespace StereoSomTool
{
    public static class StereoSomProgram
    {
        private static readonly string s_toolExecutableName = Path.GetFileNameWithoutExtension(Application.ExecutablePath);

        static void Main(string[] args)
        {
            var options = new OptionSet();
            List<string> extraParameters;
            var showHelp = false;
            var showGui = false;

            // SteroSom Default parameters (Override by command line arguments)
            var stereoSomThreadParams = new StereoSomThreadParameters
                                            {
                                                NormFactor = null,
                                                Profile = "sot",
                                                InitialParams = new StereoSomParameters
                                                                    {
                                                                        MaxDisp = null,
                                                                        MinDisp = 0,
                                                                        MaxVerticalDisp = 0,
                                                                        MinVerticalDisp = 0,
                                                                        NormalizationFactor = null,
                                                                        ConsistenceCheckStrategy =
                                                                        ConsistenceCheckStrategies.BidirectionalCheck,
                                                                        SupportSize = 3,
                                                                        SupportVariance = 300,
                                                                        SubPixelSize = 0.25,
                                                                    },
                                                OrderingParams = new OrderingParameters
                                                                     {
                                                                         Iterations = null,
                                                                         Smoothed = null,
                                                                         ColorMagnitude = 1000,
                                                                         ContinuityMagnitude = 1,
                                                                         StartLearningSize = 80,
                                                                         EndLearningSize = 10,
                                                                     },
                                                TuningParams = new TuningParameters
                                                                   {
                                                                       Iterations = null,
                                                                       ColorDrivenlearningFunctionVariance = 300,
                                                                       ColorMagnitude = 20,
                                                                       ContinuityMagnitude = 1,
                                                                       StartLearningFunctionSpreadMax = 1,
                                                                       EndLearningFunctionSpreadMax = 1,
                                                                       StartLearningFunctionSpreadMin = 0.01,
                                                                       EndLearningFunctionSpreadMin = 0.01,
                                                                       LearningSize = 20,
                                                                       Accuracy = 1,
                                                                   },
                                                LeftImagePath = null,
                                                RightImagePath = null,
                                                OutPath = "",
                                                OutFile = null,
                                                ImageOutput = true,
                                                TextOutput = false,
                                                DiscoverDisparityRange = false,
                                            };

            const string defaultValue = "Default= ";

            var generalOptions = new OptionSet
                                     {
                                         {
                                             "h|?|help", "Show the program help",
                                             v => showHelp = true
                                             },
                                         {
                                             "g|preview", "Show the StereoSom GUI with a results preview",
                                             v => showGui = true
                                             },
                                         {
                                             "p|profile=", "StereoSom profile, allowed values:\n" +
                                                           "'o'  : ordering phase \n" +
                                                           "'so' : smoothed ordering phase \n" +
                                                           "'t'  : tuning phase \n" +
                                                           "and compositions ('ot', 'sot')\n" +
                                                           defaultValue + "'sot'",
                                             v =>
                                                 {
                                                     stereoSomThreadParams.Profile = v;
                                                     switch (stereoSomThreadParams.Profile)
                                                     {
                                                         case "o":
                                                         case "so":
                                                         case "t":
                                                         case "ot":
                                                         case "sot":
                                                             break;
                                                         default:
                                                             showHelp = true;
                                                             break;
                                                     }
                                                 }
                                             },
                                         {
                                             "maxd|maxDisparity=", "Peak disparity value\n" +
                                                                   defaultValue + "(image width)",
                                             (int v) => stereoSomThreadParams.InitialParams.MaxDisp = v
                                             },
                                         {
                                             "mind|minDisparity=", "Slightest disparity value\n" +
                                                                   defaultValue + "'0'",
                                             (int v) => stereoSomThreadParams.InitialParams.MinDisp = v
                                             },
                                         {
                                             "maxvd|maxVerticalDisparity=", "Peak vertical disparity value\n" +
                                                                            defaultValue + "'0'",
                                             (int v) => stereoSomThreadParams.InitialParams.MaxVerticalDisp = v
                                             },
                                         {
                                             "minvd|minVerticalDisparity=", "Slightest vertical disparity value\n" +
                                                                            defaultValue + "'0'",
                                             (int v) => stereoSomThreadParams.InitialParams.MinVerticalDisp = v
                                             },
                                         {
                                             "ccs=|consistencyCheckStrategy=",
                                             "Strategy used to identify and manage occlusions, allowed values:\n" +
                                             "'n' : no check\n" +
                                             "'b' : bidirectional check\n" +
                                             defaultValue + "'b'",
                                             v =>
                                                 {
                                                     switch (v)
                                                     {
                                                         case "n":
                                                             stereoSomThreadParams.InitialParams.ConsistenceCheckStrategy =
                                                                 ConsistenceCheckStrategies.Nothing;
                                                             break;
                                                         case "b":
                                                             stereoSomThreadParams.InitialParams.ConsistenceCheckStrategy =
                                                                 ConsistenceCheckStrategies.BidirectionalCheck;
                                                             break;
                                                         default:
                                                             showHelp = true;
                                                             break;
                                                     }
                                                 }
                                             },
                                         {
                                             "ss|supportSize=", "Adaptive support size\n" +
                                                                defaultValue + "'3'",
                                             (uint v) => stereoSomThreadParams.InitialParams.SupportSize = (int) v
                                             },
                                         {
                                             "sv|supportVariance=", "Adaptive support function variance\n" +
                                                                    defaultValue + "'300'",
                                             (double v) => stereoSomThreadParams.InitialParams.SupportVariance = v
                                             },
                                         {
                                             "sg|subpixelGranularity=", "Subpixel estimation granularity\n" +
                                                                    defaultValue + "'0.25'",
                                             (double v) => stereoSomThreadParams.InitialParams.SubPixelSize = v
                                             },


                                         {
                                             "om=|outputMode=",
                                             "Define how to write output files:\n" +
                                             "'i' : only disparity images\n" +
                                             "'t' : only disparity text files\n" +
                                             "'it' : both\n" +
                                             defaultValue + "'i'",
                                             v =>
                                                 {
                                                     switch (v)
                                                     {
                                                         case "i":
                                                             stereoSomThreadParams.ImageOutput = true;
                                                             stereoSomThreadParams.TextOutput = false;
                                                             break;
                                                         case "t":
                                                             stereoSomThreadParams.ImageOutput = false;
                                                             stereoSomThreadParams.TextOutput = true;
                                                             break;
                                                         case "it":
                                                             stereoSomThreadParams.ImageOutput = true;
                                                             stereoSomThreadParams.TextOutput = true;
                                                             break;
                                                         default:
                                                             showHelp = true;
                                                             break;
                                                     }
                                                 }
                                             },
                                         {
                                             "of|outputFile=", "Output base file name\n",
                                             v => stereoSomThreadParams.OutFile = v
                                             },
                                         {
                                             "od|outputDir=", "Output directory\n",
                                             v =>
                                                 {
                                                     if (Directory.Exists(v))
                                                     {
                                                         stereoSomThreadParams.OutPath = v;
                                                     }
                                                     else
                                                     {
                                                         throw new OptionException("Output directory doesn't exists",
                                                                                   "outputPath");
                                                     }
                                                 }
                                             },
                                         {
                                             "nf|normFactor=",
                                             "Factor used to normalize image disparity maps\n" +
                                             defaultValue + "255/(maxDisparity - minDisparity)",
                                             (double v) => stereoSomThreadParams.InitialParams.NormalizationFactor = v
                                             },
                                     };

            var orderingOptions = new OptionSet
                                      {
                                          {
                                              "oi|orderingIterations=", "Number of iterations\n" +
                                                                        defaultValue + "(imageWidth * imageHeight)/15",
                                              (uint v) => stereoSomThreadParams.OrderingParams.Iterations = (int) v
                                              },
                                          {
                                              "ocolm|orderingColorMagnitude=", "Magnitude of the color feature\n" +
                                                                               defaultValue + "'1000'",
                                              (double v) => stereoSomThreadParams.OrderingParams.ColorMagnitude = v
                                              },
                                          {
                                              "oconm|orderingContinuityMagnitude=",
                                              "Magnitude of the continuity feature\n" +
                                              defaultValue + "'1'",
                                              (double v) => stereoSomThreadParams.OrderingParams.ContinuityMagnitude = v
                                              },
                                          {
                                              "ols|orderingLearningSize=",
                                              "Learning function size (variable inteval)\n" +
                                              defaultValue + "'80:10'",
                                              v =>
                                                  {
                                                      var learningSizes = v.Split(':');
                                                      uint startLearningSize, endLearningSize;

                                                      if (learningSizes.Length != 2 ||
                                                          !uint.TryParse(learningSizes[0], out startLearningSize) ||
                                                          !uint.TryParse(learningSizes[1], out endLearningSize))
                                                      {
                                                          showHelp = true;
                                                      }
                                                      else
                                                      {
                                                          stereoSomThreadParams.OrderingParams.StartLearningSize = (int) startLearningSize;
                                                          stereoSomThreadParams.OrderingParams.EndLearningSize = (int) endLearningSize;
                                                      }
                                                  }
                                              },
                                      };

            var tuningOptions = new OptionSet
                                    {
                                        {
                                            "ti|tuningIterations=", "Number of iterations\n" +
                                                                    defaultValue + "Delegated to tuningAccuracy",
                                            (uint v) => stereoSomThreadParams.TuningParams.Iterations = (int) v
                                            },
                                        {
                                            "ta|tuningAccuracy=", "Number of iterations based on image size\n" +
                                            "'0' : it=(imageWidth * imageHeight)/4\n" +
                                            "'1' : it=(imageWidth * imageHeight)/2\n" +
                                            "'2' : it=(imageWidth * imageHeight)\n" +
                                            "'3' : it=(imageWidth * imageHeight)*2\n" +
                                            "'4' : it=(imageWidth * imageHeight)*4\n" +
                                            defaultValue + "1",
                                            (uint v) =>
                                                {
                                                    if  (v < 0 || v > 4)
                                                    {
                                                        showHelp = true;
                                                    }
                                                    else
                                                    {
                                                        stereoSomThreadParams.TuningParams.Accuracy = (int) v;
                                                    }
                                                }
                                            },
                                        {
                                            "tcolm|tuningColorMagnitude=", "Magnitude of the color feature\n" +
                                                                           defaultValue + "'20'",
                                            (double v) => stereoSomThreadParams.TuningParams.ColorMagnitude = v
                                            },
                                        {
                                            "tconm|tuningContinuityMagnitude=",
                                            "Magnitude of the continuity feature\n" +
                                            defaultValue + "'1'",
                                            (double v) => stereoSomThreadParams.TuningParams.ContinuityMagnitude = v
                                            },
                                        {
                                            "tls|tuningLearningSize=", "Learning function size\n" +
                                                                       defaultValue + "'20'",
                                            (uint v) => stereoSomThreadParams.TuningParams.LearningSize = (int) v
                                            },
                                        {
                                            "tmaxls|tuningMaxLearningSpread=",
                                            "Learning function spread peak value (variable inteval)\n" +
                                            defaultValue + "'1:1'",
                                            v =>
                                                {
                                                    var maxLearningSpread = v.Split(':');
                                                    double startMaxLearningSpread, endMaxLearningSpread;

                                                    if (maxLearningSpread.Length != 2 ||
                                                        !double.TryParse(maxLearningSpread[0],
                                                                      out startMaxLearningSpread) ||
                                                        !double.TryParse(maxLearningSpread[1],
                                                                      out endMaxLearningSpread))
                                                    {
                                                        showHelp = true;
                                                    }
                                                    else
                                                    {
                                                        stereoSomThreadParams.TuningParams.StartLearningFunctionSpreadMax =
                                                            startMaxLearningSpread;
                                                        stereoSomThreadParams.TuningParams.EndLearningFunctionSpreadMax =
                                                            endMaxLearningSpread;
                                                    }
                                                }
                                        },
                                                                                {
                                            "tminls|tuningMinLearningSpread=",
                                            "Learning function spread slightest value (variable inteval)\n" +
                                            defaultValue + "'0.01:0.01'",
                                            v =>
                                                {
                                                    var minLearningSpread = v.Split(':');
                                                    double startMinLearningSpread, endMinLearningSpread;

                                                    if (minLearningSpread.Length != 2 ||
                                                        !double.TryParse(minLearningSpread[0],
                                                                      out startMinLearningSpread) ||
                                                        !double.TryParse(minLearningSpread[1],
                                                                      out endMinLearningSpread))
                                                    {
                                                        showHelp = true;
                                                    }
                                                    else
                                                    {
                                                        stereoSomThreadParams.TuningParams.StartLearningFunctionSpreadMin =
                                                            startMinLearningSpread;
                                                        stereoSomThreadParams.TuningParams.EndLearningFunctionSpreadMin =
                                                            endMinLearningSpread;
                                                    }
                                                }
                                        },
                                        {
                                            "tlv|tuningLearningVariance=", "Learning function variance\n" +
                                                                           defaultValue + "'300'",
                                            (double v) => stereoSomThreadParams.TuningParams.ColorDrivenlearningFunctionVariance = v
                                            },
                                    };
            var otherOptions = new OptionSet
                                   {
                                       {
                                           "ddr|discoverDisparityRange",
                                           "Automagically find and return peak and slightest disparity values",
                                           v => stereoSomThreadParams.DiscoverDisparityRange = true
                                           },
                                   };
            try
            {
                foreach (var option in generalOptions)
                    options.Add(option);
                foreach (var option in orderingOptions)
                    options.Add(option);
                foreach (var option in tuningOptions)
                    options.Add(option);
                foreach (var option in otherOptions)
                    options.Add(option);
                extraParameters = options.Parse(args);

                if (!showHelp)
                {
                    if (extraParameters.Count < 2)
                    {
                        throw new OptionException("Source image paths are not optional", "Source image paths");
                    }

                    if (extraParameters.Count > 2)
                    {
                        throw new OptionException("Wrong parameters", "Source image paths");
                    }

                    stereoSomThreadParams.LeftImagePath = extraParameters[0];
                    if (!File.Exists(stereoSomThreadParams.LeftImagePath))
                    {
                        throw new OptionException(String.Format("{0} file doesn't exists", stereoSomThreadParams.LeftImagePath), "Left image file");
                    }

                    stereoSomThreadParams.RightImagePath = extraParameters[1];
                    if (!File.Exists(stereoSomThreadParams.RightImagePath))
                    {
                        throw new OptionException(String.Format("{0} file doesn't exists", stereoSomThreadParams.RightImagePath), "Right image file");
                    }
                }
            }
            catch (OptionException e)
            {
                Console.WriteLine("StereoSom: {0}", e.Message);
                Console.WriteLine("Try '{0} --help' for more information.", s_toolExecutableName);
                return;
            }

            if (showHelp || extraParameters.Count != 2)
            {
                ShowHelp(
                    new[]{
                            new KeyValuePair<string, OptionSet>(null, generalOptions),
                            new KeyValuePair<string, OptionSet>("ordering phase", orderingOptions),
                            new KeyValuePair<string, OptionSet>("tuning phase", tuningOptions),
                            new KeyValuePair<string, OptionSet>("other functionalities", otherOptions),
                        });
                return;
            }

            // StereoSom Console Thread
            var stereoSomConsole = new Thread(StereoSomThreads.RunConsole);
            // StereoSom GUI Thread
            var stereoSomGui = new Thread(StereoSomThreads.RunGui);
            // StereoSom Algorithm Thread
            var stereoSomThread = new Thread(() => StereoSomThreads.RunStereoSom(stereoSomThreadParams));

            // Start threads
            if (showGui) stereoSomGui.Start();
            stereoSomConsole.Start();
            Thread.Sleep(100);
            stereoSomThread.Start();

            // Wait for threads' natural dead
            if (showGui) stereoSomGui.Join();
            stereoSomConsole.Join();
            stereoSomThread.Join();
        }

        static void ShowHelp(IEnumerable<KeyValuePair<string, OptionSet>> optionSets)
        {
            Console.WriteLine("Usage: {0} [Options] <leftImagePath> <rightImagePath>", s_toolExecutableName);
            Console.WriteLine("Execute the StereoSom algorithm on given stereo images.");
            Console.WriteLine("If no option is specified, default configuration is used.");
            foreach (var optionSet in optionSets)
            {
                Console.WriteLine();

                if (optionSet.Key == null)
                {
                    Console.WriteLine("Options:");
                }
                else
                {
                    Console.WriteLine("Options for {0}:", optionSet.Key);
                }

                optionSet.Value.WriteOptionDescriptions(Console.Out);   
            }
        }
    }
}
