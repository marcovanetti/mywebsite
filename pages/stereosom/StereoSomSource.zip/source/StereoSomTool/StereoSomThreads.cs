﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using ArteStereo.Images;
using Emgu.CV.CvEnum;
using StereoSom.Engine;
using StereoSom.Session;
using StereoSom.Strategies;
using StereoSom.Utilities;
using StereoSomTool.Libraries;
using System.Linq;

namespace StereoSomTool
{
    public static class StereoSomThreads
    {
        private static ProcessStatusGui s_projectStatusform;
        private static readonly SomWeightsUtils s_somWeightsUtils = new SomWeightsUtils();
        private static readonly StereoSomPhase.StereoSomPhaseCallback s_stereoSomCallback =
                (stereoSomEngine, stereoSomPhase, progression) =>
                {
                    ConsoleProgressBar.Draw(progression, Console.BufferWidth);
                    if (s_projectStatusform != null)
                    {
                        var leftPreview = new TruecolorImage(stereoSomEngine.ImageWidth, stereoSomEngine.ImageHeight);
                        s_somWeightsUtils.DeserializeImage(stereoSomEngine.LeftDisparityVector, stereoSomEngine.Parameters.NormalizationFactor ?? 1, stereoSomEngine.Parameters.MinDisp, leftPreview);

                        var rightPreview = new TruecolorImage(stereoSomEngine.ImageWidth, stereoSomEngine.ImageHeight);
                        s_somWeightsUtils.DeserializeImage(stereoSomEngine.RightDisparityVector, stereoSomEngine.Parameters.NormalizationFactor ?? 1, stereoSomEngine.Parameters.MinDisp, rightPreview);

                        s_projectStatusform.UpdateLeftDisparityMap(leftPreview.Bitmap);
                        s_projectStatusform.UpdateRightDisparityMap(rightPreview.Bitmap);
                        s_projectStatusform.UpdateProgressBar((int)(progression * 100));
                    }
                };

        // Show StereoSom Status Console
        public static void RunConsole()
        {
            Console.Title = "StereoSom console";
        }

        // Run StereoSom Status GUI
        [STAThread]
        public static void RunGui()
        {
            // Code borrowed from default Form project
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            s_projectStatusform = new ProcessStatusGui();
            Application.Run(s_projectStatusform);
        }

        public static void RunStereoSom(StereoSomThreadParameters stereoSomParams)
        {
            var tic = DateTime.Now;
            if (stereoSomParams.DiscoverDisparityRange)
            {
                RunDisparityRange(stereoSomParams);
            }
            else
            {
                RunStereoMatching(stereoSomParams);
            }
            var toc = DateTime.Now;

            Console.WriteLine("Required time: {0} seconds.", (toc - tic).TotalSeconds);
        }

        private static void RunStereoMatching(StereoSomThreadParameters stereoSomParams)
        {
            // Default output files
            string outLeftFile;
            string outRightFile;
            if (String.IsNullOrEmpty(stereoSomParams.OutFile))
            {
                outLeftFile = Path.GetFileNameWithoutExtension(stereoSomParams.LeftImagePath);
                outRightFile = Path.GetFileNameWithoutExtension(stereoSomParams.RightImagePath);
            }
            else
            {
                outLeftFile = stereoSomParams.OutFile + "_left";
                outRightFile = stereoSomParams.OutFile + "_right";
            }

            var leftImageOutput = Path.Combine(stereoSomParams.OutPath, outLeftFile + "_disp" + Path.GetExtension(stereoSomParams.LeftImagePath));
            var rightImageOutput = Path.Combine(stereoSomParams.OutPath, outRightFile + "_disp" + Path.GetExtension(stereoSomParams.RightImagePath));
            var leftTextOutput = Path.Combine(stereoSomParams.OutPath, outLeftFile + "_disp.txt");
            var rightTextOutput = Path.Combine(stereoSomParams.OutPath, outRightFile + "_disp.txt");

            Console.WriteLine("Loading images...");
            TruecolorImage leftImage, rightImage;
            try
            {
                leftImage = new TruecolorImage(stereoSomParams.LeftImagePath);
                rightImage = new TruecolorImage(stereoSomParams.RightImagePath);
            }
            catch
            {
                Console.WriteLine("Image type not supported!");
                return;
            }

            using (var stereoSom = new StereoSomSession(leftImage, rightImage, stereoSomParams.InitialParams, s_stereoSomCallback))
            {
                stereoSomParams.OrderingParams.Smoothed = stereoSomParams.Profile.Contains("s");
                if (stereoSomParams.Profile.Contains("o"))
                {
                    stereoSom.AddStrategy(new Ordering(stereoSom.ImageHeight, stereoSom.ImageWidth,
                                                       stereoSomParams.OrderingParams));
                }
                if (stereoSomParams.Profile.Contains("t"))
                {
                    stereoSom.AddStrategy(new Tuning(stereoSom.ImageHeight, stereoSom.ImageWidth,
                                                     stereoSomParams.TuningParams));
                }

                Console.WriteLine("Executing StereoSom...");
                stereoSom.Execute();

                if (stereoSomParams.ImageOutput)
                {
                    stereoSom.LeftDisparityMap.Save(leftImageOutput);
                    stereoSom.RightDisparityMap.Save(rightImageOutput);
                }
                if (stereoSomParams.TextOutput)
                {
                    using (var leftTextWriter = new StreamWriter(leftTextOutput))
                    using (var rightTextWriter = new StreamWriter(rightTextOutput))
                    {
                        leftTextWriter.Write(stereoSom.LeftTextualDisparityMap);
                        rightTextWriter.Write(stereoSom.RightTextualDisparityMap);
                    }
                }
            }
        }

        private static void RunDisparityRange(StereoSomThreadParameters stereoSomParams)
        {
            Console.WriteLine("Loading images...");
            using (var leftOrigImage = new TruecolorImage(stereoSomParams.LeftImagePath))
            using (var rightOrigImage = new TruecolorImage(stereoSomParams.RightImagePath))
            using (var leftImage = leftOrigImage.Resize(DiscoverDisparityRange.ScaledImageWidth, DiscoverDisparityRange.ScaledImageHeight, INTER.CV_INTER_LINEAR))
            using (var rightImage = rightOrigImage.Resize(DiscoverDisparityRange.ScaledImageWidth, DiscoverDisparityRange.ScaledImageHeight, INTER.CV_INTER_LINEAR))
            {
                var stereoSomEngine = new StereoSomEngine(leftImage, rightImage);
                using (var stereoSom = new StereoSomSession(stereoSomEngine, s_stereoSomCallback))
                {
                    stereoSom.AddStrategy(new DiscoverDisparityRange());

                    stereoSom.Parameters = stereoSomParams.InitialParams;
                    stereoSom.Parameters.MinDisp = -leftImage.Width;
                    stereoSom.Parameters.MaxDisp = leftImage.Width;

                    Console.WriteLine("Executing StereoSom...");
                    stereoSom.Execute();

                    var disparityRange =
                        GetDisparityRange(stereoSomEngine.LeftDisparityVector.Union(stereoSomEngine.RightDisparityVector), leftOrigImage.Width);

                    Console.WriteLine("Slightest disparity: {0}", disparityRange.Key);
                    Console.WriteLine("Peak disparity: {0}", disparityRange.Value);
                }
            }
        }

        private static KeyValuePair<double, double> GetDisparityRange(IEnumerable<double> disparityValues, int imageWidth)
        {
            var ceilDispFreq = new Dictionary<int, int>();
            var floorDispFreq = new Dictionary<int, int>();

            const double selectionThreshold = (DiscoverDisparityRange.ScaledImageWidth * DiscoverDisparityRange.ScaledImageHeight * 2) * 0.01;
            var normFactor = (double)imageWidth / DiscoverDisparityRange.ScaledImageWidth;

            foreach (var dispNormValue in disparityValues)
            {
                var dispValue = dispNormValue * normFactor;

                var ceilValue = (int)Math.Ceiling(dispValue);
                if (ceilDispFreq.ContainsKey(ceilValue))
                    ceilDispFreq[ceilValue]++;
                else
                    ceilDispFreq.Add(ceilValue, 1);

                var floorValue = (int)Math.Floor(dispValue);
                if (floorDispFreq.ContainsKey(floorValue))
                    floorDispFreq[floorValue]++;
                else
                    floorDispFreq.Add(floorValue, 1);
            }

            var minDisp = (from disp in floorDispFreq
                           where disp.Value > selectionThreshold
                           select disp.Key);
            var maxDisp = (from disp in ceilDispFreq
                           where disp.Value > selectionThreshold
                           select disp.Key);

            if (minDisp.Any() && maxDisp.Any())
            {
                return new KeyValuePair<double, double>(minDisp.Min(), maxDisp.Max());
            }

            return new KeyValuePair<double, double>(0, 0);
        }
    }

    /// <summary>
    /// StereoSom thread initializaion parameters
    /// </summary>
    public class StereoSomThreadParameters
    {
        public string LeftImagePath { get; set; }
        public string RightImagePath { get; set; }
        public string OutPath { get; set; }
        public string OutFile { get; set; }
        public double? NormFactor { get; set; }
        public string Profile { get; set; }
        public StereoSomParameters InitialParams { get; set; }
        public OrderingParameters OrderingParams { get; set; }
        public TuningParameters TuningParams { get; set; }
        public bool TextOutput { get; set; }
        public bool ImageOutput { get; set; }
        public bool DiscoverDisparityRange { get; set; }
    }
}
