﻿using System.Windows.Forms;

namespace StereoSomTool
{
    public partial class ProcessStatusGui : Form
    {
        public ProcessStatusGui()
        {
            InitializeComponent();
        }
    }
}
