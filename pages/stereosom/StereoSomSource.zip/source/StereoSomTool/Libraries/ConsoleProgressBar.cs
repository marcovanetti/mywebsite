﻿using System;

namespace StereoSomTool.Libraries
{
    public static class ConsoleProgressBar
    {
        /// <summary>
        /// Draw a progress bar on the console
        /// </summary>
        /// <param name="progression">Progression value [0:1]</param>
        /// <param name="barLength">Length for the progress bar</param>
        public static void Draw(double progression, int barLength)
        {
            var closingText = string.Format("] {0}%", (int)(progression * 100));

            barLength -= (closingText.Length + 2);

            var filledArea = (int)(progression * barLength);
            var progressChars = "----=----*----+".ToCharArray();

            Console.Write("\r[");
            for (var i = 0; i < filledArea; i++)
            {
                Console.Write("{0}", progressChars[i % progressChars.Length]);
            }
            for (var i = filledArea; i < barLength; i++)
            {
                Console.Write(" ");
            }
            Console.Write(closingText);
        }
    }
}
