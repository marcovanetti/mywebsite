﻿using System.Drawing;

namespace StereoSomTool
{
    partial class ProcessStatusGui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusPanel = new System.Windows.Forms.Panel();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.disparitySplitPanel = new System.Windows.Forms.SplitContainer();
            this.leftDisparityMap = new System.Windows.Forms.PictureBox();
            this.rightDisparityMap = new System.Windows.Forms.PictureBox();
            this.statusPanel.SuspendLayout();
            this.disparitySplitPanel.Panel1.SuspendLayout();
            this.disparitySplitPanel.Panel2.SuspendLayout();
            this.disparitySplitPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.leftDisparityMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDisparityMap)).BeginInit();
            this.SuspendLayout();
            // 
            // statusPanel
            // 
            this.statusPanel.Controls.Add(this.progressBar);
            this.statusPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.statusPanel.Location = new System.Drawing.Point(0, 252);
            this.statusPanel.Name = "statusPanel";
            this.statusPanel.Size = new System.Drawing.Size(505, 32);
            this.statusPanel.TabIndex = 3;
            // 
            // progressBar
            // 
            this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar.Location = new System.Drawing.Point(3, 4);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(499, 25);
            this.progressBar.TabIndex = 1;
            // 
            // disparitySplitPanel
            // 
            this.disparitySplitPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.disparitySplitPanel.IsSplitterFixed = true;
            this.disparitySplitPanel.Location = new System.Drawing.Point(0, 0);
            this.disparitySplitPanel.Name = "disparitySplitPanel";
            // 
            // disparitySplitPanel.Panel1
            // 
            this.disparitySplitPanel.Panel1.Controls.Add(this.leftDisparityMap);
            // 
            // disparitySplitPanel.Panel2
            // 
            this.disparitySplitPanel.Panel2.Controls.Add(this.rightDisparityMap);
            this.disparitySplitPanel.Size = new System.Drawing.Size(505, 250);
            this.disparitySplitPanel.SplitterDistance = 250;
            this.disparitySplitPanel.TabIndex = 1;
            this.disparitySplitPanel.TabStop = false;
            // 
            // leftDisparityMap
            // 
            this.leftDisparityMap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.leftDisparityMap.Location = new System.Drawing.Point(0, 0);
            this.leftDisparityMap.Name = "leftDisparityMap";
            this.leftDisparityMap.Size = new System.Drawing.Size(250, 250);
            this.leftDisparityMap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.leftDisparityMap.TabIndex = 0;
            this.leftDisparityMap.TabStop = false;
            // 
            // rightDisparityMap
            // 
            this.rightDisparityMap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rightDisparityMap.Location = new System.Drawing.Point(0, 0);
            this.rightDisparityMap.Name = "rightDisparityMap";
            this.rightDisparityMap.Size = new System.Drawing.Size(251, 250);
            this.rightDisparityMap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rightDisparityMap.TabIndex = 1;
            this.rightDisparityMap.TabStop = false;
            // 
            // ProcessStatusGui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 284);
            this.Controls.Add(this.statusPanel);
            this.Controls.Add(this.disparitySplitPanel);
            this.MinimumSize = new System.Drawing.Size(300, 200);
            this.Name = "ProcessStatusGui";
            this.Text = "StereoSom";
            this.statusPanel.ResumeLayout(false);
            this.disparitySplitPanel.Panel1.ResumeLayout(false);
            this.disparitySplitPanel.Panel2.ResumeLayout(false);
            this.disparitySplitPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.leftDisparityMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDisparityMap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel statusPanel;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.SplitContainer disparitySplitPanel;
        private System.Windows.Forms.PictureBox leftDisparityMap;
        private System.Windows.Forms.PictureBox rightDisparityMap;

        # region Thread safe "barbatrick"

        delegate void UpdateDisparityMapDelegate(Image newImage);
        public void UpdateLeftDisparityMap(Image newImage)
        {
            if (progressBar.InvokeRequired)
            {
                var del = new UpdateDisparityMapDelegate(UpdateLeftDisparityMap);
                leftDisparityMap.Invoke(del, new object[] { newImage });
            }
            else
            {
                leftDisparityMap.Image = newImage;
                leftDisparityMap.Refresh();
            }
        }

        public void UpdateRightDisparityMap(Image newImage)
        {
            if (progressBar.InvokeRequired)
            {
                var del = new UpdateDisparityMapDelegate(UpdateRightDisparityMap);
                rightDisparityMap.Invoke(del, new object[] { newImage });
            }
            else
            {
                rightDisparityMap.Image = newImage;
                rightDisparityMap.Refresh();
            }
        }

        delegate void UpdateProgressBarDelegate(int newProgress);
        public void UpdateProgressBar(int newProgress)
        {
            if (progressBar.InvokeRequired)
            {
                var del = new UpdateProgressBarDelegate(UpdateProgressBar);
                progressBar.Invoke(del, new object[] { newProgress });
            }
            else
            {
                progressBar.Value = newProgress;
            }
        }

        # endregion
    }
}